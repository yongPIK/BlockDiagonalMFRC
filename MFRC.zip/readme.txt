1. Dataset Parameters for Ten Chaotic Systems
System Name	Data File	Input Dimension	Output Dimension	Reservoir Size
SprottA	data_SprottA_2000_0.01.dat	3	3	100
SprottB	data_SprottB_2000_0.01.dat	3	3	100
SprottC	data_SprottC_2000_0.01.dat	3	3	100
SprottD	data_SprottD_2000_0.01.dat	3	3	100
Lorenz	data_Lorenz.dat	3	3	100
Roessler	data_roessler2_1000_0.01.dat	3	3	100
Chen	data_chen_1000_0.01.dat	3	3	100
Sel'kov	data_sel_kov_1000_0.01.dat	2	2	100
Hyperchaotic Oscillator	data_hyperchaotic_oscillator_1000_0.01.dat	4	4	500
Hyper SprottB	data_hyper_sprottB_1000_0.01.dat	5	5	500

2. Experimental Global Parameter Settings
Parameter Name	Description	Value
Number of Experiments	Number of independent experiment repetitions	500
Total Training Length	Total training duration of the reservoir	60000 steps
Test Length	Duration of the prediction phase	30000 steps
Initialization Length	Number of initial steps discarded during training	6000 steps
Downsampling Interval	Sampling interval for correlation dimension calculation	5 steps

3. Reservoir Hyperparameters for Ten Systems
System Name	W_in_a	k	ρ
SprottA	0.166903974271684	59.1510248401282	-2.82953128218694
SprottB	0.524801417382458	2.80696270207184	2.72180624436781
SprottC	0.287709384851287	74.0972678053068	1.97938743778260
SprottD	1.03375020271522	1	3
Lorenz	2.81262506997391	94.9666913419282	-0.730966611140523
Roessler	0.958860215120228	1.02505593204508	2.70376617790837
Chen	2.88942563792231	6.20808716642222	-0.0376176384094279
Sel'kov	2.23394122119754	24.5498565590683	-0.00227173616567419
Hyperchaotic Oscillator	0.299007202733509	171.705780833805	-1.21189202441243
Hyper SprottB	0.125746762061917	405.335058731385	1.53843634290604

4. Training Hyperparameters
Parameter Name	Description	Value
Leakage Rate (a)	Leakage rate for reservoir state update	0.1
Regularization (reg)	Ridge regression regularization coefficient	1 × 10^(-5)

5. Function Descriptions
Function Name	Parameter Description
gene_Win(resSize, inSize, add_dim, W_in_a, W_in_type)	Generates input weight matrix:
- resSize: Reservoir size
- inSize: Input dimension
- add_dim: Whether to add extra dimension (0/1)
- W_in_a: Input weight magnitude
- W_in_type: Weight type (1: uniform distribution, 2: normal distribution)
gene_Wr(resSize, k, eig_rho, W_r_type)	Generates internal reservoir weight matrix:
- resSize: Reservoir size
- k: Average degree (sparsity)
- eig_rho: Desired spectral radius
- W_r_type: Weight type (1: uniform distribution, 2: normal distribution)
Grassberger_Procaccia(dim, data)	Calculates correlation dimension:
- dim: Embedding dimension
- data: Input data matrix (rows: time points, columns: dimensions)