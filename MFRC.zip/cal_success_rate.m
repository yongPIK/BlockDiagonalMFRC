clear;
clc;

fractal_dim_pre = load('Dim_fractal_matrix_pre_10sys_30000length_gap10_500times.dat');
fractal_dim_true = load('Dim_fractal_matrix_ture_10sys_30000length_gap10_500times.dat');
num=500;

err_fractal_dim=abs((fractal_dim_pre -fractal_dim_true)./fractal_dim_true);
suc_rat_all_MFRC  = sum(err_fractal_dim < 0.2, 1)/num;

