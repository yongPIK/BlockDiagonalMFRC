"""R1-5 / R2-5: optimisation and readout cost accounting.

Merged from: c8b_timing_protocol.py, c8c_optimization_cost.py, c8d_optimization_runs.py, c8h_uniform_budget.py, exp_c8_costs.py
"""

try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import json
import os
import platform
import sys
import time
import numpy as np
from mfrc import rc                                     # noqa: E402
import io
from scipy.stats import qmc                                    # noqa: E402
import c8e_optimization_benchmark as B                          # noqa: E402
from c8g_modular_scaling import eval_params_mod                 # noqa: E402


# ========================================================================
# c8b_timing_protocol.py
# ========================================================================

"""Re-measure the cost benchmark with an explicit, reproducible protocol.

Records the machine, the thread setting, the exact scope of each timed block,
and repeats every measurement (1 warm-up + 5 timed runs).

Run:  python c8b_timing_protocol.py      (writes results/c8b_timing.json)
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")          # single-threaded BLAS


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

c8b_timing_protocol_MOD = 100          # nodes per module
c8b_timing_protocol_N_OUT = 3          # outputs per module
T_READOUT = 20000  # samples used to fit the readout
c8b_timing_protocol_TRAIN_STEPS = 60000
INIT_STEPS = 6000
c8b_timing_protocol_REPEATS = 5
MODULE_SIZES = (1, 2, 4, 8)


def c8b_timing_protocol_machine_info():
    info = {
        "os": "%s %s" % (platform.system(), platform.release()),
        "python": sys.version.split()[0],
        "numpy": np.__version__,
        "logical_cpus": os.cpu_count(),
        "blas_threads": {k: os.environ.get(k) for k in
                         ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS")},
    }
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                             r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        info["cpu"] = winreg.QueryValueEx(key, "ProcessorNameString")[0].strip()
    except Exception as exc:                              # pragma: no cover
        info["cpu"] = "unknown (%s)" % exc
    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        m = MS()
        m.dwLength = ctypes.sizeof(MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        info["ram_GB"] = round(m.ullTotalPhys / 1e9, 1)
    except Exception:
        pass
    return info


def build_case(n, seed=0):
    rng = np.random.default_rng(seed)
    W_in = [rc.gene_Win(c8b_timing_protocol_MOD, 3, 1.0, rng) for _ in range(n)]
    W_r = [rc.gene_Wr(c8b_timing_protocol_MOD, 10, 1.0, rng) for _ in range(n)]
    W = np.zeros((n * c8b_timing_protocol_MOD, n * c8b_timing_protocol_MOD))
    for i in range(n):
        W[i * c8b_timing_protocol_MOD:(i + 1) * c8b_timing_protocol_MOD, i * c8b_timing_protocol_MOD:(i + 1) * c8b_timing_protocol_MOD] = W_r[i]
    data = [rng.standard_normal((3, c8b_timing_protocol_TRAIN_STEPS)) * 0.5 for _ in range(n)]
    starts = [i * c8b_timing_protocol_MOD for i in range(n)]
    ends = [(i + 1) * c8b_timing_protocol_MOD for i in range(n)]
    return W_in, W_r, W, data, starts, ends


def time_call(fn, repeats=c8b_timing_protocol_REPEATS):
    fn()                                    # warm-up (not recorded)
    ts = []
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        ts.append(time.perf_counter() - t0)
    ts = np.array(ts)
    return float(ts.mean()), float(ts.std(ddof=1)), float(ts.min())


def main_c8b_timing_protocol():
    out = {"protocol": {
        "clock": "time.perf_counter() wall clock, single process, single thread",
        "repeats": "%d timed runs after 1 warm-up; mean +/- s.d. reported" % c8b_timing_protocol_REPEATS,
        "reservoir_pass": "run_reservoir_forced: %d update steps of the full "
                          "block-diagonal state, including input projections and tanh; "
                          "data already in memory" % c8b_timing_protocol_TRAIN_STEPS,
        "readout_blockwise": "ridge regression fitted separately for each module on the "
                             "last %d samples" % T_READOUT,
        "readout_global": "one ridge regression from the concatenated state "
                          "(%dN x %dN) to all outputs, same samples" % (c8b_timing_protocol_MOD, c8b_timing_protocol_MOD),
        "excluded": "data loading, hyperparameter optimisation, plotting",
        "caveat": "measured with a NumPy re-implementation on the machine below; "
                  "the authors' MATLAB implementation should be re-measured with the "
                  "same protocol before the numbers are quoted in the paper",
    }, "machine": c8b_timing_protocol_machine_info(), "results": {}}

    for n in MODULE_SIZES:
        W_in, W_r, W, data, starts, ends = build_case(n)
        case = {}

        def pass_fn():
            rc.run_reservoir_forced(W_in, W, data, c8b_timing_protocol_TRAIN_STEPS, INIT_STEPS, 0.1,
                                    starts, ends)

        X = rc.run_reservoir_forced(W_in, W, data, c8b_timing_protocol_TRAIN_STEPS, INIT_STEPS, 0.1,
                                    starts, ends)
        mean, sd, mn = time_call(pass_fn)
        case["reservoir_pass"] = {"mean_s": mean, "sd_s": sd, "min_s": mn,
                                  "ms_per_step": 1000 * mean / c8b_timing_protocol_TRAIN_STEPS}

        def blk_fn():
            for i in range(n):
                rc.ridge_readout(X[starts[i]:ends[i], -T_READOUT:],
                                 data[i][:, -T_READOUT - 1:-1], 1e-5)

        mean, sd, mn = time_call(blk_fn)
        case["readout_blockwise"] = {"mean_s": mean, "sd_s": sd, "min_s": mn}

        Yt = np.zeros((n * c8b_timing_protocol_N_OUT, T_READOUT))

        def glob_fn():
            rc.ridge_readout(X[:, -T_READOUT:], Yt, 1e-5)

        mean, sd, mn = time_call(glob_fn)
        case["readout_global"] = {"mean_s": mean, "sd_s": sd, "min_s": mn}
        case["ratio_global_over_blockwise"] = (case["readout_global"]["mean_s"]
                                              / case["readout_blockwise"]["mean_s"])
        out["results"]["N=%d" % n] = case
        print("N=%d  pass %.3f s (%.3f ms/step)  block readout %.4f s  "
              "global readout %.4f s  ratio %.2f"
              % (n, case["reservoir_pass"]["mean_s"],
                 case["reservoir_pass"]["ms_per_step"],
                 case["readout_blockwise"]["mean_s"],
                 case["readout_global"]["mean_s"],
                 case["ratio_global_over_blockwise"]), flush=True)

    path = os.path.join(HERE, "results", "c8b_timing.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    print("\nwritten:", path)
    print("machine:", out["machine"])


# ========================================================================
# c8c_optimization_cost.py
# ========================================================================

"""Measure the cost of ONE hyperparameter-c8c_optimization_cost_objective evaluation, and hence the
total cost of the nested optimisation (Referee 1, comment 5).

The c8c_optimization_cost_objective is taken verbatim from the released scripts
(Opt_sprottABCD/func_data_train.m, Opt_lorenz_hypersprottB/func_data_train.m,
Opt/opt_RC_1.m, func_train_repeat.m):

  one c8c_optimization_cost_objective evaluation =
        build W_in, W_r for the module(s)
      + run the teacher-forced reservoir for trainLen = 60000 steps (dropping initLen = 6000)
      + fit one ridge readout per module (last 20000-50000 samples)
      + run a closed-loop rollout of testLen = 10000 steps per module
      + return the summed RMSE over the first errorLen = 5000/500/600/1000 steps

  one outer evaluation  = repeat_num = 10 such c8c_optimization_cost_objective evaluations (parfor)
  one optimisation run  = iter_max   = 200 outer evaluations (surrogateopt)

Run:  python c8c_optimization_cost.py     ->  results/c8c_optimization_cost.json
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

TRAINLEN, INITLEN, TESTLEN = 60000, 6000, 10000
READOUT_SAMPLES = 20000          # per module in the c8c_optimization_cost_objective
ROLLOUT_FOR_ERROR = 5000         # errorLen used for module 1 (largest)
c8c_optimization_cost_REPEATS = 5
OUTER_EVALS = 200                # iter_max in opt_RC_1.m
INNER_REPEATS = 10               # repeat_num in func_train_repeat.m

_CACHE = {}


def c8c_optimization_cost_machine_info():
    info = {"os": "%s %s" % (platform.system(), platform.release()),
            "cpu": "unknown", "python": sys.version.split()[0],
            "numpy": np.__version__, "logical_cpus": os.cpu_count(),
            "blas_threads": os.environ.get("OMP_NUM_THREADS")}
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                           r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        info["cpu"] = winreg.QueryValueEx(k, "ProcessorNameString")[0].strip()
    except Exception:
        pass
    return info


def make_case(sizes, seed=0):
    """sizes: list of module sizes, e.g. [100] or [100,100,100,100] or [100,500]."""
    key = tuple(sizes)
    if key in _CACHE:
        return _CACHE[key]
    rng = np.random.default_rng(seed)
    M = sum(sizes)
    W_in = [rc.gene_Win(m, 3, 1.0, rng) for m in sizes]
    W = np.zeros((M, M))
    s = 0
    for m in sizes:
        W[s:s + m, s:s + m] = rc.gene_Wr(m, 10, 1.0, rng)
        s += m
    data = [rng.standard_normal((3, TRAINLEN + TESTLEN + 10)) * 0.5
            for _ in sizes]
    starts, ends = [], []
    s = 0
    for m in sizes:
        starts.append(s)
        ends.append(s + m)
        s += m
    _CACHE[key] = (W_in, W, data, starts, ends, M)
    return _CACHE[key]


def c8c_optimization_cost_objective(sizes):
    """One evaluation of the hyperparameter c8c_optimization_cost_objective (teacher forcing + rollout)."""
    W_in, W, data, starts, ends, M = make_case(sizes)
    X = rc.run_reservoir_forced(W_in, W, data, TRAINLEN, INITLEN, 0.1, starts, ends)
    total = 0.0
    for i, m in enumerate(sizes):
        seg = X[starts[i]:ends[i], -READOUT_SAMPLES:]
        Yt = data[i][:, TRAINLEN - READOUT_SAMPLES + 1: TRAINLEN + 1]
        Wout = rc.ridge_readout(seg, Yt, 1e-5)
        Y = rc.rollout_single(W_in[i], W[starts[i]:ends[i], starts[i]:ends[i]],
                              Wout, data[i], TRAINLEN, TESTLEN, 0.1,
                              x_init=X[starts[i]:ends[i], -1])
        true = data[i][:, TRAINLEN + 1: TRAINLEN + TESTLEN + 1]
        n = min(ROLLOUT_FOR_ERROR, TESTLEN)
        total += float(np.sqrt(np.mean((Y[:, :n] - true[:, :n]) ** 2)))
    return total


def final_training(sizes):
    """The cost usually quoted for the method: one training + full test rollout."""
    W_in, W, data, starts, ends, M = make_case(sizes)
    X = rc.run_reservoir_forced(W_in, W, data, TRAINLEN, INITLEN, 0.1, starts, ends)
    for i, m in enumerate(sizes):
        seg = X[starts[i]:ends[i], -READOUT_SAMPLES:]
        Yt = data[i][:, TRAINLEN - READOUT_SAMPLES + 1: TRAINLEN + 1]
        Wout = rc.ridge_readout(seg, Yt, 1e-5)
        rc.rollout_single(W_in[i], W[starts[i]:ends[i], starts[i]:ends[i]], Wout,
                          data[i], TRAINLEN, 30000, 0.1,
                          x_init=X[starts[i]:ends[i], -1])


def c8c_optimization_cost_timeit(fn, arg):
    fn(arg)                                  # warm-up
    ts = []
    for _ in range(c8c_optimization_cost_REPEATS):
        t0 = time.perf_counter()
        fn(arg)
        ts.append(time.perf_counter() - t0)
    ts = np.array(ts)
    return float(ts.mean()), float(ts.std(ddof=1))


def main_c8c_optimization_cost():
    cases = {"1 module x 100": [100],
             "4 modules x 100 (Sprott A-D)": [100, 100, 100, 100],
             "2 modules: 100 + 500 (Lorenz+hyperSprottB)": [100, 500]}
    out = {"protocol": {
        "machine": c8c_optimization_cost_machine_info(),
        "clock": "time.perf_counter(), single process, single BLAS thread",
        "repeats": "%d timed runs after 1 warm-up; mean +/- s.d." % c8c_optimization_cost_REPEATS,
        "c8c_optimization_cost_objective": "teacher forcing 60000 steps (initLen 6000) + ridge readout on the "
                     "last 20000 samples + closed-loop rollout of 10000 steps; "
                     "error measured on the first 5000 steps",
        "outer_evaluations": OUTER_EVALS,
        "inner_repeats": INNER_REPEATS,
        "total_objective_evaluations_per_run": OUTER_EVALS * INNER_REPEATS,
    }, "cases": {}}

    for label, sizes in cases.items():
        t_obj, sd_obj = c8c_optimization_cost_timeit(c8c_optimization_cost_objective, sizes)
        t_fin, sd_fin = c8c_optimization_cost_timeit(final_training, sizes)
        total_cpu = t_obj * OUTER_EVALS * INNER_REPEATS
        entry = {
            "modules": sizes,
            "total_nodes": sum(sizes),
            "objective_mean_s": t_obj, "objective_sd_s": sd_obj,
            "final_training_mean_s": t_fin, "final_training_sd_s": sd_fin,
            "budget_objective_evals": OUTER_EVALS * INNER_REPEATS,
            "total_cpu_hours": total_cpu / 3600.0,
            "wall_clock_hours_if_inner_parfor": OUTER_EVALS * t_obj / 3600.0,
            "ratio_total_to_single_training": total_cpu / t_fin,
        }
        out["cases"][label] = entry
        print("%-44s obj %6.2f s  final train %6.2f s  total %6.2f CPU-h "
              "(wall %.2f h with 10 workers)  ratio %6.1fx"
              % (label, t_obj, t_fin, entry["total_cpu_hours"],
                 entry["wall_clock_hours_if_inner_parfor"],
                 entry["ratio_total_to_single_training"]), flush=True)

    path = os.path.join(HERE, "results", "c8c_optimization_cost.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    print("\nwritten:", path)
    print("machine:", out["protocol"]["machine"])


# ========================================================================
# c8d_optimization_runs.py
# ========================================================================

"""Cost of each hyperparameter search that produced Table II.

The four optimisation runs shipped with the paper are re-measured with *their own*
settings, extracted from the released scripts:

  run                     modules            trainLen initLen testLen  readout windows      errorLen        iter_max  src
  Opt                     [100,100]           30000    3000    1000    [5000,20000]         [200,800]        200      Opt/opt_RC_1.m:8, func_data_train.m:18-30
  Opt_sprottABCD          [100,100,100,100]   60000    6000   10000    [50000,20000,30000,40000] [5000,500,600,1000] 300 Opt_sprottABCD/*
  Opt_lorenz_hypersprottB [100,500]           50000    5000    4000    [5000,40000]         [200,600]        200      Opt_lorenz_hypersprottB/*
  Opt_sel_lorenz_hyper_osc[100,100,400]       30000    3000    8000    [10000,10000,20000]  [2000,200,400]   200      Opt_sel_lorenz_hyper_osc/*

One c8d_optimization_runs_objective evaluation = teacher forcing (trainLen steps, initLen discarded)
                         + one ridge readout per module (its own window)
                         + closed-loop rollout of testLen steps per module
                         + RMSE summed over the first errorLen steps of each module.
One outer evaluation = repeat_num = 10 c8d_optimization_runs_objective evaluations (parfor).
One search = iter_max outer evaluations (surrogateopt).

Run:  python c8d_optimization_runs.py   ->  results/c8d_optimization_runs.json
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

ALPHA, REG = 0.1, 1e-5
FINAL_TESTLEN = 30000        # rollout length used for the reported results
INNER = 10                   # repeat_num
c8d_optimization_runs_REPEATS = 3

RUNS = {
    "Opt (Lorenz + Rossler)": dict(
        modules=[100, 100], trainLen=30000, initLen=3000, testLen=1000,
        windows=[5000, 20000], error=[200, 800], outer=200,
        source="Opt/opt_RC_1.m:8; Opt/func_data_train.m:18-30"),
    "Opt_sprottABCD (4 x 100)": dict(
        modules=[100, 100, 100, 100], trainLen=60000, initLen=6000, testLen=10000,
        windows=[50000, 20000, 30000, 40000], error=[5000, 500, 600, 1000],
        outer=300, source="Opt_sprottABCD/opt_RC_1.m:8; func_data_train.m:35-57"),
    "Opt_lorenz_hypersprottB (100+500)": dict(
        modules=[100, 500], trainLen=50000, initLen=5000, testLen=4000,
        windows=[5000, 40000], error=[200, 600], outer=200,
        source="Opt_lorenz_hypersprottB/opt_RC_1.m:8; func_data_train.m:18-30"),
    "Opt_sel_lorenz_hyper_osc (100+100+400)": dict(
        modules=[100, 100, 400], trainLen=30000, initLen=3000, testLen=8000,
        windows=[10000, 10000, 20000], error=[2000, 200, 400], outer=200,
        source="Opt_sel_lorenz_hyper_osc/opt_RC_1.m:8; func_data_train.m:26-46"),
}


def build(cfg, seed=0):
    rng = np.random.default_rng(seed)
    sizes = cfg["modules"]
    M = sum(sizes)
    need = max(cfg["trainLen"] + cfg["testLen"] + 10, cfg["trainLen"] + FINAL_TESTLEN + 10)
    W_in = [rc.gene_Win(m, 3, 1.0, rng) for m in sizes]
    W = np.zeros((M, M))
    s = 0
    for m in sizes:
        W[s:s + m, s:s + m] = rc.gene_Wr(m, 10, 1.0, rng)
        s += m
    data = [rng.standard_normal((3, need)) * 0.5 for _ in sizes]
    starts, ends, s = [], [], 0
    for m in sizes:
        starts.append(s)
        ends.append(s + m)
        s += m
    return W_in, W, data, starts, ends, M


def c8d_optimization_runs_objective(cfg, cache):
    W_in, W, data, starts, ends, M = cache
    tl, ini = cfg["trainLen"], cfg["initLen"]
    X = rc.run_reservoir_forced(W_in, W, data, tl, ini, ALPHA, starts, ends)
    total = 0.0
    for i, m in enumerate(cfg["modules"]):
        L = cfg["windows"][i]
        seg = X[starts[i]:ends[i], -L:]
        Yt = data[i][:, tl - L + 1: tl + 1]
        Wout = rc.ridge_readout(seg, Yt, REG)
        Y = rc.rollout_single(W_in[i], W[starts[i]:ends[i], starts[i]:ends[i]],
                              Wout, data[i], tl, cfg["testLen"], ALPHA,
                              x_init=X[starts[i]:ends[i], -1])
        true = data[i][:, tl + 1: tl + cfg["testLen"] + 1]
        n = min(cfg["error"][i], cfg["testLen"])
        total += float(np.sqrt(np.mean((Y[:, :n] - true[:, :n]) ** 2)))
    return total


def final_run(cfg, cache):
    """One training plus the full test rollout used for the reported results."""
    W_in, W, data, starts, ends, M = cache
    tl, ini = cfg["trainLen"], cfg["initLen"]
    X = rc.run_reservoir_forced(W_in, W, data, tl, ini, ALPHA, starts, ends)
    for i, m in enumerate(cfg["modules"]):
        L = cfg["windows"][i]
        seg = X[starts[i]:ends[i], -L:]
        Yt = data[i][:, tl - L + 1: tl + 1]
        Wout = rc.ridge_readout(seg, Yt, REG)
        rc.rollout_single(W_in[i], W[starts[i]:ends[i], starts[i]:ends[i]], Wout,
                          data[i], tl, FINAL_TESTLEN, ALPHA,
                          x_init=X[starts[i]:ends[i], -1])


def c8d_optimization_runs_timeit(fn, cfg, cache):
    fn(cfg, cache)
    ts = []
    for _ in range(c8d_optimization_runs_REPEATS):
        t0 = time.perf_counter()
        fn(cfg, cache)
        ts.append(time.perf_counter() - t0)
    ts = np.array(ts)
    return float(ts.mean()), float(ts.std(ddof=1))


def main_c8d_optimization_runs():
    out = {"protocol": {
        "clock": "time.perf_counter(), single process, single BLAS thread",
        "repeats": "%d timed runs after 1 warm-up; mean +/- s.d." % c8d_optimization_runs_REPEATS,
        "machine": {"cpu": "unknown", "os": platform.system()},
        "one_objective_evaluation": "teacher forcing (trainLen, initLen discarded) + one "
                                    "ridge readout per module (own window) + closed-loop "
                                    "rollout of testLen steps + RMSE over the first errorLen steps",
        "one_search": "iter_max outer evaluations x repeat_num=10 inner repetitions",
        "note": "NumPy re-implementation; re-measure in MATLAB with the same protocol",
    }, "runs": {}}
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                           r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        out["protocol"]["machine"]["cpu"] = winreg.QueryValueEx(
            k, "ProcessorNameString")[0].strip()
    except Exception:
        pass

    total_cpu = 0.0
    for name, cfg in RUNS.items():
        cache = build(cfg)
        t_obj, sd_obj = c8d_optimization_runs_timeit(c8d_optimization_runs_objective, cfg, cache)
        t_fin, sd_fin = c8d_optimization_runs_timeit(final_run, cfg, cache)
        n_eval = cfg["outer"] * INNER
        cpu_h = t_obj * n_eval / 3600.0
        total_cpu += cpu_h
        entry = {
            "modules": cfg["modules"], "total_nodes": sum(cfg["modules"]),
            "trainLen": cfg["trainLen"], "initLen": cfg["initLen"],
            "testLen": cfg["testLen"], "outer_evals": cfg["outer"],
            "objective_evals": n_eval,
            "objective_s": t_obj, "objective_sd_s": sd_obj,
            "final_run_s": t_fin,
            "search_cpu_hours": cpu_h,
            "search_wall_hours_inner_parfor": cfg["outer"] * t_obj / 3600.0,
            "ratio_search_to_single_run": t_obj * n_eval / t_fin,
            "source": cfg["source"],
        }
        out["runs"][name] = entry
        print("%-40s obj %6.2f s (%4d evals)  search %5.2f CPU-h  "
              "wall %5.2f h  vs single run %6.0fx"
              % (name, t_obj, n_eval, cpu_h,
                 entry["search_wall_hours_inner_parfor"],
                 entry["ratio_search_to_single_run"]), flush=True)

    out["total_cpu_hours_all_four_runs"] = total_cpu
    print("\ntotal for the four searches that produced Table II: %.2f CPU-hours"
          % total_cpu)
    path = os.path.join(HERE, "results", "c8d_optimization_runs.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    print("written:", path)


# ========================================================================
# c8h_uniform_budget.py
# ========================================================================

"""R1-5 / R2-5: one uniform normalisation for the whole cost table.

Every arm receives exactly the same total number of c8h_uniform_budget_objective evaluations
(BUDGET = 128), so "same budget, different cost / quality" is apples to apples:

  N = 2  : Sprott B, C        (per module 64 evaluations)
  N = 4  : Sprott A - D       (per module 32)
  N = 10 : all ten systems    (per module 12-13)

Arms: modular (N independent 3-parameter searches) and joint (one search over
all 3N parameters).  The joint arm is run even for N = 10 (a 30-dimensional
search) so that the table contains no extrapolated row.

The optimiser is an exact-budget differential evolution (DE/rand/1/bin with
Sobol' initialisation); SciPy's DE cannot honour a budget smaller than its
population, which is what made the earlier N = 10 row use 320 evaluations
instead of 128.  Identical optimiser and identical budget in every arm.

Outputs results/c8h_uniform_budget.json (written after every arm).
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

BUDGET = 128
SPROTT_BC, SPROTT_ABCD, ALL_TEN = [1, 2], [0, 1, 2, 3], list(range(10))
NAMES = B.systems.NAMES
PATH = os.path.join(HERE, "results", "c8h_uniform_budget.json")


def objective_factory(idx, budget, rng, stats):
    def obj(x):
        f = eval_params_mod(list(x), idx, [0], rng, stats)
        return f
    return obj


def de_budget(idx, dim_bounds, budget, seed):
    """Exact-budget DE/rand/1/bin; returns (best value, best x, evals, seconds)."""
    bounds = np.array(dim_bounds, dtype=float)
    lo, hi = bounds[:, 0], bounds[:, 1]
    dim = len(bounds)
    pop = max(1, int(min(budget - 1, max(5, 5 * dim))))
    rng = np.random.default_rng(seed)
    stats = {"seconds": 0.0, "t_last": time.perf_counter()}
    obj = objective_factory(idx, budget, rng, stats)

    sampler = qmc.Sobol(d=dim, scramble=True, seed=seed)
    X = lo + sampler.random(pop) * (hi - lo)
    F = np.array([obj(x) for x in X])
    n = pop
    while n < budget:
        if pop < 4:          # DE/rand/1/bin needs four distinct population members
            break
        advanced = False
        for i in range(pop):
            if n >= budget:
                break
            a, b, c = rng.choice([j for j in range(pop) if j != i], 3,
                                 replace=False)
            trial = X[a] + 0.7 * (X[b] - X[c])
            cross = rng.random(dim) < 0.9
            if not cross.any():
                cross[rng.integers(dim)] = True
            trial = np.clip(np.where(cross, trial, X[i]), lo, hi)
            ft = obj(trial)
            n += 1
            advanced = True
            if ft < F[i]:
                X[i], F[i] = trial, ft
        if not advanced:
            break
    k = int(np.argmin(F))
    return float(F[k]), X[k].tolist(), n, stats["seconds"]


def modular(idx, budget, seed0):
    """N independent 3-parameter searches sharing one total budget."""
    base, extra = divmod(budget, len(idx))
    shares = [base + (1 if k < extra else 0) for k in range(len(idx))]
    parts = [de_budget([i], B.BOUNDS, shares[k], seed0 + k)
             for k, i in enumerate(idx)]
    evals = sum(p[2] for p in parts)
    cpu = sum(p[3] for p in parts)
    secs = [p[3] for p in parts]
    return {
        "modules": [NAMES[i] for i in idx],
        "searches": len(idx),
        "params_per_search": 3,
        "evaluations_per_search": shares,
        "evaluations": evals,
        "cpu_seconds": cpu,
        "seconds_per_evaluation": cpu / evals,
        "wall_seconds_with_N_workers": max(secs),
        "per_module_seconds": secs,
        "per_module_objective": [p[0] for p in parts],
        "sum_objective": float(sum(p[0] for p in parts)),
        "best_params": [p[1] for p in parts],
    }


def joint(idx, budget, seed):
    value, x, evals, secs = de_budget(idx, B.BOUNDS * len(idx), budget, seed)
    return {
        "modules": [NAMES[i] for i in idx],
        "searches": 1,
        "params_per_search": 3 * len(idx),
        "evaluations": evals,
        "cpu_seconds": secs,
        "seconds_per_evaluation": secs / evals,
        "wall_seconds_serial": secs,
        "sum_objective": value,
        "best_params": [x],
    }


def main_c8h_uniform_budget():
    out = {"protocol": {
        "budget_per_arm": BUDGET,
        "optimiser": "exact-budget DE/rand/1/bin with Sobol' initialisation "
                     "(identical in every arm)",
        "c8h_uniform_budget_objective": "sum of per-module RMSE of a short closed-loop rollout "
                     "(identical to Opt/func_data_train.m)",
        "nodes_per_module": B.RES,
        "trainLen": B.TRAINLEN, "initLen": B.INITLEN, "testLen": B.TESTLEN,
        "alpha": B.ALPHA, "beta": B.REG,
    }, "arms": {}}

    if os.path.exists(PATH):
        try:
            with io.open(PATH, encoding="utf-8") as fh:
                out["arms"].update(json.load(fh).get("arms", {}))
        except Exception:
            pass

    def dump():
        with io.open(PATH, "w", encoding="utf-8") as fh:
            json.dump(out, fh, indent=1, ensure_ascii=False)

    jobs = [
        ("A_N2_modular", lambda: modular(SPROTT_BC, BUDGET, 11)),
        ("B_N2_joint", lambda: joint(SPROTT_BC, BUDGET, 21)),
        ("C_N4_modular", lambda: modular(SPROTT_ABCD, BUDGET, 31)),
        ("D_N4_joint", lambda: joint(SPROTT_ABCD, BUDGET, 41)),
        ("E_N10_modular", lambda: modular(ALL_TEN, BUDGET, 51)),
        ("F_N10_joint", lambda: joint(ALL_TEN, BUDGET, 61)),
    ]
    for name, fn in jobs:
        if name in out["arms"]:
            print("skip (done):", name, flush=True)
        else:
            print("run:", name, "...", flush=True)
            out["arms"][name] = fn()
            dump()
        a = out["arms"][name]
        print("   evals=%d cpu=%.1fs (%.2f s/eval) wall=%.1fs sum_obj=%.4f"
              % (a["evaluations"], a["cpu_seconds"], a["seconds_per_evaluation"],
                 a.get("wall_seconds_with_N_workers",
                       a.get("wall_seconds_serial")),
                 a.get("sum_objective", float("nan"))),
              flush=True)
    print("written:", PATH, flush=True)


# ========================================================================
# exp_c8_costs.py
# ========================================================================

"""C8: cost accounting for the scaling claims (Referee 1 #5, Referee 2 #5).

(a) analytic operation counts for blockwise vs global ridge regression,
(b) measured wall-clock of the reservoir pass and of the readout fit for
    N = 1, 2, 4, 8 modules of 100 nodes,
(c) hyperparameter counts and the number of exp_c8_costs_objective evaluations actually
    spent per optimization run (from the released driver scripts).
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__))

exp_c8_costs_MOD = 100          # nodes per module
exp_c8_costs_N_OUT = 3          # outputs per module
T = 20000          # training samples used by the readout
exp_c8_costs_TRAIN_STEPS = 60000


def analytic():
    rows = {}
    for n in (2, 4, 8, 10):
        M = n * exp_c8_costs_MOD
        block = sum(T * exp_c8_costs_MOD ** 2 + exp_c8_costs_MOD ** 3 / 3 + T * exp_c8_costs_MOD * exp_c8_costs_N_OUT for _ in range(n))
        glob = T * M ** 2 + M ** 3 / 3 + T * M * n * exp_c8_costs_N_OUT
        rows[n] = {"M_total": M,
                   "blockwise_readout_flops": float(block),
                   "global_readout_flops": float(glob),
                   "ratio": float(glob / block)}
    return rows


def timing():
    rows = {}
    for n in (1, 2, 4, 8):
        rng = np.random.default_rng(0)
        blocks = [rc.gene_Wr(exp_c8_costs_MOD, 10, 1.0, rng) for _ in range(n)]
        W_in = [rc.gene_Win(exp_c8_costs_MOD, 3, 1.0, rng) for _ in range(n)]
        data = [rng.standard_normal((3, exp_c8_costs_TRAIN_STEPS)) * 0.5 for _ in range(n)]
        W = np.zeros((n * exp_c8_costs_MOD, n * exp_c8_costs_MOD))
        for i, b in enumerate(blocks):
            W[i * exp_c8_costs_MOD:(i + 1) * exp_c8_costs_MOD, i * exp_c8_costs_MOD:(i + 1) * exp_c8_costs_MOD] = b
        starts = [i * exp_c8_costs_MOD for i in range(n)]
        ends = [(i + 1) * exp_c8_costs_MOD for i in range(n)]
        t0 = time.time()
        X = rc.run_reservoir_forced(W_in, W, data, exp_c8_costs_TRAIN_STEPS, 6000, 0.1,
                                    starts, ends)
        t_train = time.time() - t0
        t0 = time.time()
        for i in range(n):
            rc.ridge_readout(X[starts[i]:ends[i], -T:],
                             data[i][:, -T - 1:-1], 1e-5)
        t_block = time.time() - t0
        M = n * exp_c8_costs_MOD
        Yt = np.zeros((n * exp_c8_costs_N_OUT, T))
        t0 = time.time()
        rc.ridge_readout(X[:, -T:], Yt, 1e-5)
        t_global = time.time() - t0
        rows[n] = {"M_total": M, "train_s": t_train,
                   "readout_blockwise_s": t_block, "readout_global_s": t_global,
                   "train_ms_per_step": 1000 * t_train / exp_c8_costs_TRAIN_STEPS}
    return rows


def main_exp_c8_costs():
    out = {"analytic": analytic(), "timing": timing(),
           "hyperparameters": {
               "traditional_RC_per_task": ["alpha", "sigma", "d", "rho", "beta"],
               "traditional_RC_total": "5N",
               "MFRC": ["alpha", "beta", "sigma_i", "d_i", "rho_i"],
               "MFRC_total": "3N+2",
               "improved_single_RC": ["alpha", "beta", "sigma_i (N of them)",
                                      "d", "rho", "lambda"],
               "improved_single_RC_total": "N+5"},
           "optimizer": {
               "name": "MATLAB surrogateopt (surrogate-model based, NOT Bayesian optimization)",
               "max_function_evaluations": {"Opt/opt_RC_1.m": 200,
                                            "Opt_lorenz_hypersprottB/opt_RC_1.m": 200,
                                            "Opt_sel_lorenz_hyper_osc/opt_RC_1.m": 200,
                                            "Opt_sprottABCD/opt_RC_1.m": 300},
               "inner_repeats_per_evaluation": 10,
               "bounds": {"alpha": [0, 1], "W_in_a": [0, 3], "k": [1, 100],
                          "rho": [-3, 3], "reg": [1e-8, 1e-3]},
               "exp_c8_costs_objective": "sum over modules of the RMSE of a short closed-loop "
                            "rollout (errorLen = 500-5000 steps, module dependent) "
                            "evaluated on the first part of the SAME segment later "
                            "used as the reported test set",
               "total_objective_evaluations_per_run": "200-300 outer x 10 inner = "
                                                      "2000-3000 training+rollout runs"}}
    out_path = os.path.join(HERE, "results", "c8_costs.json")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as fh:
        json.dump(out, fh, indent=1)
    print("--- analytic readout cost ---")
    for n, r in out["analytic"].items():
        print("  N=%2d  M=%4d  blockwise=%.3e  global=%.3e  ratio=%.2f"
              % (n, r["M_total"], r["blockwise_readout_flops"],
                 r["global_readout_flops"], r["ratio"]))
    print("\n--- measured (single thread, 1e5-node modules, 60000 training steps) ---")
    for n, r in out["timing"].items():
        print("  N=%d  M=%4d  train=%6.2fs  block readout=%6.3fs  global readout=%6.3fs"
              % (n, r["M_total"], r["train_s"], r["readout_blockwise_s"],
                 r["readout_global_s"]))
    print("\nwritten %s" % out_path)


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    import sys
    _steps = [main_c8b_timing_protocol, main_c8c_optimization_cost, main_c8d_optimization_runs, main_c8h_uniform_budget, main_exp_c8_costs]
    if len(sys.argv) > 1:
        _steps[int(sys.argv[1])]()
    else:
        for _f in _steps:
            _f()
