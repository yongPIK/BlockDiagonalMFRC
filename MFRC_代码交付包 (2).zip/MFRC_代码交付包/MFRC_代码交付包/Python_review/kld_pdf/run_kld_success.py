"""Preliminary success criterion based on PDF similarity (KLD).

For each system and each random realization, this script:
  1. trains the released MFRC block-local readout and the released single-task RC;
  2. performs the corresponding closed-loop rollout;
  3. compares the x marginal PDF of the predicted trajectory with that of the
     corresponding true test segment;
  4. reports the directed KLDs and their symmetrized version.

MFRC protocol:
  joint drive length 60000, washout 6000, block-local readout trained on the
  system-specific tail window of length TRAINLEN_VEC[i].

RC protocol:
  released regress_RC_fractal.m convention: trainLen=50000, initLen=5000,
  rollout initialized at X(:,1).

This is a preliminary PDF-based comparison.  The KLD values depend on the
histogram range and bin count; the script therefore reports several tolerance
levels instead of hard-coding a single threshold.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(HERE)
sys.path.insert(0, CODE)

from mfrc import rc, systems  # noqa: E402

RC_TRAINLEN, RC_INITLEN = 50000, 5000


def _normalise_pdf(x, edges):
    """Histogram with modest Laplace smoothing, clipped to a common support."""
    x = np.asarray(x, dtype=float)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    x = np.clip(x, edges[0], edges[-1])
    counts, _ = np.histogram(x, bins=edges)
    counts = counts.astype(float) + 0.5
    return counts / counts.sum()


def _kld(p, q):
    """KL(p || q), natural logarithm."""
    return float(np.sum(p * np.log(p / q)))


def _pdf_similarity(x_true, x_pred, bins=60, span=1.05):
    """Directed and symmetrized KLD between two x-marginal PDFs."""
    edges = np.linspace(-span, span, bins + 1)
    p = _normalise_pdf(x_true, edges)
    q = _normalise_pdf(x_pred, edges)
    k_tp = _kld(p, q)
    k_pt = _kld(q, p)
    return {
        "kld_true_pred": k_tp,
        "kld_pred_true": k_pt,
        "kld_sym": 0.5 * (k_tp + k_pt),
    }


def _train_mfrc(i, rng):
    d = systems.load_normalized(i)
    sigma, k, rho = systems.PARA[i]
    W_in = rc.gene_Win(systems.RES_SIZE[i], systems.IN_SIZE[i], sigma, rng)
    W_r = rc.gene_Wr(systems.RES_SIZE[i], k, rho, rng)

    X = rc.run_reservoir_single(
        W_in, W_r, d, systems.TRAINLEN, systems.INITLEN, systems.ALPHA)
    L = systems.TRAINLEN_VEC[i]
    Yt = d[:, systems.TRAINLEN - L + 1: systems.TRAINLEN + 1]
    Wout = rc.ridge_readout(X[:, -L:], Yt, systems.REG)
    Y = rc.rollout_single(
        W_in, W_r, Wout, d, systems.TRAINLEN, systems.TESTLEN,
        systems.ALPHA, x_init=X[:, -1])
    true_x = d[0, systems.TRAINLEN + 1: systems.TRAINLEN + systems.TESTLEN + 1]
    return Y[0], true_x


def _train_rc(i, rng):
    d = systems.load_normalized(i)
    sigma, k, rho = systems.PARA[i]
    W_in = rc.gene_Win(systems.RES_SIZE[i], systems.IN_SIZE[i], sigma, rng)
    W_r = rc.gene_Wr(systems.RES_SIZE[i], k, rho, rng)

    X = rc.run_reservoir_single(
        W_in, W_r, d, RC_TRAINLEN, RC_INITLEN, systems.ALPHA)
    Yt = d[:, RC_INITLEN + 1: RC_TRAINLEN + 1]
    Wout = rc.ridge_readout(X, Yt, systems.REG)
    Y = rc.rollout_single(
        W_in, W_r, Wout, d, RC_TRAINLEN, systems.TESTLEN,
        systems.ALPHA, x_init=X[:, 0])
    true_x = d[0, RC_TRAINLEN + 1: RC_TRAINLEN + systems.TESTLEN + 1]
    return Y[0], true_x


def worker(task):
    i, seed, bins = task
    rng = np.random.default_rng(seed)
    try:
        y_m, t_m = _train_mfrc(i, rng)
        m = _pdf_similarity(t_m, y_m, bins=bins)
    except Exception as exc:  # keep one bad realization from killing the run
        m = {"error": repr(exc)}

    try:
        y_r, t_r = _train_rc(i, rng)
        r = _pdf_similarity(t_r, y_r, bins=bins)
    except Exception as exc:
        r = {"error": repr(exc)}
    return i, seed, m, r


def _finite(x):
    return bool(np.isfinite(x))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--systems", default="Lorenz",
                    help="comma-separated system names, or 'all'")
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--bins", type=int, default=60)
    ap.add_argument("--out", default="kld_results.json")
    args = ap.parse_args()

    if args.systems.strip().lower() == "all":
        idx = list(range(10))
    else:
        wanted = [s.strip() for s in args.systems.split(",") if s.strip()]
        idx = [systems.NAMES.index(s) for s in wanted]

    tasks = [(i, seed, args.bins) for i in idx for seed in range(args.n)]
    t0 = time.time()
    rows = []
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for done, (i, seed, m, r) in enumerate(pool.map(worker, tasks), 1):
            rows.append({"system": systems.NAMES[i], "seed": seed,
                         "MFRC": m, "RC": r})
            if done % max(1, len(idx)) == 0:
                print("%d/%d tasks (%.0f s)" % (done, len(tasks), time.time() - t0),
                      flush=True)

    summary = {}
    for i in idx:
        name = systems.NAMES[i]
        rs = [z for z in rows if z["system"] == name]
        summary[name] = {"n": len(rs), "MFRC": {}, "RC": {}}
        for arm in ("MFRC", "RC"):
            vals = np.array([z[arm].get("kld_sym", np.nan) for z in rs], float)
            finite = np.isfinite(vals)
            entry = {
                "finite_frac": float(finite.mean()),
                "kld_median": float(np.nanmedian(vals)),
                "kld_q25": float(np.nanpercentile(vals, 25)),
                "kld_q75": float(np.nanpercentile(vals, 75)),
                "kld_min": float(np.nanmin(vals)),
                "kld_max": float(np.nanmax(vals)),
            }
            for thr in (0.05, 0.10, 0.20, 0.30, 0.50):
                entry["success_%.2f" % thr] = float(np.mean(vals < thr))
            summary[name][arm] = entry

    out = {"systems": args.systems, "n_per_system": args.n, "bins": args.bins,
           "summary": summary, "rows": rows}
    with open(os.path.join(HERE, args.out), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    print("\nsystem       arm   median sym-KLD   eta@0.1  eta@0.2  eta@0.3  eta@0.5")
    for name in [systems.NAMES[i] for i in idx]:
        for arm in ("MFRC", "RC"):
            e = summary[name][arm]
            print("%-12s %-5s %14.4f %9.3f %8.3f %8.3f %8.3f"
                  % (name, arm, e["kld_median"], e["success_0.10"],
                     e["success_0.20"], e["success_0.30"], e["success_0.50"]))
    print("written:", os.path.join(HERE, args.out))


if __name__ == "__main__":
    main()
