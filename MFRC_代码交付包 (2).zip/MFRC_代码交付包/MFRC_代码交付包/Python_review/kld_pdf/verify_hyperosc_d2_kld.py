"""Compare Table-III-style D2 and PDF/KLD results on the same HyperOsc rollouts.

This checks whether the Table III success rate of HyperOsc-RC (0.470) comes
from the RC rollout itself or from a different protocol/parameter setting.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor

import numpy as np
from numba import njit

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(HERE)
sys.path.insert(0, CODE)

from mfrc import rc, systems  # noqa: E402

RC_TRAINLEN, RC_INITLEN = 50000, 5000


@njit(cache=True, fastmath=True)
def _forced_reservoir_jit(W_in, W, dataT, trainLen, initLen, a):
    """Teacher-forced RC pass, matching mfrc.rc.run_reservoir_single."""
    n = W.shape[0]
    X = np.empty((n, trainLen - initLen), dtype=np.float64)
    x = np.zeros(n, dtype=np.float64)
    for t in range(trainLen):
        x = (1.0 - a) * x + a * np.tanh(W_in @ dataT[t] + W @ x)
        if t >= initLen:
            X[:, t - initLen] = x
    return X


@njit(cache=True, fastmath=True)
def _rollout_jit(W_in, W, Wout, data, trainLen, testLen, a, x0, u0):
    """Generative RC rollout, matching mfrc.rc.rollout_single."""
    out_dim = Wout.shape[0]
    Y = np.empty((out_dim, testLen), dtype=np.float64)
    x = x0.copy()
    u = u0.copy()
    for t in range(testLen):
        x = (1.0 - a) * x + a * np.tanh(W_in @ u + W @ x)
        u = Wout @ x
        Y[:, t] = u
    return Y


@njit(cache=True, fastmath=True)
def _gp_counts_jit(Y, radii):
    """Pairwise-distance counts for the released Grassberger-Procaccia estimator."""
    N = Y.shape[0]
    nr = radii.shape[0]
    counts = np.zeros(nr, dtype=np.int64)
    for i in range(N - 1):
        for j in range(i + 1, N):
            d2 = 0.0
            for k in range(Y.shape[1]):
                dv = Y[i, k] - Y[j, k]
                d2 += dv * dv
            d = np.sqrt(d2)
            for k in range(nr):
                if d < radii[k]:
                    counts[k] += 1
    return counts


def _gp_released_jit(Y, r_min=1e-2, r_max=1.0, n_r=20, log_floor=-10.0):
    """Same result as mfrc.gp.gp_released, with a JIT pair-counting kernel."""
    Y = np.asarray(Y, dtype=np.float64)
    radii = np.logspace(np.log10(r_min), np.log10(r_max), n_r)
    counts = _gp_counts_jit(Y, radii)
    # The released MATLAB estimator counts all ordered pairs, including i=j;
    # thus the unordered i<j counts must be doubled and the N self-pairs added.
    counts = 2 * counts + Y.shape[0]
    C = counts / (Y.shape[0] * (Y.shape[0] - 1))
    with np.errstate(divide="ignore", invalid="ignore"):
        log_C = np.log(C)
    valid = np.isfinite(log_C) & (log_C > log_floor)
    if valid.sum() < 2:
        return np.nan
    return float(np.polyfit(np.log(radii[valid]), log_C[valid], 1)[0])


def _traj_mfrc(i, rng):
    d = systems.load_normalized(i)
    sigma, k, rho = systems.PARA[i]
    W_in = rc.gene_Win(systems.RES_SIZE[i], systems.IN_SIZE[i], sigma, rng)
    W_r = rc.gene_Wr(systems.RES_SIZE[i], k, rho, rng)
    X = _forced_reservoir_jit(
        W_in, W_r, np.ascontiguousarray(d.T), systems.TRAINLEN,
        systems.INITLEN, systems.ALPHA)
    L = systems.TRAINLEN_VEC[i]
    Yt = d[:, systems.TRAINLEN - L + 1: systems.TRAINLEN + 1]
    Wout = rc.ridge_readout(X[:, -L:], Yt, systems.REG)
    Y = _rollout_jit(
        W_in, W_r, Wout, np.ascontiguousarray(d), systems.TRAINLEN,
        systems.TESTLEN, systems.ALPHA, X[:, -1].copy(),
        d[:, systems.TRAINLEN].copy())
    Yt_true = d[:, systems.TRAINLEN + 1: systems.TRAINLEN + systems.TESTLEN + 1]
    return Y, Yt_true


def _traj_rc(i, rng, trainlen=RC_TRAINLEN, initlen=RC_INITLEN,
             ressize=None):
    d = systems.load_normalized(i)
    sigma, k, rho = systems.PARA[i]
    n = systems.RES_SIZE[i] if ressize is None else ressize
    W_in = rc.gene_Win(n, systems.IN_SIZE[i], sigma, rng)
    W_r = rc.gene_Wr(n, k, rho, rng)
    X = _forced_reservoir_jit(
        W_in, W_r, np.ascontiguousarray(d.T), trainlen, initlen, systems.ALPHA)
    Yt = d[:, initlen + 1: trainlen + 1]
    Wout = rc.ridge_readout(X, Yt, systems.REG)
    Y = _rollout_jit(
        W_in, W_r, Wout, np.ascontiguousarray(d), trainlen, systems.TESTLEN,
        systems.ALPHA, X[:, 0].copy(), d[:, trainlen].copy())
    Yt_true = d[:, trainlen + 1: trainlen + systems.TESTLEN + 1]
    return Y, Yt_true


def _metrics(Y, Yt_true):
    d2_true = _gp_released_jit(np.ascontiguousarray(Yt_true.T[0::10]))
    d2_pred = _gp_released_jit(np.ascontiguousarray(Y.T[0::10]))
    # x-marginal symmetric KLD, same binning as run_kld_success.py
    edges = np.linspace(-1.05, 1.05, 61)

    def pdf(x):
        x = np.nan_to_num(np.asarray(x, float), nan=0.0,
                          posinf=0.0, neginf=0.0)
        x = np.clip(x, edges[0], edges[-1])
        c, _ = np.histogram(x, bins=edges)
        c = c.astype(float) + 0.5
        return c / c.sum()

    p = pdf(Yt_true[0])
    q = pdf(Y[0])
    k_tp = float(np.sum(p * np.log(p / q)))
    k_pt = float(np.sum(q * np.log(q / p)))
    return {"d2_true": d2_true, "d2_pred": d2_pred,
            "d2_rel": float(abs(d2_pred - d2_true) / abs(d2_true)),
            "kld_x": 0.5 * (k_tp + k_pt)}


def worker(task):
    system_name, arm, seed, ressize, trainlen, initlen = task
    rng = np.random.default_rng(seed)
    i = systems.NAMES.index(system_name)
    if arm == "MFRC":
        Y, Yt = _traj_mfrc(i, rng)
    else:
        Y, Yt = _traj_rc(i, rng, trainlen=trainlen, initlen=initlen,
                          ressize=ressize)
    return system_name, arm, seed, _metrics(Y, Yt)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", default="HyperOsc")
    ap.add_argument("--n", type=int, default=50)
    ap.add_argument("--jobs", type=int, default=16)
    ap.add_argument("--configs", default="all",
                    help="comma-separated labels, or all")
    ap.add_argument("--out", default="hyperosc_d2_kld_verify.json")
    args = ap.parse_args()

    configs = [
        ("MFRC", None, None, None),
        ("RC-500-50000", 500, 50000, 5000),
        ("RC-100-50000", 100, 50000, 5000),
        ("RC-500-10000", 500, 10000, 1000),
        ("RC-100-10000", 100, 10000, 1000),
    ]
    if args.configs.strip().lower() != "all":
        wanted = {s.strip() for s in args.configs.split(",") if s.strip()}
        configs = [c for c in configs if c[0] in wanted]
        if not configs:
            raise SystemExit("no matching configs")
    if args.system not in systems.NAMES:
        raise SystemExit("unknown system: %s" % args.system)
    tasks = []
    for arm, ressize, trainlen, initlen in configs:
        for seed in range(args.n):
            tasks.append((args.system, arm, seed, ressize, trainlen, initlen))

    t0 = time.time()
    rows = []
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for done, (system_name, arm, seed, m) in enumerate(pool.map(worker, tasks), 1):
            rows.append({"system": system_name, "arm": arm, "seed": seed, **m})
            if done % 50 == 0:
                print("%d/%d (%.0f s)" % (done, len(tasks), time.time() - t0),
                      flush=True)

    summary = {}
    for arm, _, _, _ in configs:
        rs = [z for z in rows if z["arm"] == arm]
        d2 = np.array([z["d2_rel"] for z in rs])
        kl = np.array([z["kld_x"] for z in rs])
        summary[arm] = {
            "n": len(rs),
            "d2_success_0.20": float((d2 < 0.20).mean()),
            "d2_median_rel": float(np.median(d2)),
            "kld_success_0.20": float((kl < 0.20).mean()),
            "kld_median": float(np.median(kl)),
            "d2_pred_median": float(np.median([z["d2_pred"] for z in rs])),
            "d2_true_median": float(np.median([z["d2_true"] for z in rs])),
        }
    out = {"system": args.system, "n": args.n, "summary": summary, "rows": rows}
    with open(os.path.join(HERE, args.out), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    print("\n%s arm       D2 eta@0.20  D2 med rel  KLD eta@0.20  KLD median  D2pred med  D2true med"
          % args.system)
    for arm, _, _, _ in configs:
        e = summary[arm]
        print("%-16s %11.3f %11.3f %12.3f %11.4f %11.3f %11.3f"
              % (arm, e["d2_success_0.20"], e["d2_median_rel"],
                 e["kld_success_0.20"], e["kld_median"],
                 e["d2_pred_median"], e["d2_true_median"]))
    print("written:", os.path.join(HERE, args.out))


if __name__ == "__main__":
    main()
