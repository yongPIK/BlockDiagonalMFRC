"""HyperOsc KLD check with the Table-3 RC protocol: trainLen=10000, initLen=1000.

The MFRC arm remains at the released block protocol (trainLen=60000,
initLen=6000, readout window 10000).  The RC arm uses resSize=500 and the
same generative rollout, but trainLen=10000 and initLen=1000.

Run:
    python run_kld_hyperosc_rc10000.py --n 500 --jobs 4
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from verify_hyperosc_d2_kld import _metrics, _traj_mfrc, _traj_rc  # noqa: E402
from mfrc import systems  # noqa: E402


def worker(task):
    seed = task
    i = systems.NAMES.index("HyperOsc")
    rng = np.random.default_rng(seed)

    Ym, Ytm = _traj_mfrc(i, rng)
    m = _metrics(Ym, Ytm)

    Yr, Ytr = _traj_rc(i, rng, trainlen=10000, initlen=1000, ressize=500)
    r = _metrics(Yr, Ytr)
    return seed, m, r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--out", default="hyperosc_kld_rc10000_n500.json")
    args = ap.parse_args()

    t0 = time.time()
    rows = []
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for done, (seed, m, r) in enumerate(pool.map(worker, range(args.n)), 1):
            rows.append({"seed": seed, "MFRC": m, "RC_10000_1000": r})
            if done % 50 == 0:
                print("%d/%d (%.0f s)" % (done, args.n, time.time() - t0),
                      flush=True)

    out = {"system": "HyperOsc", "n": args.n,
           "settings": {
               "MFRC": {"trainLen": 60000, "initLen": 6000},
               "RC": {"trainLen": 10000, "initLen": 1000, "resSize": 500},
           },
           "rows": rows, "summary": {}}

    for arm in ("MFRC", "RC_10000_1000"):
        k = np.array([z[arm]["kld_x"] for z in rows], float)
        e = {"n": len(k), "kld_median": float(np.median(k)),
             "kld_q25": float(np.percentile(k, 25)),
             "kld_q75": float(np.percentile(k, 75))}
        for thr in (0.10, 0.20, 0.30, 0.50):
            e["success_%.2f" % thr] = float((k < thr).mean())
        out["summary"][arm] = e

    path = os.path.join(HERE, args.out)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    print("\nHyperOsc KLD with RC trainLen=10000, initLen=1000")
    for arm in ("MFRC", "RC_10000_1000"):
        e = out["summary"][arm]
        print("%-16s median=%.4f  eta@0.10=%.3f  eta@0.20=%.3f  "
              "eta@0.30=%.3f  eta@0.50=%.3f"
              % (arm, e["kld_median"], e["success_0.10"],
                 e["success_0.20"], e["success_0.30"], e["success_0.50"]))
    print("written:", path)


if __name__ == "__main__":
    main()
