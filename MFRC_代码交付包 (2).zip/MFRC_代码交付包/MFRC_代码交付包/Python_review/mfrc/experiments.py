"""Single-realization experiment drivers used by all C1..C10 computations."""

import numpy as np

from . import gp, rc, systems


def build_matrices(rng):
    """Build the ten (W_in, W_r) pairs in the same order as the MATLAB scripts."""
    W_in, W_r = [], []
    for i in range(10):
        sigma, k, rho = systems.PARA[i]
        n = systems.RES_SIZE[i]
        W_in.append(rc.gene_Win(n, systems.IN_SIZE[i], sigma, rng))
        W_r.append(rc.gene_Wr(n, k, rho, rng))
    return W_in, W_r


def block_slices():
    starts = np.cumsum([0] + systems.RES_SIZE[:-1])
    ends = np.cumsum(systems.RES_SIZE)
    in_starts = np.cumsum([0] + systems.IN_SIZE[:-1])
    in_ends = np.cumsum(systems.IN_SIZE)
    return starts, ends, in_starts, in_ends


def block_diag(blocks):
    M = sum(b.shape[0] for b in blocks)
    W = np.zeros((M, M))
    s = 0
    for b in blocks:
        W[s:s + b.shape[0], s:s + b.shape[0]] = b
        s += b.shape[0]
    return W


def train_joint(W_in, W_r, data_list, trainLen=systems.TRAINLEN,
                initLen=systems.INITLEN, a=systems.ALPHA):
    """Run the MFRC exactly as multi_regress_RC_10sys_fractaldim.m does."""
    W = block_diag(W_r)
    X = rc.run_reservoir_forced(W_in, W, data_list, trainLen, initLen, a,
                                *block_slices()[:2])
    return X, W


def readouts_blockwise(X, data_list, res_starts, res_ends):
    Wout = []
    for i in range(10):
        L = systems.TRAINLEN_VEC[i]
        seg = X[res_starts[i]:res_ends[i], -L:]
        Yt = data_list[i][:, systems.TRAINLEN - L + 1: systems.TRAINLEN + 1]
        Wout.append(rc.ridge_readout(seg, Yt, systems.REG))
    return Wout


def truth_d2(data_list, gap=10):
    return np.array([gp.gp_released(
        data_list[i][:, systems.TRAINLEN + 1: systems.TRAINLEN + systems.TESTLEN + 1]
        .T[0::gap])[0] for i in range(10)])


def realization_blocklocal(seed, gap=10, test_len=systems.TESTLEN, joint=True):
    """One realization of the released MFRC protocol (block-diagonal, block-local
    readout and feedback). Returns (d2_pred, d2_true, diagnostics)."""
    rng = np.random.default_rng(seed)
    data_list = systems.load_all()
    W_in, W_r = build_matrices(rng)
    res_starts, res_ends, in_starts, in_ends = block_slices()

    if joint:
        X, W = train_joint(W_in, W_r, data_list)
    else:
        X = np.zeros((sum(systems.RES_SIZE), systems.TRAINLEN - systems.INITLEN))
        for i in range(10):
            Xi = rc.run_reservoir_single(W_in[i], W_r[i], data_list[i],
                                         systems.TRAINLEN, systems.INITLEN, systems.ALPHA)
            X[res_starts[i]:res_ends[i]] = Xi
        W = block_diag(W_r)

    Wout = readouts_blockwise(X, data_list, res_starts, res_ends)

    d2_pred = np.zeros(10)
    d2_true = np.zeros(10)
    for i in range(10):
        if joint:
            Y = rc.rollout_block_local(W_in, W, Wout, data_list, systems.TRAINLEN,
                                       test_len, systems.ALPHA, res_starts, res_ends,
                                       in_starts, in_ends, i,
                                       x_init=X[:, -1],
                                       u_init=np.concatenate(
                                           [d[:, systems.TRAINLEN] for d in data_list]))
        else:
            # factorized, mathematically identical (proved in exp_c1)
            Y = rc.rollout_single(W_in[i], W_r[i], Wout[i], data_list[i],
                                  systems.TRAINLEN, test_len, systems.ALPHA,
                                  x_init=X[res_starts[i]:res_ends[i], -1])
        d2_pred[i] = gp.gp_released(Y.T[0::gap])[0]
        d2_true[i] = gp.gp_released(
            data_list[i][:, systems.TRAINLEN + 1: systems.TRAINLEN + test_len + 1]
            .T[0::gap])[0]
    return d2_pred, d2_true


def realization_standalone_paired(seed, gap=10):
    """Standalone RC for each system with exactly the same W_in, W_r, window,
    initial state and readout as the corresponding MFRC block."""
    rng = np.random.default_rng(seed)
    data_list = systems.load_all()
    W_in, W_r = build_matrices(rng)
    res_starts, res_ends, _, _ = block_slices()
    d2_pred = np.zeros(10)
    d2_true = np.zeros(10)
    for i in range(10):
        Xi = rc.run_reservoir_single(W_in[i], W_r[i], data_list[i],
                                     systems.TRAINLEN, systems.INITLEN, systems.ALPHA)
        L = systems.TRAINLEN_VEC[i]
        Yt = data_list[i][:, systems.TRAINLEN - L + 1: systems.TRAINLEN + 1]
        Wout = rc.ridge_readout(Xi[:, -L:], Yt, systems.REG)
        Y = rc.rollout_single(W_in[i], W_r[i], Wout, data_list[i], systems.TRAINLEN,
                              systems.TESTLEN, systems.ALPHA, x_init=Xi[:, -1])
        d2_pred[i] = gp.gp_released(Y.T[0::gap])[0]
        d2_true[i] = gp.gp_released(
            data_list[i][:, systems.TRAINLEN + 1: systems.TRAINLEN + systems.TESTLEN + 1]
            .T[0::gap])[0]
    return d2_pred, d2_true


def realization_standalone_published_protocol(seed, i, variant="ic_bug",
                                              gap=10, trainLen=50000, initLen=5000):
    """Emulate the released regress_RC_fractal.m protocol for system i.

    variant='paired'  : matched window/IC   (reference)
    variant='ic_bug'  : rollout starts from X(:,1) as in the released script
    variant='window'  : own window (trainLen/initLen) + X(:,1) + u=data(:,trainLen+1)
    """
    rng = np.random.default_rng(seed)
    data_list = systems.load_all()
    W_in, W_r = build_matrices(rng)
    d = data_list[i]

    if variant == "paired":
        Xi = rc.run_reservoir_single(W_in[i], W_r[i], d, systems.TRAINLEN,
                                     systems.INITLEN, systems.ALPHA)
        L = systems.TRAINLEN_VEC[i]
        Yt = d[:, systems.TRAINLEN - L + 1: systems.TRAINLEN + 1]
        Wout = rc.ridge_readout(Xi[:, -L:], Yt, systems.REG)
        Y = rc.rollout_single(W_in[i], W_r[i], Wout, d, systems.TRAINLEN,
                              systems.TESTLEN, systems.ALPHA, x_init=Xi[:, -1])
        Yt_true = d[:, systems.TRAINLEN + 1: systems.TRAINLEN + systems.TESTLEN + 1]
    elif variant == "ic_bug":
        Xi = rc.run_reservoir_single(W_in[i], W_r[i], d, systems.TRAINLEN,
                                     systems.INITLEN, systems.ALPHA)
        L = systems.TRAINLEN_VEC[i]
        Yt = d[:, systems.TRAINLEN - L + 1: systems.TRAINLEN + 1]
        Wout = rc.ridge_readout(Xi[:, -L:], Yt, systems.REG)
        Y = rc.rollout_single(W_in[i], W_r[i], Wout, d, systems.TRAINLEN,
                              systems.TESTLEN, systems.ALPHA, x_init=Xi[:, 0])
        Yt_true = d[:, systems.TRAINLEN + 1: systems.TRAINLEN + systems.TESTLEN + 1]
    elif variant == "window":
        Xi = rc.run_reservoir_single(W_in[i], W_r[i], d, trainLen, initLen, systems.ALPHA)
        Yt = d[:, initLen + 1: trainLen + 1]
        Wout = rc.ridge_readout(Xi, Yt, systems.REG)
        Y = rc.rollout_single(W_in[i], W_r[i], Wout, d, trainLen, systems.TESTLEN,
                              systems.ALPHA, x_init=Xi[:, 0])
        Yt_true = d[:, trainLen + 1: trainLen + systems.TESTLEN + 1]
    else:
        raise ValueError(variant)
    return (gp.gp_released(Y.T[0::gap])[0], gp.gp_released(Yt_true.T[0::gap])[0])
