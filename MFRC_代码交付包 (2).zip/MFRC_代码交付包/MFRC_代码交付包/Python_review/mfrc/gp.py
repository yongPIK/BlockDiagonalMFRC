"""Grassberger-Procaccia correlation dimension, replicating the released
Grassberger_Procaccia.m *including* its simplifications, plus a corrected variant.

Released version:
    r_values = logspace(-2, 0, 20)
    C(r) = 2 * #{||Y_i - Y_j|| < r} / (N (N-1))
    one global linear fit over all r with log C > -10   (no Theiler window,
    no scaling-region selection)
"""

import numpy as np


def _correlation_integral(Y, radii, theiler=0):
    N = Y.shape[0]
    C = np.zeros(len(radii))
    chunk = 512
    counts = np.zeros(len(radii), dtype=np.int64)
    for s in range(0, N, chunk):
        e = min(s + chunk, N)
        d = np.linalg.norm(Y[s:e, None, :] - Y[None, :, :], axis=2)
        for k, r in enumerate(radii):
            mask = d < r
            if theiler > 0:
                idx = np.arange(s, e)
                mask &= np.abs(idx[:, None] - np.arange(N)[None, :]) > theiler
            counts[k] += mask.sum()
    # each unordered pair counted twice (i->j and j->i)
    C = counts / (N * (N - 1))
    return C


def gp_released(Y, r_min=1e-2, r_max=1.0, n_r=20, log_floor=-10.0):
    """Exact port of the published Grassberger_Procaccia.m."""
    Y = np.asarray(Y, dtype=np.float64)
    radii = np.logspace(np.log10(r_min), np.log10(r_max), n_r)
    C = _correlation_integral(Y, radii)
    with np.errstate(divide="ignore", invalid="ignore"):
        log_r = np.log(radii)
        log_C = np.log(C)
    valid = np.isfinite(log_C) & (log_C > log_floor)
    if valid.sum() < 2:
        return np.nan, radii, C
    slope = np.polyfit(log_r[valid], log_C[valid], 1)[0]
    return slope, radii, C


def gp_corrected(Y, theiler=None, r_min=1e-2, r_max=1.0, n_r=40,
                 fit_frac=(0.15, 0.75), log_floor=-12.0):
    """Corrected estimator: Theiler window + automatic scaling-region selection.

    Radii are chosen from the actual pairwise-distance distribution (log spaced
    between the 1st and 60th percentile of distances), and the fit window keeps
    the region where the local slope is most stable (plateau of the derivative
    of log C vs log r).
    """
    Y = np.asarray(Y, dtype=np.float64)
    N = Y.shape[0]
    # reference distance scale from a subsample (avoids a second N^2 pass)
    sub = Y[:: max(1, N // 500)]
    dsub = np.linalg.norm(sub[:, None, :] - sub[None, :, :], axis=2)
    dsub = dsub[np.triu_indices(len(sub), 1)]
    dsub = dsub[dsub > 0]
    r_min = np.percentile(dsub, 1.0)
    r_max = np.percentile(dsub, 60.0)
    radii = np.logspace(np.log10(r_min), np.log10(r_max), n_r)
    if theiler is None:
        theiler = max(1, N // 10)
    C = _correlation_integral(Y, radii, theiler=theiler)
    with np.errstate(divide="ignore", invalid="ignore"):
        log_r = np.log(radii)
        log_C = np.log(C)
    ok = np.isfinite(log_C) & (log_C > log_floor)
    log_r, log_C = log_r[ok], log_C[ok]
    if len(log_r) < 8:
        return np.nan
    # local slope, then pick the longest window whose slope stays within 5% of
    # the median slope over the middle of the curve
    slopes = np.diff(log_C) / np.diff(log_r)
    mid = slopes[int(0.2 * len(slopes)):int(0.8 * len(slopes))]
    ref = np.median(mid)
    good = np.abs(slopes - ref) < 0.05 * max(abs(ref), 1e-9)
    best = (0, 0)
    i = 0
    while i < len(good):
        if good[i]:
            j = i
            while j + 1 < len(good) and good[j + 1]:
                j += 1
            if j - i > best[1] - best[0]:
                best = (i, j)
            i = j + 1
        else:
            i += 1
    i, j = best
    if j - i < 2:
        i, j = int(fit_frac[0] * len(log_r)), int(fit_frac[1] * len(log_r))
    return np.polyfit(log_r[i:j + 2], log_C[i:j + 2], 1)[0]


def nrmse(true, pred):
    return float(np.sqrt(np.mean((true - pred) ** 2)) / np.sqrt(np.mean(true ** 2)))


def valid_time(true, pred, threshold=0.3):
    """Number of steps until the normalized error first exceeds `threshold`."""
    rms = np.sqrt(np.mean(true ** 2, axis=1).sum())
    err = np.linalg.norm(pred - true, axis=0) / rms
    idx = np.where(err > threshold)[0]
    return int(idx[0]) if len(idx) else pred.shape[1]


def max_lyapunov(data, dt=0.01, m=3, tau=5, kmax=1200, n_ref=300, theiler=20,
                 seed=0, fit=(0.5, 2.0)):
    """Rosenstein maximal Lyapunov exponent from a scalar time series.

    Defaults are calibrated on the Lorenz system (reference lambda1 = 0.906):
    tau = 5 steps, fit over t in [0.5, 2.0] time units -> 0.864-0.92.
    """
    rng = np.random.default_rng(seed)
    x = np.asarray(data, dtype=np.float64).ravel()
    N = len(x)
    M = N - (m - 1) * tau
    if M < 200:
        return np.nan
    V = np.stack([x[i * tau: i * tau + M] for i in range(m)], axis=1)
    idx = rng.choice(M, size=min(n_ref, M), replace=False)
    div = np.zeros(kmax)
    cnt = np.zeros(kmax)
    for i in idx:
        d = np.linalg.norm(V - V[i], axis=1)
        d[max(0, i - theiler): i + theiler + 1] = np.inf
        j = int(np.argmin(d))
        if not np.isfinite(d[j]):
            continue
        for k in range(kmax):
            if i + k >= M or j + k >= M:
                break
            div[k] += np.log(max(np.linalg.norm(V[i + k] - V[j + k]), 1e-12))
            cnt[k] += 1
    S = np.full(kmax, np.nan)
    ok = cnt > 0
    S[ok] = div[ok] / cnt[ok]
    t = np.arange(kmax) * dt
    sel = ok & (t >= fit[0]) & (t <= fit[1]) & np.isfinite(S)
    if sel.sum() < 5:
        return np.nan
    return float(np.polyfit(t[sel], S[sel], 1)[0])
