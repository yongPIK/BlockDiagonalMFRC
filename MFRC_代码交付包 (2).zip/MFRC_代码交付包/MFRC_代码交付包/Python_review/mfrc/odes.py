"""ODE definitions for the ten benchmark systems (taken from our own validated
time-series generator) plus a fixed-step Dormand-Prince 5(4) integrator for the
solver-robustness test.
"""

import numpy as np


def sprott_a(y, b=1.0):
    return np.array([y[1], y[1] * y[2] - y[0], b - y[1] ** 2])


def sprott_b(y, b=1.0):
    return np.array([y[1] * y[2], y[0] - y[1], b - y[0] * y[1]])


def sprott_c(y, b=1.0):
    return np.array([y[1] * y[2], y[0] - y[1], b - y[0] ** 2])


def sprott_d(y, b=3.0):
    return np.array([-y[1], y[0] + y[2], y[0] * y[2] + b * y[1] ** 2])


def lorenz(y, a=10.0, b=28.0, c=8.0 / 3.0):
    return np.array([a * (y[1] - y[0]), y[0] * (b - y[2]) - y[1],
                     y[0] * y[1] - c * y[2]])


def roessler_paper(y):
    """5x-time-scaled Rossler exactly as in the MFRC appendix."""
    return np.array([-5 * y[1] - 5 * y[2], 5 * y[0] + 2.5 * y[1],
                     10 + 5 * y[2] * (y[0] - 4)])


def chen_mfrc(y, a=40.0, b=3.0, c=28.0):
    return np.array([a * (y[1] - y[0]),
                     (c - a) * y[0] - y[0] * y[2] + c * y[1],
                     y[0] * y[1] - b * y[2]])


def selkov(y, a=0.08, b=0.6):
    return np.array([-y[0] + a * y[1] + y[0] ** 2 * y[1],
                     b - a * y[1] - y[0] ** 2 * y[1]])


def laarem(y):
    x, y1, z, w = y
    return np.array([-y1 - z + w,
                     x + 0.1 * y1 - z,
                     0.1 + z * (x - 14) - 20 * x * w,
                     -x * y1 - 0.28 * w])


def hypersprottb(y):
    x, y1, z, u, v = y
    return np.array([x * z - v, x - y1 - u, 1 - x * y1, 0.01 * x + y1, x])


# name -> (rhs, initial condition, burn-in steps at dt=0.01)
CATALOG = {
    "SprottA": (sprott_a, (0.33041, 0.94601, 0.59004), 2000),
    "SprottB": (sprott_b, (0.96078, 0.36423, 0.0045435), 2000),
    "SprottC": (sprott_c, (0.52353, 0.97085, 0.43866), 2000),
    "SprottD": (sprott_d, (-3.8516, -1.1081, 0.45564), 2000),
    "Lorenz": (lorenz, (0.0, 1.0, 0.0), 0),
    "Roessler": (roessler_paper, (0.037366, 0.45429, 0.3693), 2000),
    "Chen": (chen_mfrc, (0.74551, 0.7947, 0.63255), 2000),
    "Selkov": (selkov, (0.5, 0.5), 2000),
    "HyperOsc": (laarem, (0.30065, 0.67752, 0.87283, 0.87877), 2000),
    "HyperSprottB": (hypersprottb,
                     (0.2785, 0.54688, 0.95751, 0.96489, 0.15761), 2000),
}


def rk4_step(f, y, dt, args=()):
    k1 = f(y, *args)
    k2 = f(y + dt / 2 * k1, *args)
    k3 = f(y + dt / 2 * k2, *args)
    k4 = f(y + dt * k3, *args)
    return y + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)


# Dormand-Prince 5(4) coefficients
_DP_C = [0, 1 / 5, 3 / 10, 4 / 5, 8 / 9, 1.0, 1.0]
_DP_A = [
    [],
    [1 / 5],
    [3 / 40, 9 / 40],
    [44 / 45, -56 / 15, 32 / 9],
    [19372 / 6561, -25360 / 2187, 64448 / 6561, -212 / 729],
    [9017 / 3168, -355 / 33, 46732 / 5247, 49 / 176, -5103 / 18656],
    [35 / 384, 0, 500 / 1113, 125 / 192, -2187 / 6784, 11 / 84],
]
_DP_B = [35 / 384, 0, 500 / 1113, 125 / 192, -2187 / 6784, 11 / 84, 0]


def dopri5_step(f, y, dt, args=()):
    ks = []
    for i, c in enumerate(_DP_C):
        yi = y.copy()
        for j, aij in enumerate(_DP_A[i]):
            yi = yi + dt * aij * ks[j]
        ks.append(f(yi, *args))
    out = y.copy()
    for i, b in enumerate(_DP_B):
        out = out + dt * b * ks[i]
    return out


def integrate(name, dt=0.01, n=100001, method="rk4", burn=None):
    """Return (n, dim) trajectory sampled at step dt (burn-in discarded)."""
    f, ic, burn_default = CATALOG[name]
    burn = burn_default if burn is None else burn
    y = np.array(ic, dtype=float)
    burn_steps = int(round(burn * 0.01 / dt))
    out = np.empty((n, y.size))
    step = rk4_step if method == "rk4" else dopri5_step
    for _ in range(burn_steps):
        y = step(f, y, dt)
    for i in range(n):
        out[i] = y
        y = step(f, y, dt)
    return out
