"""System definitions shared by all experiment scripts."""

import os
import numpy as np

from . import rc

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG_DATA = os.path.join(os.path.dirname(os.path.dirname(_HERE)), "Data", "TimeSeries")
MFRC_DIR = _PKG_DATA if os.path.isdir(_PKG_DATA) else r"C:\Users\KevinJiang\Desktop\MFRC"
CACHE = os.path.join(os.path.dirname(_HERE), "cache")
os.makedirs(CACHE, exist_ok=True)   # created on demand; not shipped with the package

# order used everywhere in the paper (Table III, Fig. 7)
NAMES = ["SprottA", "SprottB", "SprottC", "SprottD", "Lorenz", "Roessler",
         "Chen", "Selkov", "HyperOsc", "HyperSprottB"]

FILES = ["data_SprottA_2000_0.01.dat", "data_SprottB_2000_0.01.dat",
         "data_SprottC_2000_0.01.dat", "data_SprottD_2000_0.01.dat",
         "data_Lorenz.dat", "data_roessler2_1000_0.01.dat",
         "data_chen_1000_0.01.dat", "data_sel_kov_1000_0.01.dat",
         "data_hyperchaotic_oscillator_1000_0.01.dat",
         "data_hyper_sprottB_1000_0.01.dat"]

IN_SIZE = [3, 3, 3, 3, 3, 3, 3, 2, 4, 5]
OUT_SIZE = IN_SIZE[:]
RES_SIZE = [100] * 8 + [500, 500]

# Table II values (W_in_a, k, eig_rho) straight out of the para vector
PARA = [
    (0.166903974271684, 59.1510248401282, -2.82953128218694),
    (0.524801417382458, 2.80696270207184, 2.72180624436781),
    (0.287709384851287, 74.0972678053068, 1.97938743778260),
    (1.03375020271522, 1.0, 3.0),
    (2.81262506997391, 94.9666913419282, -0.730966611140523),
    (0.958860215120228, 1.02505593204508, 2.70376617790837),
    (2.88942563792231, 6.20808716642222, -0.0376176384094279),
    (2.23394122119754, 24.5498565590683, -0.00227173616567419),
    (0.299007202733509, 171.705780833805, -1.21189202441243),
    (0.125746762061917, 405.335058731385, 1.53843634290604),
]

TRAINLEN_VEC = [50000, 20000, 20000, 40000, 5000, 10000, 3000, 5000, 10000, 50000]
TRAINLEN = 60000
TESTLEN = 30000
INITLEN = 6000
ALPHA = 0.1
REG = 1e-5


def load_normalized(i):
    """Load system i exactly like the MATLAB scripts do (transpose + max-abs scaling)."""
    npz = os.path.join(CACHE, "sys_%s.npy" % NAMES[i])
    if os.path.exists(npz):
        try:
            data = np.load(npz)
            if data.size:
                return data
        except Exception:
            pass                      # corrupt or empty cache -> rebuild below
    data = np.loadtxt(os.path.join(MFRC_DIR, FILES[i])).T
    data = rc.normalize(data)
    np.save(npz, data)
    return data


def load_all():
    return [load_normalized(i) for i in range(10)]


def real_true_d2(data_list, i, trainLen=TRAINLEN, testLen=TESTLEN, gap=10):
    Y = data_list[i][:, trainLen + 1: trainLen + testLen + 1].T
    return Y[0::gap]
