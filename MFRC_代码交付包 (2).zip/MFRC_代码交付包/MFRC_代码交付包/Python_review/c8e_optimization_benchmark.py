"""Benchmark definition used by the equal-budget optimisation comparison.

Protocol of the released MFRC implementation: one reservoir module per task
with 100 nodes, trainLen = 60000 (the first initLen = 6000 steps are dropped),
testLen = 10000, leakage alpha = 0.1, ridge coefficient beta = 1e-5.
The three parameters optimised per module are [sigma, d, rho].
"""

from mfrc import systems

NAMES = systems.NAMES

# search range of the surrogate search (sigma, d, rho)
BOUNDS = ((0.0, 3.0), (1.0, 100.0), (-3.0, 3.0))

RES = 100
TRAINLEN, INITLEN, TESTLEN = 60000, 6000, 10000
ALPHA, REG = 0.1, 1e-5
