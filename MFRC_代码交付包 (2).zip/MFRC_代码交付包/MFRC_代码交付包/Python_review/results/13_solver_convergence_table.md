# R1-8 solver / time-step convergence (RK4, dt=0.01 against the near-exact reference dt=0.001)

Both lambda_1 and D2 are computed **directly from the raw numerically integrated trajectories**, without any reconstruction; eta is the **reconstruction success rate** obtained by feeding the data of that integration scheme into the same RC protocol (kappa = 0.2, 50 realizations).

| system | lambda_1 (dt=0.01) | lambda_1 (ref) | Delta lambda_1 | D2 (dt=0.01) | D2 (ref) | Delta D2 | eta (0.01 / DP5 / 0.005 / ref) |
|---|---|---|---|---|---|---|---|
| Lorenz | 0.8828 | 0.8871 | 0.49% | 1.7247 | 1.7135 | 0.65% | 0.74 / 0.80 / 0.80 / 0.78 |
| Rössler | 0.6041 | 0.5394 | 12.00% | 1.6341 | 1.6935 | 3.50% | 1.00 / 1.00 / 1.00 / 1.00 |
| Chen | 2.2925 | 2.3195 | 1.17% | 1.7029 | 1.7076 | 0.28% | 1.00 / 1.00 / 1.00 / 0.98 |
| Sprott A | 0.0110 | 0.0110 | 0.04% | 1.6051 | 1.6051 | 0.00% | 0.78 / 0.78 / 0.78 / 0.78 |
| Sprott B | 0.2069 | 0.2054 | 0.72% | 1.8013 | 1.6764 | 7.45% | 0.94 / 0.64 / 0.90 / 0.92 |
| Sprott C | 0.1574 | 0.1608 | 2.08% | 1.6538 | 1.7806 | 7.12% | 0.66 / 0.62 / 0.80 / 0.84 |
| Sprott D | 0.1091 | 0.0973 | 12.11% | 1.6674 | 1.5744 | 5.91% | 1.00 / 0.96 / 0.98 / 0.98 |
| Hyper-osc | 0.0835 | 0.0929 | 10.10% | 1.6207 | 1.6435 | 1.38% | 0.72 / 0.58 / 0.76 / 0.70 |
| Hyper-Sprott B | 0.0085 | 0.0086 | 0.04% | 1.2353 | 1.2353 | 0.00% | 0.58 / 0.54 / 0.56 / 0.54 |

**Summary**: median relative difference of lambda_1 is 1.17%, 5/9 systems are within 2%, the worst case is 12.11% (Sprott D); the largest relative difference of D2 is 7.45% (Sprott B).

The Sprott A trajectory drifts only at the $10^{-5}$ level over 1000 time units (its lambda_1 is about 0.011, the smallest of all systems), so all integration schemes agree to the precision shown in the table.

