# Reproduction of Table III/IV and of the bimodality statistics from the plotting data

Data source: `raw_data/` (a copy of the raw .dat files used by `plot_MFRC_result.m`).

## 1. Success rates (MFRC and single-task RC, 500 realizations)

| system | MFRC kappa=0.20 | kappa=0.15 | kappa=0.10 | RC kappa=0.20 | kappa=0.15 | kappa=0.10 | true D2 |
|---|---|---|---|---|---|---|---|
| SprottA | **0.764** | 0.744 | 0.674 | **0.822** | 0.778 | 0.684 | 2.313 |
| SprottB | **0.944** | 0.934 | 0.888 | **0.816** | 0.792 | 0.718 | 1.845 |
| SprottC | **0.790** | 0.782 | 0.732 | **0.628** | 0.620 | 0.580 | 1.814 |
| SprottD | **0.948** | 0.742 | 0.268 | **0.934** | 0.928 | 0.912 | 1.537 |
| Lorenz | **0.676** | 0.670 | 0.654 | **0.724** | 0.714 | 0.700 | 1.835 |
| Rössler | **0.912** | 0.898 | 0.874 | **0.970** | 0.966 | 0.960 | 1.821 |
| Chen | **0.992** | 0.992 | 0.992 | **0.990** | 0.990 | 0.988 | 1.771 |
| Selkov | **0.874** | 0.872 | 0.864 | **1.000** | 1.000 | 1.000 | 0.996 |
| HyperOsc | **0.734** | 0.698 | 0.644 | **0.470** | 0.388 | 0.256 | 1.899 |
| HyperSprottB | **0.500** | 0.468 | 0.418 | **0.352** | 0.280 | 0.202 | 1.309 |

Values reported in Table III of the manuscript: MFRC 0.764, 0.944, 0.790, 0.948, 0.676, 0.912, 0.992, 0.874, 0.734, 0.500 ; RC 0.822, 0.816, 0.628, 0.934, 0.724, 0.970, 0.990, 1.000, 0.470, 0.352.

**Reproduction: MFRC 10/10 and RC 10/10 agree with the manuscript to four decimals.**

## 2. Bimodality of the D2 distribution (original data, 500 realizations)

| system | Delta BIC | Sarle BC | two peak positions |
|---|---|---|---|
| SprottA | 919.3 | 0.921 | 0.44 / 2.31 |
| SprottB | 917.7 | 0.874 | 0.57 / 1.83 |
| SprottC | 1038.5 | 0.919 | 0.47 / 1.85 |
| SprottD | 910.9 | 0.908 | 0.03 / 1.69 |
| Lorenz | 1259.4 | 0.903 | 0.58 / 1.87 |
| Rössler | 845.1 | 0.886 | 1.36 / 1.80 |
| Chen | 916.9 | 0.852 | 1.13 / 1.76 |
| Selkov | 4616.4 | 0.986 | 0.28 / 1.00 |
| HyperOsc | 529.8 | 0.741 | 1.22 / 1.91 |
| HyperSprottB | 334.3 | 0.577 | 0.11 / 1.56 |

**All ten systems: Delta BIC = 334--4616 (threshold 10), Sarle BC 0.577--0.986.**

