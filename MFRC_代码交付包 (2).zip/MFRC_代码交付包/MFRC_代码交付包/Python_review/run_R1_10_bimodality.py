"""R1-10: bimodality of the prediction horizon and of the reconstructed D2.

Merged from: exp_c10_bimodality.py, c10b_bimodality_analysis.py
"""

try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from mfrc import gp, rc, systems                        # noqa: E402
import warnings


# ========================================================================
# exp_c10_bimodality.py
# ========================================================================

"""R1-10: is the reconstruction quality bimodal across random realizations, for
every chaotic benchmark system in the paper?

For each of the ten systems we draw N independent reservoirs (same
hyperparameters, only Win and Wr are re-drawn), train the released protocol and
record, per realization:

  vt_steps   valid prediction time of the autonomous rollout (steps until the
             normalised error first exceeds 0.3)
  d2_pred    correlation dimension of the reconstructed attractor
  one_step   open-loop one-step-ahead NRMSE (readout quality)
  wout_norm  Frobenius norm of the readout matrix

Outputs: results/c10_bimodality.npz (+ _summary.json)
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

DT = 0.01
VT_THRESHOLD = 0.3

_DATA = None


def _init():
    global _DATA
    _DATA = systems.load_all()


def worker(args):
    i, seed = args
    data = _DATA[i]
    rng = np.random.default_rng(seed)
    sigma, d, rho = systems.PARA[i]
    n = systems.RES_SIZE[i]
    L = systems.TRAINLEN_VEC[i]
    W_in = rc.gene_Win(n, systems.IN_SIZE[i], sigma, rng)
    W_r = rc.gene_Wr(n, d, rho, rng)
    X = rc.run_reservoir_forced([W_in], W_r, [data], systems.TRAINLEN,
                                systems.INITLEN, systems.ALPHA, [0], [n])
    seg = X[:, -L:]
    Yt = data[:, systems.TRAINLEN - L + 1: systems.TRAINLEN + 1]
    Wout = rc.ridge_readout(seg, Yt, systems.REG)
    Y = rc.rollout_single(W_in, W_r, Wout, data, systems.TRAINLEN,
                          systems.TESTLEN, systems.ALPHA, x_init=X[:, -1])
    true = data[:, systems.TRAINLEN + 1: systems.TRAINLEN + systems.TESTLEN + 1]
    vt = gp.valid_time(true, Y, VT_THRESHOLD)
    # open-loop (teacher forced) one-step error on the same window
    n_ol = 2000
    Yol = np.zeros((Yt.shape[0], n_ol))
    x = X[:, -1].copy()
    for t in range(n_ol):
        u = data[:, systems.TRAINLEN + t]
        x = (1 - systems.ALPHA) * x + systems.ALPHA * np.tanh(W_in @ u + W_r @ x)
        Yol[:, t] = Wout @ x
    true_ol = data[:, systems.TRAINLEN + 1: systems.TRAINLEN + 1 + n_ol]
    one_step = float(np.sqrt(np.mean((Yol - true_ol) ** 2))
                     / np.sqrt(np.mean(true_ol ** 2)))
    d2 = gp.gp_released(Y.T[0::10])[0]
    d2_true = gp.gp_released(true.T[0::10])[0]
    return {"system": systems.NAMES[i], "seed": seed, "vt_steps": vt,
            "d2_pred": d2, "d2_true": d2_true,
            "one_step_nrmse": one_step,
            "wout_norm": float(np.linalg.norm(Wout))}


def main_exp_c10_bimodality():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--jobs", type=int, default=12)
    ap.add_argument("--out", default="results/c10_bimodality.npz")
    args = ap.parse_args()
    tasks = [(i, 10000 + s) for i in range(10) for s in range(args.n)]
    acc = {name: [] for name in systems.NAMES}
    t0 = time.time()
    with ProcessPoolExecutor(max_workers=args.jobs, initializer=_init) as pool:
        for k, rec in enumerate(pool.map(worker, tasks, chunksize=2), 1):
            acc[rec["system"]].append(rec)
            if k % 200 == 0:
                print("  %d/%d (%.1f min)" % (k, len(tasks), (time.time() - t0) / 60),
                      flush=True)

    out = {}
    for name in systems.NAMES:
        recs = acc[name]
        out[name] = {k: np.array([r[k] for r in recs])
                     for k in ("vt_steps", "d2_pred", "d2_true",
                               "one_step_nrmse", "wout_norm")}
    np.savez(os.path.join(HERE, args.out), **{("%s__%s" % (n, k)): v
                                              for n, d in out.items()
                                              for k, v in d.items()})
    summary = {}
    for name in systems.NAMES:
        d = out[name]
        summary[name] = {
            "n": int(len(d["vt_steps"])),
            "vt_steps_median": float(np.median(d["vt_steps"])),
            "d2_pred_mean": float(d["d2_pred"].mean()),
            "d2_pred_std": float(d["d2_pred"].std()),
            "d2_true": float(d["d2_true"][0]),
            "one_step_median": float(np.median(d["one_step_nrmse"])),
            "corr_vt_d2": float(np.corrcoef(d["vt_steps"], d["d2_pred"])[0, 1]),
            "corr_vt_onestep": float(np.corrcoef(d["vt_steps"],
                                                 d["one_step_nrmse"])[0, 1]),
        }
    with open(os.path.join(HERE, args.out.replace(".npz", "_summary.json")),
              "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=1, ensure_ascii=False)
    print("\n%-13s %10s %11s" % ("system", "VT(med)", "corr(VT,D2)"))
    for name in systems.NAMES:
        s = summary[name]
        print("%-13s %10.0f %11.2f"
              % (name, s["vt_steps_median"], s["corr_vt_d2"]))
    print("\nwritten:", os.path.join(HERE, args.out))


# ========================================================================
# c10b_bimodality_analysis.py
# ========================================================================

"""Modality analysis for R1-10.

(1) Modality tests on the valid-prediction-time distribution (in steps) and on
    the correlation-dimension distribution:
      * Sarle's bimodality coefficient  BC = (skew^2 + 1) / kurtosis   (>0.555 hints bimodal)
      * 1- vs 2-component Gaussian mixture, BIC comparison
      * number of local maxima of a Gaussian KDE (Silverman bandwidth)
(2) Reliability of the two families: correlation of the prediction time with
    the one-step (open loop) readout error and with the readout norm.
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
os.environ.setdefault("LOKY_MAX_CPU_COUNT", "4")
warnings.filterwarnings("ignore")


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

DT = 0.01
RESULTS = os.path.join(HERE, "results")


# --------------------------------------------------------------- modality
def sarle(x):
    x = np.asarray(x, float)
    s = x.std()
    if s == 0:
        return np.nan
    skew = np.mean(((x - x.mean()) / s) ** 3)
    kurt = np.mean(((x - x.mean()) / s) ** 4)
    return float((skew ** 2 + 1.0) / kurt)


def gmm_bic(x, seed=0):
    from sklearn.mixture import GaussianMixture
    x = np.asarray(x, float).reshape(-1, 1)
    out = {}
    for k in (1, 2):
        gm = GaussianMixture(n_components=k, random_state=seed, n_init=5)
        gm.fit(x)
        out[k] = {"bic": float(gm.bic(x)), "aic": float(gm.aic(x)),
                  "means": [float(m) for m in gm.means_.ravel()],
                  "weights": [float(w) for w in gm.weights_],
                  "converged": bool(gm.converged_)}
    out["delta_bic_1_minus_2"] = out[1]["bic"] - out[2]["bic"]
    out["prefers_two"] = bool(out["delta_bic_1_minus_2"] > 10)
    return out


def kde_modes(x, n=400):
    from scipy.stats import gaussian_kde
    x = np.asarray(x, float)
    kde = gaussian_kde(x)
    grid = np.linspace(x.min(), x.max(), n)
    d = kde(grid)
    # count sign changes of the derivative, ignoring tiny ripples
    thr = 0.02 * d.max()
    sign = np.sign(np.diff(d))
    sign[np.abs(np.diff(d)) < thr * 0.05] = 0
    modes, last = 0, 0
    for s in sign:
        if s == 0:
            continue
        if last == 0:
            last = s
        elif s != last:
            if s < 0:
                modes += 1
            last = s
    if sign[sign != 0].size and sign[sign != 0][0] < 0:
        modes += 1
    return int(modes)


def analyse(values, label):
    v = np.asarray(values, float)
    v = v[np.isfinite(v)]
    g = gmm_bic(v)
    return {"label": label, "n": int(v.size),
            "median": float(np.median(v)),
            "iqr": [float(np.percentile(v, 25)), float(np.percentile(v, 75))],
            "sarle_BC": sarle(v), "kde_modes": kde_modes(v),
            "gmm": g,
            "poor_fraction": float(np.mean(v < np.median(v))),
            "two_mode_means": g[2]["means"], "two_mode_weights": g[2]["weights"]}


def main_c10b_bimodality_analysis():
    d = np.load(os.path.join(RESULTS, "c10_bimodality.npz"))
    old = np.load(os.path.join(RESULTS, "c1_ensemble_mfrc.npz"))

    out = {"systems": {}}
    for i, name in enumerate(systems.NAMES):
        vt = d["%s__vt_steps" % name]
        d2 = old["pred"][:, i]
        d2_true = float(old["true"][0, i])
        rel = np.abs((d2 - d2_true) / d2_true)
        entry = {
            "vt_steps": analyse(vt, "%s VT (steps)" % name),
            "d2_pred": analyse(d2, "%s D2 (500 realizations)" % name),
            "d2_true": d2_true,
            "eta_kappa020": float(np.mean(rel < 0.20)),
            "corr_vt_onestep": float(np.corrcoef(vt, d["%s__one_step_nrmse" % name])[0, 1]),
            "corr_vt_wout": float(np.corrcoef(vt, d["%s__wout_norm" % name])[0, 1]),
        }
        out["systems"][name] = entry

    path = os.path.join(RESULTS, "c10_bimodality_analysis.json")
    json.dump(out, open(path, "w", encoding="utf-8"), indent=1, ensure_ascii=False)

    print("\n%-13s %9s %9s %9s %8s %8s"
          % ("system", "VT(med)", "BC(VT)", "modes", "dBC", "2-comp"))
    for name in systems.NAMES:
        e = out["systems"][name]
        v = e["vt_steps"]
        print("%-13s %9.2f %9.3f %9d %8.1f %8s"
              % (name, v["median"], v["sarle_BC"], v["kde_modes"],
                 v["gmm"]["delta_bic_1_minus_2"],
                 "yes" if v["gmm"]["prefers_two"] else "no"))
    print("\nD2 distributions (500 realizations):")
    print("%-13s %9s %9s %8s  %s" % ("system", "D2 med", "BC(D2)", "modes", "dBC"))
    for name in systems.NAMES:
        e = out["systems"][name]["d2_pred"]
        print("%-13s %9.3f %9.3f %8d %8.1f"
              % (name, e["median"], e["sarle_BC"], e["kde_modes"],
                 e["gmm"]["delta_bic_1_minus_2"]))
    print("\nwritten:", path)


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    import sys
    _steps = [main_exp_c10_bimodality, main_c10b_bimodality_analysis]
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        # drop the step index so that argparse in the step sees only its own flags
        _steps[int(sys.argv.pop(1))]()
    else:
        for _f in _steps:
            _f()
