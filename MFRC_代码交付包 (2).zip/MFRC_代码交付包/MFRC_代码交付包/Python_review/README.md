# Python review code

Recomputation, statistical tests and figure code provided in addition to the
manuscript results. The manuscript results themselves are reproduced by
`../MATLAB/`; this directory supports the additional arguments of the reply.

Environment: Python 3.12 + NumPy / SciPy / scikit-learn / matplotlib.

```bash
cd Python_review
pip install -r requirements.txt
python run_R1_11_R1_12_figures.py      # writes figures/figR1-Wr-sparsity.{png,pdf}
python run_R1_13_readout.py            # writes figures/figR2-readout-weights.{png,pdf}
```

`results/` and `raw_data/` are shipped with the package and can be read
directly.

## 1. Experiment scripts

| Script | Comment(s) covered |
|---|---|
| `run_R1_5_R2_5_cost.py` | R1-5 / R2-5: optimisation and readout cost accounting, equal-budget 128-evaluation comparison, CPU-hours of four real searches (Table 7) |
| `run_R1_8_solver.py` | R1-8: re-integration with four schemes (lambda_1, D2), solver-convergence table |
| `run_R1_10_bimodality.py` | R1-10: prediction horizon / one-step error, BIC / Delta-BIC / Sarle statistics |
| `run_R1_11_R1_12_figures.py` | R1-11 (r = 0.837 recomputed from the released data), R1-12 (W_r sparsity figure) |
| `run_R1_13_readout.py` | R1-13: block-local readout statistics (Fig. R2) |
| `run_R1_16_R2_6_metrics.py` | R1-16 / R2-6: D2 distribution shape, estimator-impact table |
| `run_R2_1_R2_3_paired.py` | R2-1 / R2-3: block-diagonal equivalence, paired 500-realization statistics |
| `run_R2_3_reproduce_tables.py` | R2-3 / R1-10: recomputation of Table 3/4 and of the bimodality statistics from the released data |
| `run_R2_7_modularity.py` | R2-7: correlation between the modularity Q and the success rate on the released grid, and the unconfounded Q test on the improved single reservoir |

Each script can be run as a whole (`python run_xxx.py`) or step by step
(`python run_xxx.py <step index>`).

## 2. Reply figures

| Figure | Producing script | Content |
|---|---|---|
| `figures/figR1-Wr-sparsity.{png,pdf}` | second step of `run_R1_11_R1_12_figures.py` | three examples of W_r sparsity (s_p = 0 / s_p = 0.5, n_sigma = 1e-2 / s_p = 1, n_sigma = 1e-1) plus intra-block / inter-block weight histograms (R1-12) |
| `figures/figR2-readout-weights.{png,pdf}` | `run_R1_13_readout.py` | magnitude distribution of the block-local readout plus the per-task Frobenius norm (R1-13) |

The output directory `figures/` is created by the scripts when they run.

## 3. Data

`raw_data/` (72 files) contains the data read by the scripts; the values are
identical to the files of the same name under `../Data/`:

- grid data of Fig. 8: `Q_matrix_sprottBC_500times*.dat` and the 42
  `success_rate_matrix_sprott{B,C}_labIndex*.txt` files;
- the 500-realization D2 matrices used for the manuscript figures:
  `Dim_fractal_matrix_*_10sys_*` and the per-system `*_RC_fractal_dim_*`;
- data of the R2-7 unconfounded test (improved single reservoir):
  `Dim_fractal_matrix_pre/ture_sprott{B,C}_500times.dat` and
  `Q_max_vec_sprottBC{1,2}_500times.dat`.

`run_R2_7_modularity.py` reads `raw_data/` first, so
`python run_R2_7_modularity.py 1` reproduces the two tests
Sprott B 0.293 vs 0.253 (p = 0.014) and Sprott C 0.310 vs 0.291 (p = 0.027).

## 4. `kld_pdf/`

Python check of the KLD/PDF metric (including the Hyper-osc training-protocol
verification); it corresponds to Table 4 of the manuscript. The MATLAB
implementation is in `../MATLAB/KLD_MATLAB/`.
