"""R1-13: statistics of the block-local readout actually used by the method.

Merged from: c11_weight_analysis.py
"""

try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import json
import os
import sys
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from mfrc import experiments as ex, rc, systems            # noqa: E402


# ========================================================================
# c11_weight_analysis.py
# ========================================================================

"""R1-13: analysis of the trained readout weights that the method actually uses.

The released implementation trains one block-local readout per task: task i is
read out from its own module's state segment only, so in the complete readout the
cross-module blocks are zero *by construction* rather than as a result of
training.  For each of the ten tasks we therefore characterise the readout
itself: effective rank, condition number, Frobenius norm, mean |weight| and the
pooled weight-magnitude distribution.

Outputs: results/c11_weight_analysis.json, figures/figR2-readout-weights.{png,pdf}
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

matplotlib.use("Agg")

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

SEED = 3
ORDER = systems.NAMES


def main_c11_weight_analysis():
    data_list = systems.load_all()
    rng = np.random.default_rng(SEED)
    W_in, W_r = ex.build_matrices(rng)
    res_starts, res_ends, _, _ = ex.block_slices()

    X = np.zeros((sum(systems.RES_SIZE), systems.TRAINLEN - systems.INITLEN))
    for i in range(10):
        X[res_starts[i]:res_ends[i]] = rc.run_reservoir_single(
            W_in[i], W_r[i], data_list[i], systems.TRAINLEN, systems.INITLEN,
            systems.ALPHA)
    print("reservoir trained; X =", X.shape, flush=True)

    local, mags = {}, []
    Wouts = ex.readouts_blockwise(X, data_list, res_starts, res_ends)
    for i, name in enumerate(ORDER):
        Wo = Wouts[i]
        s = np.linalg.svd(Wo, compute_uv=False)
        local[name] = {
            "shape": list(Wo.shape),
            "fro": float(np.linalg.norm(Wo)),
            "spectral": float(s[0]),
            "condition": float(s[0] / s[-1]) if s[-1] > 0 else float("inf"),
            "effective_rank": float((s.sum() ** 2) / (s ** 2).sum()),
            "mean_abs": float(np.abs(Wo).mean()),
            "max_abs": float(np.abs(Wo).max()),
        }
        mags.append(np.abs(Wo).ravel())
    pooled = np.concatenate(mags)

    out = {
        "readout": "block-local (the readout used for every result in the paper)",
        "note": "cross-module blocks are zero by construction: task i is read out "
                "from its own module's state only",
        "block_local_readout": local,
        "pooled": {
            "mean_abs": float(pooled.mean()),
            "median_abs": float(np.median(pooled)),
            "max_abs": float(pooled.max()),
            "n_weights": int(pooled.size),
        },
    }
    path = os.path.join(HERE, "results", "c11_weight_analysis.json")
    json.dump(out, open(path, "w", encoding="utf-8"), indent=1, ensure_ascii=False)

    # ---------------------------------- figure ------------------------------
    fros = np.array([local[n]["fro"] for n in ORDER])
    fig = plt.figure(figsize=(9.0, 4.0))

    ax1 = fig.add_subplot(1, 2, 1)
    bins = np.logspace(np.log10(max(pooled.min(), 1e-6)), np.log10(pooled.max()), 45)
    ax1.hist(pooled, bins=bins, color="#4C72B0", alpha=0.85)
    ax1.set_xscale("log")
    ax1.set_xlabel(r"$|w|$ (ten task readouts pooled)")
    ax1.set_ylabel("count")
    ax1.set_title("(a) trained readout weights\nmean $|w|$ = %.3f, max = %.1f"
                  % (pooled.mean(), pooled.max()),
                  fontsize=9)

    ax2 = fig.add_subplot(1, 2, 2)
    ax2.bar(range(10), fros, color="#C44E52")
    ax2.set_yscale("log")
    ax2.set_xticks(range(10))
    ax2.set_xticklabels(ORDER, rotation=90, fontsize=6)
    ax2.set_ylabel(r"$\|W_{out}\|_F$")
    ax2.set_title("(b) readout Frobenius norm per task", fontsize=9)

    fig.tight_layout()
    for ext in ("png", "pdf"):
        os.makedirs(os.path.join(os.path.dirname(HERE), "figures"), exist_ok=True)
        fig.savefig(os.path.join(os.path.dirname(HERE), "figures",
                                 "figR2-readout-weights.%s" % ext),
                    bbox_inches="tight", dpi=220)
    print("wrote figR2-readout-weights")

    print("\ntrained block-local readout (per task):")
    print("%-13s %8s %8s %8s %10s %10s" %
          ("system", "||W||_F", "sigma_max", "cond", "eff. rank", "mean |w|"))
    for name in ORDER:
        L = local[name]
        print("%-13s %8.2f %8.3f %8.2f %10.2f %10.4f"
              % (name, L["fro"], L["spectral"], L["condition"],
                 L["effective_rank"], L["mean_abs"]))
    print("\npooled: mean |w| %.4f, median %.4f, max %.3f over %d weights"
          % (pooled.mean(), np.median(pooled), pooled.max(), pooled.size))
    print("written:", path)


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    import sys
    _steps = [main_c11_weight_analysis]
    if len(sys.argv) > 1:
        _steps[int(sys.argv[1])]()
    else:
        for _f in _steps:
            _f()
