"""R2-1 / R2-3: block-diagonal equivalence and the paired ensemble.

Merged from: exp_c1_equivalence.py, exp_c1_ensemble.py
"""

try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import os
import sys
import numpy as np
from mfrc import experiments as ex, gp, rc, systems
import argparse
import json
import time
from concurrent.futures import ProcessPoolExecutor


# ========================================================================
# exp_c1_equivalence.py
def main_exp_c1_equivalence():
    # ========================================================================

    """C1a: numerical proof that the block-diagonal MFRC with a block-local readout is
    identical to the corresponding standalone RC (Referee 2, comments 1-3)."""


    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

    print("=== joint block-diagonal run vs factorized per-block run (same seed) ===")
    rng = np.random.default_rng(12345)
    data_list = systems.load_all()
    W_in, W_r = ex.build_matrices(rng)
    res_starts, res_ends, in_starts, in_ends = ex.block_slices()

    Xj, W = ex.train_joint(W_in, W_r, data_list)
    Xf = np.zeros_like(Xj)
    for i in range(10):
        Xf[res_starts[i]:res_ends[i]] = rc.run_reservoir_single(
            W_in[i], W_r[i], data_list[i], systems.TRAINLEN, systems.INITLEN, systems.ALPHA)

    print("max |X_joint - X_factorized| over training states: %.3e" % np.abs(Xj - Xf).max())

    Wout = ex.readouts_blockwise(Xj, data_list, res_starts, res_ends)
    u0 = np.concatenate([d[:, systems.TRAINLEN] for d in data_list])

    print("\nsystem      max|dY| (joint vs standalone rollout)   D2_joint   D2_standalone")
    for i in range(10):
        Yj = rc.rollout_block_local(W_in, W, Wout, data_list, systems.TRAINLEN,
                                    systems.TESTLEN, systems.ALPHA, res_starts, res_ends,
                                    in_starts, in_ends, i, x_init=Xj[:, -1], u_init=u0)
        Xs = Xf[res_starts[i]:res_ends[i]]
        Ys = rc.rollout_single(W_in[i], W_r[i], Wout[i], data_list[i], systems.TRAINLEN,
                               systems.TESTLEN, systems.ALPHA, x_init=Xs[:, -1])
        d2j = gp.gp_released(Yj.T[0::10])[0]
        d2s = gp.gp_released(Ys.T[0::10])[0]
        print("%-13s %18.3e %22.6f %14.6f"
              % (systems.NAMES[i], np.abs(Yj - Ys).max(), d2j, d2s))

    print("\n=== paired standalone RC (same matrices/window/IC) vs MFRC blocks, 5 seeds ===")
    for seed in range(5):
        a_p, a_t = ex.realization_blocklocal(seed, joint=False)
        b_p, b_t = ex.realization_standalone_paired(seed)
        print("seed %d: max|D2 difference| = %.3e   (true D2 max diff %.3e)"
              % (seed, np.abs(a_p - b_p).max(), np.abs(a_t - b_t).max()))

# ========================================================================
# exp_c1_ensemble.py
# ========================================================================

"""C1b: ensemble statistics for the paired control.

Runs `--n` realizations of
  * MFRC  = block-diagonal W_r + block-local readout + block-local feedback
            (identical to the released pipeline; the factorized form is exact and
             is used for rollout speed, verified step-by-step in exp_c1_equivalence)
  * RC    = standalone reservoir with the same W_in, W_r, window, initial state
            and readout (the strictly paired control requested by Referee 2)
  * RCbug = the released regress_RC_fractal.m protocol (own window + x=X(:,1) + )
            resSize follows the paper's "matched dimension" claim
and reports the success rate eta per system with Wilson 95% intervals.
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")     # avoid BLAS thread oversubscription


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

_DATA = None
_TRUE = None
_TRUE_BUG = None


def _init():
    global _DATA, _TRUE, _TRUE_BUG
    _DATA = systems.load_all()
    _TRUE = np.array([gp.gp_released(
        _DATA[i][:, systems.TRAINLEN + 1: systems.TRAINLEN + systems.TESTLEN + 1]
        .T[0::10])[0] for i in range(10)])
    _TRUE_BUG = np.array([gp.gp_released(
        _DATA[i][:, 50001:50001 + systems.TESTLEN].T[0::10])[0]
        for i in range(10)])


def d2_pair(Y_pred, Y_true, gap=10):
    return (gp.gp_released(Y_pred.T[0::gap])[0],
            gp.gp_released(Y_true.T[0::gap])[0])


def worker(args):
    kind, seed = args
    global _DATA, _TRUE, _TRUE_BUG
    data_list = _DATA
    rng = np.random.default_rng(seed)
    W_in, W_r = ex.build_matrices(rng)
    res_starts, res_ends, _, _ = ex.block_slices()
    out = {}
    true = _TRUE.copy()

    if kind in ("mfrc", "rc"):
        X = np.zeros((sum(systems.RES_SIZE), systems.TRAINLEN - systems.INITLEN))
        for i in range(10):
            X[res_starts[i]:res_ends[i]] = ex.rc.run_reservoir_single(
                W_in[i], W_r[i], data_list[i], systems.TRAINLEN, systems.INITLEN,
                systems.ALPHA)
        Wout = ex.readouts_blockwise(X, data_list, res_starts, res_ends)
        pred = np.zeros(10)
        for i in range(10):
            Y = ex.rc.rollout_single(W_in[i], W_r[i], Wout[i], data_list[i],
                                     systems.TRAINLEN, systems.TESTLEN, systems.ALPHA,
                                     x_init=X[res_starts[i]:res_ends[i], -1])
            pred[i] = gp.gp_released(Y.T[0::10])[0]
        out["pred"], out["true"] = pred, true

    elif kind == "rcbug":
        # released regress_RC_fractal.m: own window (trainLen/initLen) and
        # rollout from X(:,1); matrices are the same as the MFRC block
        pred = np.zeros(10)
        for i in range(10):
            d = data_list[i]
            Xi = ex.rc.run_reservoir_single(W_in[i], W_r[i], d, 50000, 5000,
                                            systems.ALPHA)
            Yt = d[:, 5001:50001]
            Wout = ex.rc.ridge_readout(Xi, Yt, systems.REG)
            Y = ex.rc.rollout_single(W_in[i], W_r[i], Wout, d, 50000,
                                     systems.TESTLEN, systems.ALPHA, x_init=Xi[:, 0])
            pred[i] = gp.gp_released(Y.T[0::10])[0]
        out["pred"], out["true"] = pred, _TRUE_BUG.copy()
    else:
        raise ValueError(kind)
    return kind, seed, out["pred"], out["true"]


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (c - h, c + h)


def main_exp_c1_ensemble():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--n_rc", type=int, default=50,
                    help="realizations for the paired standalone-RC cross-check")
    ap.add_argument("--jobs", type=int, default=20)
    ap.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "results", "c1_ensemble.npz"))
    args = ap.parse_args()
    os.makedirs(os.path.dirname(args.out), exist_ok=True)

    tasks = []
    tasks += [("mfrc", s) for s in range(args.n)]
    tasks += [("rc", s) for s in range(args.n_rc)]
    tasks += [("rcbug", s) for s in range(args.n)]

    results = {"mfrc": {}, "rc": {}, "rcbug": {}}
    jsonl = args.out + ".jsonl"
    done = set()
    if os.path.exists(jsonl):
        with open(jsonl) as fh:
            for line in fh:
                rec = json.loads(line)
                done.add((rec["kind"], rec["seed"]))
                results[rec["kind"]]["pred"] = results[rec["kind"]].get("pred", [])
                results[rec["kind"]]["true"] = results[rec["kind"]].get("true", [])
                results[rec["kind"]]["pred"].append(rec["pred"])
                results[rec["kind"]]["true"].append(rec["true"])
        tasks = [t for t in tasks if t not in done]
        print("resuming: %d tasks already done" % len(done), flush=True)

    t0 = time.time()
    with ProcessPoolExecutor(max_workers=args.jobs, initializer=_init) as pool:
        with open(jsonl, "a") as fh:
            for n_done, (kind, seed, pred, true) in enumerate(
                    pool.map(worker, tasks, chunksize=1), 1):
                results[kind].setdefault("pred", []).append(pred)
                results[kind].setdefault("true", []).append(true)
                fh.write(json.dumps({"kind": kind, "seed": seed,
                                     "pred": list(map(float, pred)),
                                     "true": list(map(float, true))}) + "\n")
                fh.flush()
                if n_done % 25 == 0:
                    print("  %d/%d done (%.1f min)"
                          % (n_done, len(tasks), (time.time() - t0) / 60), flush=True)

    summary = {}
    for kind in results:
        P = np.array(results[kind]["pred"])
        T = np.array(results[kind]["true"])
        np.savez(args.out.replace(".npz", "_%s.npz" % kind), pred=P, true=T)
        summary[kind] = {}
        for kappa in (0.20, 0.15, 0.10):
            eta, lo, hi = [], [], []
            for i in range(10):
                ok = np.abs((P[:, i] - T[:, i]) / T[:, i]) < kappa
                l, h = wilson(ok.sum(), len(ok))
                eta.append(ok.mean())
                lo.append(l)
                hi.append(h)
            summary[kind]["kappa_%.2f" % kappa] = {"eta": eta, "lo": lo, "hi": hi}
        summary[kind]["d2_true_mean"] = T.mean(axis=0).tolist()
        summary[kind]["d2_pred_mean"] = P.mean(axis=0).tolist()
        summary[kind]["d2_pred_std"] = P.std(axis=0).tolist()

    with open(args.out.replace(".npz", "_summary.json"), "w") as fh:
        json.dump({"names": systems.NAMES, "summary": summary}, fh, indent=1)

    print("\n%s" % ("system".ljust(13) + "".join("%14s" % k for k in results)))
    for i, name in enumerate(systems.NAMES):
        row = name.ljust(13)
        for kind in results:
            e = summary[kind]["kappa_0.20"]["eta"][i]
            l = summary[kind]["kappa_0.20"]["lo"][i]
            h = summary[kind]["kappa_0.20"]["hi"][i]
            row += "%14s" % ("%.3f [%.3f,%.3f]" % (e, l, h))
        print(row)
    print("\n(written to %s)" % args.out)


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    import sys
    _steps = [main_exp_c1_equivalence, main_exp_c1_ensemble]
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        # drop the step index so that argparse in the step sees only its own flags
        _steps[int(sys.argv.pop(1))]()
    else:
        for _f in _steps:
            _f()
