"""R1-11 / R1-12: reproduce Fig. 8 from the released data; W_r sparsity figure.

Merged from: check_fig8.py, c22_wr_sparsity_figure.py
"""

try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt


# ========================================================================
# check_fig8.py
def main_check_fig8():
    # ========================================================================

    base = os.path.join(HERE, "raw_data")
    if not os.path.isdir(base):
        base = r"C:\Users\KevinJiang\Desktop\multifunctionRC\result_add_noise"

    B, C = [], []
    for ix in range(1, 22):
        for tag, acc in (("sprottB", B), ("sprottC", C)):
            f = os.path.join(base, "success_rate_matrix_%s_labIndex%02d.txt" % (tag, ix))
            d = np.loadtxt(f)
            acc.append(d[0:8, 0])

    B = np.array(B).reshape(21, 8)
    C = np.array(C).reshape(21, 8)
    avg = (B + C) / 2.0
    Q = np.loadtxt(os.path.join(base, "Q_matrix_sprottBC_500times.dat"))
    ov = np.loadtxt(os.path.join(base, "overlap_matrix_sprottBC_500times.dat"))

    np.set_printoptions(precision=3, suppress=True, linewidth=140)
    print("success SprottB range (eps=0.2):", B.min(), B.max())
    print("success SprottC range (eps=0.2):", C.min(), C.max())
    print("avg success range:", avg.min(), avg.max())
    print("Q range:", Q.min(), Q.max(), "any negative Q:", bool((Q < 0).any()))
    print("overlap range:", ov.min(), ov.max())
    print("pearson(avg, Q) over 168 points =", np.corrcoef(avg.ravel(), Q.ravel())[0, 1])
    print("pearson(avg, Q) within fixed sp, over alp:")
    rs = [np.corrcoef(avg[i], Q[i])[0, 1] for i in range(21)]
    print("   min %.3f max %.3f (undefined where Q is constant)" % (np.nanmin(rs), np.nanmax(rs)))
    print("Q at sp=0 row:", Q[0])
    print("avg success at sp=0 row:", avg[0])

# ========================================================================
# c22_wr_sparsity_figure.py
# ========================================================================

"""R1-12: sparsity structure of W_r (block-diagonal limit, intermediate and dense
inter-module coupling) with the corresponding weight histograms.

Outputs figures/figR1-Wr-sparsity.{png,pdf}
"""


matplotlib.use("Agg")

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(os.path.dirname(HERE), "figures")
os.makedirs(FIG, exist_ok=True)

M, RNG = 400, np.random.default_rng(7)
CASES = [(0.0, 0.0), (0.5, 1e-2), (1.0, 1e-1)]


def build(sp, n_sigma, n_blocks=4):
    W = np.zeros((M, M))
    b = M // n_blocks
    for i in range(n_blocks):
        s = slice(i * b, (i + 1) * b)
        W[s, s] = np.random.default_rng(10 + i).standard_normal((b, b)) / np.sqrt(b)
    if sp > 0 and n_sigma > 0:
        mask = np.random.default_rng(11).random((M, M)) < sp
        np.fill_diagonal(mask, False)
        off = n_sigma * np.random.default_rng(12).standard_normal((M, M)) * mask
        W = W + off
    return W, b


def main_c22_wr_sparsity_figure():
    fig = plt.figure(figsize=(11.0, 3.2))
    letter = "abc"
    for k, (sp, ns) in enumerate(CASES):
        W, b = build(sp, ns)
        ax = fig.add_subplot(2, 3, k + 1)
        vmax = np.percentile(np.abs(W[W != 0]), 99) if (W != 0).any() else 1
        ax.imshow(np.abs(W), cmap="viridis", vmin=0, vmax=vmax)
        for q in range(1, M // b):
            ax.axvline(q * b - 0.5, color="w", lw=0.5)
            ax.axhline(q * b - 0.5, color="w", lw=0.5)
        ax.set_title("(%s) $s_p=%.1f$, $n_\\sigma=%g$" % (letter[k], sp, ns),
                     fontsize=9)
        ax.set_xticks([]); ax.set_yticks([])
        ax2 = fig.add_subplot(2, 3, k + 4)
        diag = np.concatenate([np.abs(W[i * b:(i + 1) * b, i * b:(i + 1) * b]).ravel()
                               for i in range(M // b)])
        mask_off = np.ones_like(W, dtype=bool)
        for i in range(M // b):
            mask_off[i * b:(i + 1) * b, i * b:(i + 1) * b] = False
        off = np.abs(W[mask_off])
        if (off > 0).any():
            bins = np.logspace(-4, 0.5, 40)
            ax2.hist(diag, bins=bins, density=True, alpha=0.75,
                     label="intra-block", color="#4C72B0")
            ax2.hist(off[off > 0], bins=bins, density=True, alpha=0.75,
                     label="inter-block", color="#C44E52")
            ax2.set_xscale("log")
            ax2.legend(fontsize=6)
        else:
            ax2.hist(diag, bins=40, density=True, color="#4C72B0")
            ax2.text(0.5, 0.8, "no inter-block entries", ha="center",
                     transform=ax2.transAxes, fontsize=7)
        ax2.set_xlabel(r"$|w|$", fontsize=8)
        ax2.tick_params(labelsize=7)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(FIG, "figR1-Wr-sparsity.%s" % ext),
                    bbox_inches="tight", dpi=220)
    print("wrote figR1-Wr-sparsity")


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    import sys
    _steps = [main_check_fig8, main_c22_wr_sparsity_figure]
    if len(sys.argv) > 1:
        _steps[int(sys.argv[1])]()
    else:
        for _f in _steps:
            _f()
