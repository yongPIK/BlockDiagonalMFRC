"""R1-16 / R2-6: D2 distribution shape, estimator conventions, D2-bimodality figure.

Merged from: c13_distribution_compare.py, c24_R26_estimator_impact.py
"""

try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import json
import os
import numpy as np
from sklearn.mixture import GaussianMixture
import io
import sys
from mfrc import gp                                    # noqa: E402


# ========================================================================
# c13_distribution_compare.py
# ========================================================================

"""Quantify our D2 distribution shape for the three systems used in Table IV
(Lorenz, Rossler, Chen) from the existing 500-realization data, so that the
comparison with the Ref. [18] distributions (Fig. 9) can be stated precisely.
"""



HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
SYSTEMS = {"Lorenz": 4, "Roessler": 5, "Chen": 6}


def main_c13_distribution_compare():
    d = np.load(os.path.join(RES, "c1_ensemble_mfrc.npz"))
    pred, true = d["pred"], d["true"]
    out = {}
    print("%-9s %9s %9s %9s %9s %9s %9s" %
          ("system", "D2 true", "peak1", "peak2", "w1", "frac<=10%", "frac<=20%"))
    for name, i in SYSTEMS.items():
        x = pred[:, i]
        ref = float(true[0, i])
        rel = np.abs((x - ref) / ref)
        gm = GaussianMixture(n_components=2, random_state=0, n_init=10).fit(x[:, None])
        means = gm.means_.ravel()
        weights = gm.weights_
        order = np.argsort(np.abs(means - ref))
        out[name] = {
            "d2_ref": ref,
            "peaks": [float(m) for m in means],
            "weights": [float(w) for w in weights],
            "nearest_peak": float(means[order[0]]),
            "nearest_peak_weight": float(weights[order[0]]),
            "nearest_peak_rel_dev": float(abs(means[order[0]] - ref) / ref),
            "frac_rel_lt_0.10": float((rel < 0.10).mean()),
            "frac_rel_lt_0.15": float((rel < 0.15).mean()),
            "frac_rel_lt_0.20": float((rel < 0.20).mean()),
            "median_rel": float(np.median(rel)),
            "iqr_rel": [float(np.percentile(rel, 25)), float(np.percentile(rel, 75))],
        }
        e = out[name]
        print("%-9s %9.3f %9.3f %9.3f %9.2f %9.3f %9.3f"
              % (name, ref, e["peaks"][0], e["peaks"][1], e["weights"][0],
                 e["frac_rel_lt_0.10"], e["frac_rel_lt_0.20"]))
    print("\nnearest peak (the 'good' family) and its weight:")
    for name in SYSTEMS:
        e = out[name]
        print("  %-9s peak %.3f vs true %.3f (rel. dev %.1f%%), weight %.2f; "
              "median rel. error %.1f%%"
              % (name, e["nearest_peak"], e["d2_ref"],
                 100 * e["nearest_peak_rel_dev"], e["nearest_peak_weight"],
                 100 * e["median_rel"]))
    with open(os.path.join(RES, "c13_distribution_compare.json"), "w",
              encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    print("\nwritten: results/c13_distribution_compare.json")


# ========================================================================
# c24_R26_estimator_impact.py
# ========================================================================

"""R2-6: effect of the D2 estimator conventions on the Table III success rates.

The 500 realisations of the released data store only D2 values (no trajectories), so we
measure, on the author's own true and predicted trajectories, the ratio
r = D2(corrected estimator) / D2(released estimator) with the corrected estimator using a
Theiler window and automatic scaling-region selection (mfrc.gp.gp_corrected), map the
500-realisation distributions by that ratio and recompute the success rates.

Outputs results/c24_R26_estimator_impact.json  (used by make_figures.fig06)
"""



HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "Data", "result_MFRC", "result_MFRC")
if not os.path.isdir(SRC):
    SRC = r"C:\Users\KevinJiang\Desktop\result_MFRC\result_MFRC"
RC_FILE = ["SprottA", "SprottB", "SprottC", "SprottD", "Lorenz", "Roessler",
           "Chen", "sel_kov", "hyperchaotic_oscillator", "hyper_sprottB"]
DISPLAY = ["SprottA", "SprottB", "SprottC", "SprottD", "Lorenz", "Rössler",
           "Chen", "Selkov", "HyperOsc", "HyperSprottB"]
KAPPAS = (0.20, 0.15, 0.10)


def eta(values, true, kappa):
    return float((np.abs((np.ravel(values) - true) / true) < kappa).mean())


def ratios(prefix):
    d = {}
    for tag, fn in (("true", "%s_true.dat" % prefix), ("pred", "%s_pre.dat" % prefix)):
        Y = np.loadtxt(os.path.join(SRC, fn)).T[0::10]
        rel = float(gp.gp_released(Y)[0])
        cor = float(gp.gp_corrected(Y))
        d[tag] = cor / rel
    return d


def main_c24_r26_estimator_impact():
    pre = np.loadtxt(os.path.join(SRC, "Dim_fractal_matrix_pre_10sys_30000length_gap10_500times.dat"))
    tru = np.loadtxt(os.path.join(SRC, "Dim_fractal_matrix_ture_10sys_30000length_gap10_500times.dat"))
    out = {"kappas": list(KAPPAS), "systems": {}}
    for i, (prefix, name) in enumerate(zip(RC_FILE, DISPLAY)):
        r = ratios(prefix)
        true_d2 = float(tru[0, i])
        pred = np.ravel(pre[:, i])
        rc_pre = np.ravel(np.loadtxt(os.path.join(
            SRC, "%s_RC_fractal_dim_30000length_pre_gap10_500times.dat" % prefix)))
        rc_true = float(np.ravel(np.loadtxt(os.path.join(
            SRC, "%s_RC_fractal_dim_30000length_ture_gap10_500times.dat" % prefix)))[0])
        entry = {"r_true": r["true"], "r_pred": r["pred"],
                 "mfrc_orig": [eta(pred, true_d2, k) for k in KAPPAS],
                 "mfrc_corr": [eta(pred * r["pred"], true_d2 * r["true"], k) for k in KAPPAS],
                 "rc_orig": [eta(rc_pre, rc_true, k) for k in KAPPAS],
                 "rc_corr": [eta(rc_pre * r["pred"], rc_true * r["true"], k) for k in KAPPAS]}
        out["systems"][name] = entry
        ascii_name = name.encode("ascii", "replace").decode()
        print("%-14s r=%.3f/%.3f  MFRC %.3f->%.3f  RC %.3f->%.3f"
              % (ascii_name, r["true"], r["pred"], entry["mfrc_orig"][0],
                 entry["mfrc_corr"][0], entry["rc_orig"][0], entry["rc_corr"][0]))

    m_o = np.mean([e["mfrc_orig"] for e in out["systems"].values()], axis=0)
    m_c = np.mean([e["mfrc_corr"] for e in out["systems"].values()], axis=0)
    out["means"] = {"mfrc_orig": m_o.tolist(), "mfrc_corr": m_c.tolist()}
    print("means  MFRC orig %s -> corr %s" % (np.round(m_o, 3), np.round(m_c, 3)))

    path = os.path.join(HERE, "results", "c24_R26_estimator_impact.json")
    json.dump(out, io.open(path, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print("written:", path)


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    import sys
    _steps = [main_c13_distribution_compare, main_c24_r26_estimator_impact]
    if len(sys.argv) > 1:
        _steps[int(sys.argv[1])]()
    else:
        for _f in _steps:
            _f()
