"""R2-3 / R1-10: recompute Table III/IV and the bimodality statistics from the author data.

Merged from: analyze_paper_figdata.py
"""

try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import os
import numpy as np
from scipy.stats import kurtosis, skew
from sklearn.mixture import GaussianMixture


# ========================================================================
# analyze_paper_figdata.py
# ========================================================================

"""Analyse the author's figure data (shipped in raw_data/, a copy of result_MFRC/result_MFRC).

Inputs (all produced by the author's MATLAB plotting script plot_MFRC_result.m):
  Dim_fractal_matrix_pre_10sys_30000length_gap10_500times.dat   MFRC D2, 500 x 10
  Dim_fractal_matrix_ture_10sys_30000length_gap10_500times.dat  true D2, 500 x 10
  <sys>_RC_fractal_dim_30000length_{pre,ture}_gap10_500times.dat single-RC D2
Outputs:
  results/14_reproduce_TableIII_and_bimodality.md
"""



SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "raw_data")
if not os.path.isdir(SRC):
    SRC = r"C:\Users\KevinJiang\Desktop\result_MFRC\result_MFRC"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "results", "14_reproduce_TableIII_and_bimodality.md")

RC_FILE = ["SprottA", "SprottB", "SprottC", "SprottD", "Lorenz", "Roessler",
           "Chen", "sel_kov", "hyperchaotic_oscillator", "hyper_sprottB"]
DISPLAY = ["SprottA", "SprottB", "SprottC", "SprottD", "Lorenz", "Rössler",
           "Chen", "Selkov", "HyperOsc", "HyperSprottB"]
PAPER_MFRC = [0.764, 0.944, 0.790, 0.948, 0.676, 0.912, 0.992, 0.874, 0.734, 0.500]
PAPER_RC = [0.822, 0.816, 0.628, 0.934, 0.724, 0.970, 0.990, 1.000, 0.470, 0.352]
KAPPAS = (0.20, 0.15, 0.10)


def eta(values, true, kappa):
    return float((np.abs((np.ravel(values) - true) / true) < kappa).mean())


def two_component(x):
    x = np.asarray(x, float).reshape(-1, 1)
    g1 = GaussianMixture(1, n_init=5, random_state=0).fit(x)
    g2 = GaussianMixture(2, n_init=5, random_state=0).fit(x)
    bc = (skew(x.ravel()) ** 2 + 1) / kurtosis(x.ravel(), fisher=False)
    return float(g1.bic(x) - g2.bic(x)), float(bc), sorted(g2.means_.ravel().tolist())


def main_analyze_paper_figdata():
    pre = np.loadtxt(os.path.join(SRC, "Dim_fractal_matrix_pre_10sys_30000length_gap10_500times.dat"))
    tru = np.loadtxt(os.path.join(SRC, "Dim_fractal_matrix_ture_10sys_30000length_gap10_500times.dat"))
    true_d2 = tru[0]

    L = ["# Reproduction of Table III/IV and of the bimodality statistics from the plotting data\n",
         "Data source: `raw_data/` (a copy of the raw .dat files used by `plot_MFRC_result.m`).\n",
         "## 1. Success rates (MFRC and single-task RC, 500 realizations)\n",
         "| system | MFRC kappa=0.20 | kappa=0.15 | kappa=0.10 | RC kappa=0.20 | kappa=0.15 | kappa=0.10 | true D2 |",
         "|---|---|---|---|---|---|---|---|"]
    ok_m = ok_r = 0
    for i, nm in enumerate(RC_FILE):
        m = [eta(pre[:, i], true_d2[i], k) for k in KAPPAS]
        ok_m += int(abs(m[0] - PAPER_MFRC[i]) < 5e-4)
        f = os.path.join(SRC, "%s_RC_fractal_dim_30000length_pre_gap10_500times.dat" % nm)
        ft = os.path.join(SRC, "%s_RC_fractal_dim_30000length_ture_gap10_500times.dat" % nm)
        rc_true = float(np.ravel(np.loadtxt(ft))[0])
        rcp = np.loadtxt(f)
        r = [eta(rcp, rc_true, k) for k in KAPPAS]
        ok_r += int(abs(r[0] - PAPER_RC[i]) < 5e-4)
        L.append("| %s | **%.3f** | %.3f | %.3f | **%.3f** | %.3f | %.3f | %.3f |"
                 % (DISPLAY[i], m[0], m[1], m[2], r[0], r[1], r[2], true_d2[i]))
    L.append("\nValues reported in Table III of the manuscript: MFRC %s ; RC %s."
             % (", ".join("%.3f" % v for v in PAPER_MFRC), ", ".join("%.3f" % v for v in PAPER_RC)))
    L.append("\n**Reproduction: MFRC %d/10 and RC %d/10 agree with the manuscript to four decimals.**\n" % (ok_m, ok_r))

    L.append("## 2. Bimodality of the D2 distribution (original data, 500 realizations)\n")
    L.append("| system | Delta BIC | Sarle BC | two peak positions |")
    L.append("|---|---|---|---|")
    dbics, bcs = [], []
    for i in range(10):
        db, bc, means = two_component(pre[:, i])
        dbics.append(db); bcs.append(bc)
        L.append("| %s | %.1f | %.3f | %.2f / %.2f |" % (DISPLAY[i], db, bc, means[0], means[-1]))
    L.append("\n**All ten systems: Delta BIC = %.0f--%.0f (threshold 10), Sarle BC %.3f--%.3f.**\n"
             % (min(dbics), max(dbics), min(bcs), max(bcs)))

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    print("\n".join(L))
    print("\nwritten -> %s" % OUT)


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    import sys
    _steps = [main_analyze_paper_figdata]
    if len(sys.argv) > 1:
        _steps[int(sys.argv[1])]()
    else:
        for _f in _steps:
            _f()
