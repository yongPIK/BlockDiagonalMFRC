"""R2-7: relation between the functional modularity Q and reconstruction success.

Merged from: c14_undiag_Q_vs_success.py, c15_r27_undiag_Q.py
"""

try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import json
import os
import sys
import numpy as np
from scipy.stats import mannwhitneyu, pearsonr, pointbiserialr


# ========================================================================
# c14_undiag_Q_vs_success.py
# ========================================================================

"""R2-7: relation between the functional c14_undiag_q_vs_success_modularity Q and reconstruction
success in the *improved single-reservoir* experiment (Eq. (9)-(10)), using the
500-realization data shipped with the code in Desktop/MFRC_undiag.

In that experiment the off-diagonal scaling is FIXED (scale_factor = 1 in
multi_regress_RC_sprottBC.m), so Q varies ONLY through the random draw of the
reservoir - there is no variation of s_p / n_sigma.  This therefore gives an
unconfounded test of the Q-success relation.
"""



# use the copy shipped in raw_data/ first, and fall back to the author's Desktop directory
_RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), "raw_data")
DIR = _RAW if os.path.isdir(_RAW) else r"C:\Users\KevinJiang\Desktop\MFRC_undiag\modularity_successrate"
PRE = {"SprottB": "Dim_fractal_matrix_pre_sprottB_500times.dat",
       "SprottC": "Dim_fractal_matrix_pre_sprottC_500times.dat"}
TRU = {"SprottB": "Dim_fractal_matrix_ture_sprottB_500times.dat",
       "SprottC": "Dim_fractal_matrix_ture_sprottC_500times.dat"}
QS = {"SprottB": "Q_max_vec_sprottBC1_500times.dat",
      "SprottC": "Q_max_vec_sprottBC2_500times.dat"}


def aurc(scores, labels):
    """Rank-based AUC of `scores` for predicting labels==1."""
    labels = np.asarray(labels).astype(bool)
    order = np.argsort(scores)
    ranks = np.empty(len(scores), float)
    ranks[order] = np.arange(1, len(scores) + 1)
    n1 = labels.sum()
    n0 = len(labels) - n1
    if n1 == 0 or n0 == 0:
        return float("nan")
    return float((ranks[labels].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def main_c14_undiag_q_vs_success():
    print("%-9s %7s %9s %11s %11s %8s %6s" %
          ("system", "eta", "Q mean", "Q|success", "Q|failure", "AUC", "p (MWU)"))
    for name in ("SprottB", "SprottC"):
        pre = np.loadtxt(os.path.join(DIR, PRE[name])).ravel()
        tru = np.loadtxt(os.path.join(DIR, TRU[name])).ravel()
        q = np.loadtxt(os.path.join(DIR, QS[name])).ravel()
        n = min(len(pre), len(tru), len(q))
        pre, tru, q = pre[:n], tru[:n], q[:n]
        ok = np.abs((pre - tru) / tru) < 0.20
        u, p = mannwhitneyu(q[ok], q[~ok], alternative="greater")
        print("%-9s %7.3f %9.3f %11.3f %11.3f %8.3f %6.2e  (n_succ=%d, n_fail=%d)"
              % (name, ok.mean(), q.mean(), q[ok].mean() if ok.any() else np.nan,
                 q[~ok].mean() if (~ok).any() else np.nan, aurc(q, ok.astype(int)), p,
                 ok.sum(), (~ok).sum()))
        print("        Q range [%.3f, %.3f], median %.3f" % (q.min(), q.max(), np.median(q)))


# ========================================================================
# c15_r27_undiag_Q.py
# ========================================================================

"""R2-7 support analysis, based on the author's own source code and data.

Part A -- the paper's own grid (Fig. 8d): reproduces the Pearson r = 0.84
between the success rate eta and the functional c15_r27_undiag_q_modularity Q on the released
Q_matrix / success-rate matrices, then repeats the same correlation *within*
fixed s_p rows and *within* fixed n_sigma columns (the confound test that
Referee 2 asks for).

Part B -- the improved single reservoir of Eqs. (9)-(10), i.e. the code in
Desktop/MFRC_undiag.  There the structural parameters are fixed
(scale_factor = 1, no s_p / n_sigma scan): Q varies only because the reservoir
realisation is redrawn, so the Q-success relation is measured without the
coupling confound.  500 realisations for Sprott B and for Sprott C are
available.
"""



# same as above: prefer the copy in raw_data/ (Q and success-rate grid files of Fig. 8)
GRID_DIR = _RAW if os.path.isdir(_RAW) else r"C:\Users\KevinJiang\Desktop\multifunctionRC\result_add_noise"
UNDIAG = _RAW if os.path.isdir(_RAW) else r"C:\Users\KevinJiang\Desktop\MFRC_undiag\modularity_successrate"
OUT15 = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results",
                     "c15_r27_undiag_Q.json")


def _safe_r(x, y):
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    if len(x) < 3 or np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return float("nan")
    return float(pearsonr(x, y)[0])


def _auc(scores, labels):
    labels = np.asarray(labels).astype(bool)
    order = np.argsort(scores)
    ranks = np.empty(len(scores), float)
    ranks[order] = np.arange(1, len(scores) + 1)
    n1, n0 = labels.sum(), (~labels).sum()
    if n1 == 0 or n0 == 0:
        return float("nan")
    return float((ranks[labels].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def part_a():
    q = np.loadtxt(os.path.join(GRID_DIR, "Q_matrix_sprottBC_500times.dat"))
    eta = {}
    for sysname in ("sprottB", "sprottC"):
        m = np.zeros((21, 8))
        for ix in range(1, 22):
            f = os.path.join(GRID_DIR,
                             "success_rate_matrix_%s_labIndex%02d.txt" % (sysname, ix))
            d = np.loadtxt(f)
            m[ix - 1] = d[:8, 0]
        eta[sysname] = m
    etabar = 0.5 * (eta["sprottB"] + eta["sprottC"])
    return {"pooled_r_Q_vs_eta_avg": _safe_r(q, etabar),
            "pooled_r_Q_vs_eta_B": _safe_r(q, eta["sprottB"]),
            "pooled_r_Q_vs_eta_C": _safe_r(q, eta["sprottC"]),
            "within_fixed_sp_mean": float(np.nanmean(
                [_safe_r(q[i], etabar[i]) for i in range(21)])),
            "within_fixed_nsigma_mean": float(np.nanmean(
                [_safe_r(q[:, j], etabar[:, j]) for j in range(8)])),
            "within_fixed_sp_all": [_safe_r(q[i], etabar[i]) for i in range(21)],
            "within_fixed_nsigma_all": [_safe_r(q[:, j], etabar[:, j]) for j in range(8)],
            "Q_min": float(q.min()), "Q_max": float(q.max()), "Q_mean": float(q.mean()),
            "eta_min": float(etabar.min()), "eta_max": float(etabar.max())}


def part_b():
    pre = {"SprottB": "Dim_fractal_matrix_pre_sprottB_500times.dat",
           "SprottC": "Dim_fractal_matrix_pre_sprottC_500times.dat"}
    tru = {"SprottB": "Dim_fractal_matrix_ture_sprottB_500times.dat",
           "SprottC": "Dim_fractal_matrix_ture_sprottC_500times.dat"}
    qs = {"SprottB": "Q_max_vec_sprottBC1_500times.dat",
          "SprottC": "Q_max_vec_sprottBC2_500times.dat"}
    res = {}
    for name in ("SprottB", "SprottC"):
        p = np.loadtxt(os.path.join(UNDIAG, pre[name])).ravel()
        t = np.loadtxt(os.path.join(UNDIAG, tru[name])).ravel()
        q = np.loadtxt(os.path.join(UNDIAG, qs[name])).ravel()
        n = min(len(p), len(t), len(q))
        p, t, q = p[:n], t[:n], q[:n]
        ok = np.abs((p - t) / t) < 0.20
        u, pval = mannwhitneyu(q[ok], q[~ok], alternative="greater")
        res[name] = {
            "n": int(n), "eta": float(ok.mean()),
            "n_success": int(ok.sum()), "n_fail": int((~ok).sum()),
            "Q_mean": float(q.mean()),
            "Q_success_mean": float(q[ok].mean()), "Q_fail_mean": float(q[~ok].mean()),
            "Q_median": float(np.median(q)),
            "Q_min": float(q.min()), "Q_max": float(q.max()),
            "Q_p05": float(np.percentile(q, 5)), "Q_p95": float(np.percentile(q, 95)),
            "fracQ_below_0.05": float((q < 0.05).mean()),
            "auc": _auc(q, ok), "mwu_p": float(pval),
            "pointbiserial_r": float(pointbiserialr(ok.astype(int), q)[0]),
            "pearson_r_Q_vs_absD2err": _safe_r(q, np.abs((p - t) / t))}
    return res


def main_c15_r27_undiag_q():
    out = {"partA_released_grid": part_a(), "partB_undiag_single_reservoir": part_b()}
    os.makedirs(os.path.dirname(OUT15), exist_ok=True)
    with open(OUT15, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    a = out["partA_released_grid"]
    print("[A] released grid (21 s_p x 8 n_sigma = 168 points)")
    print("    pooled r(Q, eta_avg)        = %.3f" % a["pooled_r_Q_vs_eta_avg"])
    print("    within fixed s_p   (mean r) = %.3f" % a["within_fixed_sp_mean"])
    print("    within fixed n_sig (mean r) = %.3f" % a["within_fixed_nsigma_mean"])
    print("    Q range [%.3f, %.3f]" % (a["Q_min"], a["Q_max"]))
    print("[B] MFRC_undiag, improved single reservoir, 500 realisations each")
    print("    %-8s %6s %9s %11s %10s %7s %9s %8s" %
          ("system", "eta", "Q mean", "Q|succ", "Q|fail", "AUC", "MWU p", "r_pb"))
    for k, v in out["partB_undiag_single_reservoir"].items():
        print("    %-8s %6.3f %9.3f %11.3f %10.3f %7.3f %9.2e %8.3f"
              % (k, v["eta"], v["Q_mean"], v["Q_success_mean"], v["Q_fail_mean"],
                 v["auc"], v["mwu_p"], v["pointbiserial_r"]))
    print("    saved -> %s" % OUT15)


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    _steps = [main_c14_undiag_q_vs_success, main_c15_r27_undiag_q]
    if len(sys.argv) > 1:
        _steps[int(sys.argv[1])]()
    else:
        for _f in _steps:
            _f()
