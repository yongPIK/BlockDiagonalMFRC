"""Objective of the equal-budget optimisation comparison.

One 100-node module per task: teacher forcing over trainLen steps (the first
initLen steps are dropped), ridge readout on the tail trainLen_vec[i] steps,
generative rollout of testLen steps from the last reservoir state, then the
RMSE over the per-system error window.  Mirrors Opt/func_data_train.m.

    eval_params_mod(params, idx, _, rng, stats) -> float

params : [sigma, d, rho] repeated for every module listed in idx
idx    : system indices of the modules to train
stats  : dict collecting the elapsed time in key "seconds"
"""

import time

import numpy as np

from mfrc import rc, systems
from c8e_optimization_benchmark import RES, TRAINLEN, INITLEN, TESTLEN, ALPHA, REG

# per-system window used for the RMSE (SprottA ... HyperSprottB)
ERROR_LEN = [5000, 1000, 1000, 2000, 200, 300, 100, 800, 500, 2000]

_DATA = None


def _load():
    global _DATA
    if _DATA is None:
        _DATA = systems.load_all()
    return _DATA


def eval_params_mod(params, idx, _, rng, stats):
    data = _load()
    total = 0.0
    for k, i in enumerate(idx):
        sigma = float(params[3 * k])
        d = float(params[3 * k + 1])
        rho = float(params[3 * k + 2])
        t0 = time.perf_counter()
        n_in = systems.IN_SIZE[i]
        W_in = rc.gene_Win(RES, n_in, sigma, rng)
        W_r = rc.gene_Wr(RES, d, rho, rng)
        X = rc.run_reservoir_forced([W_in], W_r, [data[i]], TRAINLEN, INITLEN,
                                    ALPHA, [0], [RES])
        L = systems.TRAINLEN_VEC[i]
        Yt = data[i][:, TRAINLEN - L + 1: TRAINLEN + 1]
        Wout = rc.ridge_readout(X[:, -L:], Yt, REG)
        Y = rc.rollout_single(W_in, W_r, Wout, data[i], TRAINLEN, TESTLEN,
                              ALPHA, x_init=X[:, -1])
        E = ERROR_LEN[i]
        true = data[i][:, TRAINLEN + 1: TRAINLEN + 1 + TESTLEN]
        total += float(np.sqrt(np.mean((Y[:, :E] - true[:, :E]) ** 2)))
        stats["seconds"] += time.perf_counter() - t0
    return total
