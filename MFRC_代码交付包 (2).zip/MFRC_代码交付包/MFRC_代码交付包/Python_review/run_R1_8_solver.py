
try:                                   # make console output robust
    import sys as _sys
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
"""R1-8: solver / time-step robustness (lambda_1, D2, released-data reference).

Merged from: exp_c7_solver.py, make_c7_table.py, c21_dat_as_ref.py
"""

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from mfrc import gp, odes, rc, systems
import sys as _sys_c7
C7 = _sys_c7.modules[__name__]   # exp_c7_solver.py is merged into this file


# ========================================================================
# exp_c7_solver.py
# ========================================================================

"""C7: numerical-solver robustness of the reference data (Referee 1, comment 8,
which the referee flagged as the exp_c7_solver_main item).

Design.  The reconstruction protocol is defined per time step at dt = 0.01, so
we compare integrators on a common dt = 0.01 series:

  rk4_001      RK4, dt = 0.01                      (published protocol)
  dp5_001      Dormand-Prince 5(4), dt = 0.01      (same step, 5th order)
  rk4_0005     RK4, dt = 0.005, decimated by 2     (same dt = 0.01 series)
  rk4_0001     RK4, dt = 0.001, decimated by 10    (near-exact reference)
  rk4_002      RK4, dt = 0.02                      (invariants only)

For every variant we report the correlation dimension (computed on the same
physical window, per-variable max-abs scaling like the pipeline), the maximal
Lyapunov exponent (same physical time span) and the reconstruction success rate
over 100 realizations of the released protocol.
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
CACHE = os.path.join(HERE, "cache", "odes2")
T_END = 1000.0                 # physical time span of every generated series
T_D2 = (200.0, 500.0)          # physical window for the D2 comparison
SPACING = 0.1
T_LE = 300.0                   # physical span for the Lyapunov estimate
N_REAL = 50

# tag -> (dt, method, decimation)
VARIANTS = [("rk4_001", 0.01, "rk4", 1),
            ("dp5_001", 0.01, "dp5", 1),
            ("rk4_0005", 0.005, "rk4", 2),
            ("rk4_0001", 0.001, "rk4", 10),
            ("rk4_002", 0.02, "rk4", 0.5)]
SYSTEMS = ["Lorenz", "Roessler", "Chen", "SprottB", "SprottC", "HyperOsc",
           "HyperSprottB"]


def get_traj(name, tag, dt, method):
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, "%s_%s.npy" % (name, tag))
    if os.path.exists(path):
        return np.load(path)
    n = int(round(T_END / dt)) + 1
    t = odes.integrate(name, dt=dt, n=n, method=method,
                       burn=odes.CATALOG[name][2])
    np.save(path, t)
    return t


def series_at_001(name, tag, dt, method, decim):
    """Return the series resampled to dt = 0.01 (decim may be 0.5 for dt=0.02)."""
    traj = get_traj(name, tag, dt, method)
    if decim == 1:
        return traj
    if decim >= 1:
        return traj[::int(decim)]
    return traj                     # dt=0.02: not resampled (invariants only)


def d2_of(traj, dt):
    i0, i1 = int(round(T_D2[0] / dt)), int(round(T_D2[1] / dt))
    step = max(1, int(round(SPACING / dt)))
    w = rc.normalize(traj[i0:i1:step].T)      # same scaling as the pipeline
    return float(gp.gp_released(w.T)[0])


def lyapunov(name, dt, method):
    f, ic, burn = odes.CATALOG[name]
    step_fn = odes.rk4_step if method == "rk4" else odes.dopri5_step
    rng = np.random.default_rng(1)
    y = np.array(ic, float)
    for _ in range(int(round(burn * 0.01 / dt))):
        y = step_fn(f, y, dt)
    delta = 1e-9
    yp = y + delta * rng.standard_normal(y.size)
    n = int(round(T_LE / dt))
    lsum = 0.0
    for k in range(n):
        y = step_fn(f, y, dt)
        yp = step_fn(f, yp, dt)
        d = yp - y
        dist = max(float(np.linalg.norm(d)), 1e-14)
        lsum += np.log(dist / delta)
        yp = y + delta * (d / dist)
    return lsum / (n * dt)


def rc_experiment(name, traj):
    i = systems.NAMES.index(name)
    data = rc.normalize(traj.T)
    sigma, k, rho = systems.PARA[i]
    n = systems.RES_SIZE[i]
    L = systems.TRAINLEN_VEC[i]
    trainLen, initLen, testLen = systems.TRAINLEN, systems.INITLEN, systems.TESTLEN
    if data.shape[1] < trainLen + testLen + 2:
        return None
    true = gp.gp_released(
        data[:, trainLen + 1: trainLen + testLen + 1].T[0::10])[0]
    d2 = np.zeros(N_REAL)
    for s in range(N_REAL):
        rng = np.random.default_rng(1000 + s)
        W_in = rc.gene_Win(n, systems.IN_SIZE[i], sigma, rng)
        W_r = rc.gene_Wr(n, k, rho, rng)
        X = rc.run_reservoir_single(W_in, W_r, data, trainLen, initLen, systems.ALPHA)
        Yt = data[:, trainLen - L + 1: trainLen + 1]
        Wout = rc.ridge_readout(X[:, -L:], Yt, systems.REG)
        Y = rc.rollout_single(W_in, W_r, Wout, data, trainLen, testLen,
                              systems.ALPHA, x_init=X[:, -1])
        d2[s] = gp.gp_released(Y.T[0::10])[0]
    return {"eta": float((np.abs((d2 - true) / true) < 0.20).mean()),
            "d2_true": float(true), "d2_pred_mean": float(d2.mean()),
            "d2_pred_std": float(d2.std()), "n": N_REAL}


def exp_c7_solver_run_one(name):
    ckpt = os.path.join(RES, "c7_%s.json" % name)
    out = {"name": name, "stats": {}, "rc": {}}
    if os.path.exists(ckpt):
        with open(ckpt) as fh:
            out = json.load(fh)
    for tag, dt, method, decim in VARIANTS:
        if tag in out["stats"] and (tag in out["rc"]
                                    or decim < 1
                                    or out["stats"][tag].get("n_points", 0)
                                    < systems.TRAINLEN + systems.TESTLEN + 2):
            continue
        traj = get_traj(name, tag, dt, method)
        out["stats"][tag] = {
            "dt": dt, "d2": d2_of(traj, dt), "lambda1": lyapunov(name, dt, method),
            "n_points": int(traj.shape[0]),
        }
        ser = series_at_001(name, tag, dt, method, decim)
        if decim >= 1 and ser.shape[0] >= systems.TRAINLEN + systems.TESTLEN + 2:
            out["rc"][tag] = rc_experiment(name, ser)
        os.makedirs(RES, exist_ok=True)
        with open(ckpt, "w") as fh:
            json.dump(out, fh, indent=1)
    return out


def main_exp_c7_solver():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(RES, "c7_solver.json"))
    ap.add_argument("--systems", default=",".join(SYSTEMS))
    ap.add_argument("--jobs", type=int, default=7)
    args = ap.parse_args()
    names = [s for s in args.systems.split(",") if s]
    res, t0 = [], time.time()
    with ProcessPoolExecutor(max_workers=min(args.jobs, len(names))) as pool:
        for name, r in zip(names, pool.map(exp_c7_solver_run_one, names)):
            res.append(r)
            print("done %s (%.1f min)" % (name, (time.time() - t0) / 60), flush=True)
    with open(args.out, "w") as fh:
        json.dump(res, fh, indent=1)

    print("\n%-14s %-10s %8s %9s %9s %8s" %
          ("system", "variant", "D2", "lambda1", "eta", "pred_sd"))
    for r in res:
        for tag, _, _, _ in VARIANTS:
            s = r["stats"][tag]
            e = r["rc"].get(tag, {})
            print("%-14s %-10s %8.4f %9.4f %9s %8s"
                  % (r["name"], tag, s["d2"], s["lambda1"],
                     "%.3f" % e["eta"] if e else "-",
                     "%.3f" % e["d2_pred_std"] if e else "-"))
    print("\nreference (rk4_0001) D2 and lambda1 per system:")
    for r in res:
        print("  %-14s D2=%.4f lambda1=%.4f"
              % (r["name"], r["stats"]["rk4_0001"]["d2"],
                 r["stats"]["rk4_0001"]["lambda1"]))
    print("\n(written to %s)" % args.out)


# ========================================================================
# make_c7_table.py
# ========================================================================

"""Build the solver-convergence table for R1-8 from the c7 result files.

Reads:  results/c7_main.json (5 systems), c7_extra.json (SprottA/SprottD),
        c7_stats_HyperOsc.json, c7_stats_HyperSprottB.json
 Writes: results/13_solver_convergence_table.md and prints a LaTeX table for the reply drafts.
"""


OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "results", "13_solver_convergence_table.md")

make_c7_table_ORDER = ["Lorenz", "Roessler", "Chen", "SprottA", "SprottB", "SprottC", "SprottD",
         "HyperOsc", "HyperSprottB"]
DISPLAY = {"Lorenz": "Lorenz", "Roessler": "Rössler", "Chen": "Chen",
           "SprottA": "Sprott A", "SprottB": "Sprott B", "SprottC": "Sprott C",
           "SprottD": "Sprott D", "HyperOsc": "Hyper-osc", "HyperSprottB": "Hyper-Sprott B"}
VARI = [("rk4_001", "$dt=0.01$"), ("dp5_001", "DP5"), ("rk4_0005", "$dt=0.005$"),
        ("rk4_0001", "$dt=0.001$")]


def load():
    recs = {}
    for name, fn in [("c7_main.json", None), ("c7_extra.json", None),
                     ("c7_stats_HyperOsc.json", None), ("c7_stats_HyperSprottB.json", None)]:
        p = os.path.join(RES, fn if fn else name)
        if not os.path.exists(p):
            continue
        d = json.load(open(p, encoding="utf-8"))
        for r in (d if isinstance(d, list) else [d]):
            recs[r["name"]] = r
    return recs


def main_make_c7_table():
    recs = load()
    rows = []
    for name in make_c7_table_ORDER:
        r = recs.get(name)
        if not r:
            continue
        st, rc = r["stats"], r.get("rc", {})
        ref = st["rk4_0001"]
        a = st["rk4_001"]
        dl = abs(a["lambda1"] - ref["lambda1"]) / abs(ref["lambda1"]) * 100
        dd = abs(a["d2"] - ref["d2"]) / abs(ref["d2"]) * 100
        etas = [rc[k]["eta"] if k in rc else None for k, _ in VARI]
        rows.append((name, a["lambda1"], ref["lambda1"], dl,
                     a["d2"], ref["d2"], dd, etas))

    lines = ["# R1-8 solver / time-step convergence (RK4, dt=0.01 against the near-exact reference dt=0.001)\n",
             "Both lambda_1 and D2 are computed **directly from the raw numerically integrated "
             "trajectories**, without any reconstruction; eta is the **reconstruction success rate** "
             "obtained by feeding the data of that integration scheme into the same RC protocol "
             "(kappa = 0.2, 50 realizations).\n",
             "| system | lambda_1 (dt=0.01) | lambda_1 (ref) | Delta lambda_1 | D2 (dt=0.01) | D2 (ref) | Delta D2 | eta (0.01 / DP5 / 0.005 / ref) |",
             "|---|---|---|---|---|---|---|---|"]
    for name, l1, l1r, dl, d2, d2r, dd, etas in rows:
        es = " / ".join("%.2f" % e if e is not None else "—" for e in etas)
        lines.append("| %s | %.4f | %.4f | %.2f%% | %.4f | %.4f | %.2f%% | %s |"
                     % (DISPLAY[name], l1, l1r, dl, d2, d2r, dd, es))

    dls = [r[3] for r in rows]
    dds = [r[6] for r in rows]
    lines.append("\n**Summary**: median relative difference of lambda_1 is %.2f%%, "
                 "%d/%d systems are within 2%%, the worst case is %.2f%% (%s); "
                 "the largest relative difference of D2 is %.2f%% (%s)."
                 % (sorted(dls)[len(dls) // 2], sum(1 for x in dls if x <= 2.0), len(dls),
                    max(dls), DISPLAY[rows[dls.index(max(dls))][0]],
                    max(dds), DISPLAY[rows[dds.index(max(dds))][0]]))
    lines.append("\nThe Sprott A trajectory drifts only at the $10^{-5}$ level over 1000 time units "
                 "(its lambda_1 is about 0.011, the smallest of all systems), so all integration "
                 "schemes agree to the precision shown in the table.\n")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    # LaTeX table for the reply drafts
    tex = [r"\begin{center}\small",
           r"\begin{tabular}{@{}lccccccc@{}}",
           r"\toprule",
           r"system & $\lambda_1$(0.01) & $\lambda_1$(ref) & $\Delta\lambda_1$ & "
           r"$\Dtwo$(0.01) & $\Dtwo$(ref) & $\Delta\Dtwo$ & $\eta$ (0.01/DP5/0.005/ref)\\",
           r"\midrule"]
    for name, l1, l1r, dl, d2, d2r, dd, etas in rows:
        es = "/".join("%.2f" % e if e is not None else "—" for e in etas)
        tex.append(r"%s & %.3f & %.3f & %.1f\%% & %.3f & %.3f & %.1f\%% & %s\\"
                   % (DISPLAY[name], l1, l1r, dl, d2, d2r, dd, es))
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    print("\n".join(lines))
    print("\n----- LaTeX -----")
    print("\n".join(tex))
    print("\nwritten -> %s" % OUT)


# ========================================================================
# c21_dat_as_ref.py
# ========================================================================

"""R1-8 alternative: treat the *released* .dat data as the reference.

For every system of the R1-8 table we recompute the three quantities directly

  D2      same GP estimator, same scaling, same physical window (200-500 s),
          same decimation (every 10th point)
  eta     the released single-reservoir protocol of exp_c7_solver.rc_experiment
          (trainLen 60000, initLen 6000, testLen 30000, 50 realizations)
  lambda1 Rosenstein estimator on 30000 samples, two fit windows to show the
          estimator's own sensitivity

Outputs results/c21_dat_as_ref.json (+ printed table).
"""


for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_v, "1")


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

c21_dat_as_ref_ORDER = ["Lorenz", "Roessler", "Chen", "SprottA", "SprottB", "SprottC",
         "SprottD", "HyperOsc", "HyperSprottB"]
D2_WIN = (20000, 50000, 10)          # samples: 200-500 s at dt=0.01, every 10th
LE_SEG = (60000, 90000)              # 300 s of samples for the Rosenstein fit
PATH = os.path.join(HERE, "results", "c21_dat_as_ref.json")


def rosenstein(x, dt, m=3, tau=10, kmax=1200, n_ref=300, delta=1, seed=0,
               fit=(1.0, 2.0)):
    rng = np.random.default_rng(seed)
    N = len(x)
    M = N - (m - 1) * tau
    V = np.stack([x[i * tau: i * tau + M] for i in range(m)], axis=1)
    idx = rng.choice(M, size=min(n_ref, M), replace=False)
    div = np.zeros(kmax)
    cnt = np.zeros(kmax)
    for i in idx:
        d = np.linalg.norm(V - V[i], axis=1)
        d[max(0, i - delta - 1): i + delta + 2] = np.inf
        j = int(np.argmin(d))
        if not np.isfinite(d[j]):
            continue
        for k in range(kmax):
            if i + k >= M or j + k >= M:
                break
            div[k] += np.log(max(np.linalg.norm(V[i + k] - V[j + k]), 1e-12))
            cnt[k] += 1
    ok = cnt > 0
    S = np.full(kmax, np.nan)
    S[ok] = div[ok] / cnt[ok]
    t = np.arange(kmax) * dt
    sel = ok & (t >= fit[0]) & (t <= fit[1]) & np.isfinite(S)
    return float(np.polyfit(t[sel], S[sel], 1)[0])


def c21_dat_as_ref_run_one(name):
    i = systems.NAMES.index(name)
    d = systems.load_normalized(i)                  # (dim, T)
    a, b, s = D2_WIN
    q = d[:, a:b:s].T
    d2 = float(gp.gp_released(q)[0])
    eta = C7.rc_experiment(name, d.T)
    x = d[0, LE_SEG[0]:LE_SEG[1]]
    l1 = {"fit_0.5_1.5": rosenstein(x, 0.01, fit=(0.5, 1.5)),
          "fit_1.0_2.0": rosenstein(x, 0.01, fit=(1.0, 2.0))}
    return {"name": name, "d2": d2, "eta": eta, "lambda1": l1}


def main_c21_dat_as_ref():
    t0 = time.time()
    with ProcessPoolExecutor(max_workers=min(5, len(c21_dat_as_ref_ORDER))) as pool:
        res = list(pool.map(c21_dat_as_ref_run_one, c21_dat_as_ref_ORDER))
    out = {"window": {"d2": D2_WIN, "le_segment": LE_SEG},
           "method": "quantities computed directly from the released .dat files",
           "systems": res}
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    with open(PATH, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    print("%-14s %8s %8s | %8s %8s | %8s %8s | %6s" %
          ("system", "D2(.dat)", "D2(0.01)", "lam(.dat)", "lam(0.01)",
           "eta(.dat)", "eta(0.01)", "min"))
    for r in res:
        lam = min(r["lambda1"].values())
        print("%-14s %8.3f %8.3f | %8.4f %8.4f | %8.2f %8.2f" %
              (r["name"], r["d2"], float("nan"), lam, float("nan"),
               r["eta"]["eta"], float("nan")))
    print("(%.1f min) written: %s" % ((time.time() - t0) / 60, PATH))


# ========================================================================
# entry point: run every step of this item (argv[1] = step index)

if __name__ == "__main__":
    import sys
    _steps = [main_exp_c7_solver, main_make_c7_table, main_c21_dat_as_ref]
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        # drop the step index so that argparse in the step sees only its own flags
        _steps[int(sys.argv.pop(1))]()
    else:
        for _f in _steps:
            _f()
