clc;
clear;

% requires gene_Win / gene_Wr / Grassberger_Procaccia_updated from shared/
here = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data', 'TimeSeries')));


P_datas = load('data_hyperchaotic_oscillator_1000_0.01.dat');
data = P_datas';

for i = 1:4
    data(i, :) = data(i, :) ./ max(abs(data(i, :)));  % normalized
end

trainLen = 10000;
testLen  = 30000;
initLen  = 1000;
inSize   = 4;
outSize  = 4;
resSize  = 500;
add_dim  = 0;

Dim_fractal_matrix_ture = zeros(500, 1);
Dim_fractal_matrix_pre  = zeros(500, 1);
gap = 10;

para = [0.100000000000000  0.299007202733509  171.705780833805 ...
       -1.21189202441243  1.00000000000000e-05];   % hyperchaotic_oscillator

a       = para(1);
W_in_a  = para(2);
k       = para(3);
eig_rho = para(4);
reg     = para(5);

parfor iii = 1:500
    W_in_type = 1;
    W_r_type  = 1;
    Win = gene_Win(resSize, inSize, add_dim, W_in_a, W_in_type);
    W   = gene_Wr(resSize, k, eig_rho, W_r_type);

    X = zeros(resSize, trainLen - initLen);
    Yt = data(:, initLen + 2 : trainLen + 1);

    x = zeros(resSize, 1);
    for t = 1:trainLen
        u = data(:, t);
        x = (1 - a) * x + a * tanh(Win * u + W * x);
        if t > initLen
            X(:, t - initLen) = x;
        end
    end

    X_T = X';
    Wout = Yt * X_T / (X * X_T + reg * eye(resSize));

    Y = zeros(outSize, testLen);
    u = data(:, trainLen + 1);
    x = X(:, 1);
    for t = 1:testLen
        x = (1 - a) * x + a * tanh(Win * u + W * x);
        u = Wout * x;
        Y(:, t) = u;
    end

    errorLen = testLen;
    Y_t = data(:, trainLen + 2 : trainLen + errorLen + 1);
    Y_t_T = Y_t';
    Y_T = Y';

    % updated GP: automatic Theiler window + automatic scaling region
    Dim_fractal_matrix_ture(iii) = Grassberger_Procaccia_updated(inSize, ...
        Y_t_T(1:gap:errorLen, :));
    Dim_fractal_matrix_pre(iii) = Grassberger_Procaccia_updated(inSize, ...
        Y_T(1:gap:errorLen, :));
end

out_dir = fullfile(here, 'RC_fractal_10sys');
if ~exist(out_dir, 'dir'); mkdir(out_dir); end

dlmwrite(fullfile(out_dir, 'hyperchaotic_oscillator_RC_fractal_dim_30000length_true_gap10_500times_updated.dat'), ...
    Dim_fractal_matrix_ture, 'delimiter', '\t');
dlmwrite(fullfile(out_dir, 'hyperchaotic_oscillator_RC_fractal_dim_30000length_pre_gap10_500times_updated.dat'), ...
    Dim_fractal_matrix_pre, 'delimiter', '\t');



fprintf('Finished updated-GP RC run.\n');
