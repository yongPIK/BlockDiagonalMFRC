clc;
clear;

% requires gene_Win / gene_Wr / Grassberger_Procaccia from shared/
here = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data', 'TimeSeries')));



% load the data
P_datas = load('data_hyperchaotic_oscillator_1000_0.01.dat');
data = P_datas';

% data(1,:)=data(1,:)./max(abs(data(1,:))); %normalized
% data(2,:)=data(2,:)./max(abs(data(2,:)));
% data(3,:)=data(3,:)./max(abs(data(3,:)));
for i=1:4
    data(i,:)=data(i,:)./max(abs(data(i,:))); %normalized
end

% generate the ESN reservoir 
trainLen = 10000;
testLen = 30000;
initLen = 1000;
inSize = 4;
outSize =4;

resSize = 500;
add_dim = 0;

Dim_fractal_matrix_ture=zeros(500,1);
Dim_fractal_matrix_pre=zeros(500,1);
gap=10;
% para=[0.100000000000000	0.125746762061917	405.335058731385	1.53843634290604	1.00000000000000e-05];% hyper_sprottB 
para=[0.100000000000000	0.299007202733509	171.705780833805	-1.21189202441243	1.00000000000000e-05];% hyperchaotic_oscillator
% para=[0.100000000000000	2.23394122119754	24.5498565590683	-0.00227173616567419	1.00000000000000e-05];% sel_kov
% para=[0.100000000000000	2.88942563792231	6.20808716642222	-0.0376176384094279	1.00000000000000e-05];% chen
% para=[0.100000000000000	0.958860215120228	1.02505593204508	2.70376617790837	1.00000000000000e-05];%roessler
% para=[0.100000000000000	2.81262506997391	94.9666913419282	-0.730966611140523	1.00000000000000e-05];% lorenz
% para=[0.100000000000000	1.03375020271522	1	3	1.00000000000000e-05];% sprottD
% para=[0.100000000000000	0.287709384851287	74.0972678053068	1.97938743778260	1.00000000000000e-05];% sprottC
% para=[0.100000000000000	0.524801417382458	2.80696270207184	2.72180624436781	1.00000000000000e-05];% sprottB
% para=[0.100000000000000	0.166903974271684	59.1510248401282	-2.82953128218694	1.00000000000000e-05];% sprottA



a = para(1) ; % leaking rate
W_in_a = para(2);
k = para(3); 
eig_rho = para(4);
reg = para(5);  % regularization coefficient
parfor iii=1:500
W_in_type = 1;   W_r_type = 1;
Win = gene_Win(resSize,inSize,add_dim,W_in_a,W_in_type);
W = gene_Wr(resSize,k,eig_rho,W_r_type);
 % b=rand(resSize,1)-0.5;
% allocated memory for the design (collected states) matrix
 X = zeros(resSize,trainLen-initLen);                                             %%%%%  1+inSize+resSize
% X = zeros(1+inSize+resSize,trainLen-initLen);    % need to change while with bias  

% set the corresponding target matrix directly
Yt = data(:,initLen+2:trainLen+1);

% run the reservoir with the data and collect X
x = zeros(resSize,1);
for t = 1:trainLen
    u = data(:,t);
    x = (1-a)*x + a*tanh( Win*u + W*x );                %%%%%   Win*[1;u]
    % x = (1-a)*x + a*tanh( Win*[1;u]+ W*x );   
    if t > initLen
         X(:,t-initLen) = x;                       %%%%%  [1;u;x];
        % X(:,t-initLen) = [1;u;x]; 
    end
end

% train the output


X_T = X';
% Wout = Yt*X_T * inv(X*X_T + reg*eye(1+inSize+resSize));
Wout = Yt*X_T / (X*X_T + reg*eye(resSize));                             %%%%%  1+inSize+resSize
% Wout = Yt*pinv(X);

% Yt_train=Wout*X;
% figure(1);
% plot( Yt(1,1:trainLen-initLen), 'color', [0,0.75,0] );
% hold on;
% plot( Yt_train(1,1:trainLen-initLen), 'b' );
% hold off;
% axis tight;
% title('The predicted and true values of the Lorenz system in training phase');
% legend('Target signal', ' predicted signal');



Y = zeros(outSize,testLen);
u = data(:,trainLen+1);

x = X(:,1);
for t = 1:testLen 
    % u = data(1:3,trainLen+t);
    x = (1-a)*x + a*tanh( Win*u + W*x );                %%%%% Win*[1;u]
    % x = (1-a)*x + a*tanh( Win*[1;u] + W*x);
    
    u = Wout*x;                            %%%%%  [1;u;x];
    % u = Wout*[1;u;x]; 
    Y(:,t) = u;
   
    % generative mode:
    % u = y;
    % this would be a predictive mode:
    % u = data(:,trainLen+t+1);
end

errorLen = testLen;
Y_t =data(:,trainLen+2:trainLen+errorLen+1);
% mse = sum((Y_t(1,1:errorLen)-Y(1,1:errorLen)).^2)./errorLen;
% mse = sum((Y_t(1,1:errorLen)-Y(1,1:errorLen)).^2)./errorLen+sum((Y_t(3,1:errorLen)-Y(3,1:errorLen)).^2)./errorLen;
% rmse = sqrt(mse);
Y_t_T=Y_t';
Y_T=Y';

Dim_fractal_matrix_ture(iii)=Grassberger_Procaccia(inSize,Y_t_T(1:gap:errorLen,:));
Dim_fractal_matrix_pre(iii)=Grassberger_Procaccia(inSize,Y_T(1:gap:errorLen,:));


end
% % plot some signals
% figure(2);
% plot( Y_t(1,1:errorLen), 'color', [0,0.75,0] );
% hold on;
% plot( Y(1,1:errorLen), 'b' );
% hold off;
% axis tight;
% title('The predicted and true values of the Roessler system');
% legend('Target signal', ' predicted signal');
% % saveas(1,'predict_plot.fig');
% % figure(2);
% % plot( Y(1,1:errorLen), Y(3,1:errorLen),'color', [0,0.75,0] );
% % title('attractor of the Lorenz system');
% figure(3);
% plot3(Y(1,:),Y(2,:),Y(3,:))
out_dir = fullfile(here, 'RC_fractal_10sys');
if ~exist(out_dir, 'dir'); mkdir(out_dir); end
% File names follow the convention of the shipped 10-system results
% (Data/result_MFRC/result_MFRC/ and Data/GP_updated/), i.e. the true-value file
% carries the '_ture_' spelling used by cal_success_rate.m and the Python readers.
dlmwrite(fullfile(out_dir, 'hyperchaotic_oscillator_RC_fractal_dim_30000length_ture_gap10_500times.dat'), Dim_fractal_matrix_ture, 'delimiter', '\t');
dlmwrite(fullfile(out_dir, 'hyperchaotic_oscillator_RC_fractal_dim_30000length_pre_gap10_500times.dat'), Dim_fractal_matrix_pre, 'delimiter', '\t');
