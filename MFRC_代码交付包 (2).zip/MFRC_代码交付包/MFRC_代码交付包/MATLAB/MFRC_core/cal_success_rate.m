clear;
clc;

% Success rates computed from the 500-realization D2 results (BD column of
% Table 3 / Table 5). The data are in Data/result_MFRC/result_MFRC/.
here = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(here, '..', '..', 'Data', 'result_MFRC', 'result_MFRC')));

fractal_dim_pre = load('Dim_fractal_matrix_pre_10sys_30000length_gap10_500times.dat');
fractal_dim_true = load('Dim_fractal_matrix_ture_10sys_30000length_gap10_500times.dat');
num=500;

err_fractal_dim=abs((fractal_dim_pre -fractal_dim_true)./fractal_dim_true);
for kappa = [0.20 0.15 0.10]
    suc_rat_all_MFRC = sum(err_fractal_dim < kappa, 1)/num;
    fprintf('kappa = %.2f  MFRC success rate (%%): ', kappa);
    fprintf('%.1f ', 100*suc_rat_all_MFRC);
    fprintf('\n');
end

% single-task RC row (RC column of Table 3)
names = {'SprottA','SprottB','SprottC','SprottD','Lorenz', ...
    'roessler','chen','sel_kov','hyperchaotic_oscillator','hyper_sprottB'};
suc_rat_all_RC = zeros(1, numel(names));
for i = 1:numel(names)
    pre = load([names{i} '_RC_fractal_dim_30000length_pre_gap10_500times.dat']);
    tru = load([names{i} '_RC_fractal_dim_30000length_ture_gap10_500times.dat']);
    suc_rat_all_RC(i) = mean(abs((pre - tru)./tru) < 0.20);
end
fprintf('kappa = 0.20  single-task RC success rate (%%): ');
fprintf('%.1f ', 100*suc_rat_all_RC);
fprintf('\n');

