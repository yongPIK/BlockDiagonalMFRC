function mi = mutual_information(X, Y, numBins)
    % joint histogram
    jointHist = histcounts2(X(:), Y(:), numBins, 'Normalization', 'probability');
    % marginal probabilities
    marginalX = sum(jointHist, 2);
    marginalY = sum(jointHist, 1);
    % avoid log(0) for empty bins
    jointHist(jointHist == 0) = eps;
    marginalX(marginalX == 0) = eps;
    marginalY(marginalY == 0) = eps;
    % entropies
    HX = -sum(marginalX .* log(marginalX));
    HY = -sum(marginalY .* log(marginalY));
    HXY = -sum(jointHist(:) .* log(jointHist(:)));
    % mutual information
    mi = HX + HY - HXY;
end
