function [D2, r_values, C] = Grassberger_Procaccia_updated(m, TS, theiler)
% GRASSBERGER_PROCACCIA_UPDATED  Corrected GP estimator.
%
% Changes relative to the released version:
%   1. automatic Theiler window (default max(1, floor(N/10)));
%   2. data-driven radius range (1st--60th percentile of pairwise distances);
%   3. automatic local-slope scaling-region selection.

Y = TS;
N = size(Y, 1);

if nargin < 3 || isempty(theiler)
    theiler = max(1, floor(N / 10));
end

% ------------------------------------------------------------------
% Data-driven radius range
% ------------------------------------------------------------------
step = max(1, floor(N / 500));
sub = Y(1:step:N, :);
dsub = [];
for i = 1:size(sub, 1) - 1
    d = sub(i + 1:end, :) - sub(i, :);
    dsub = [dsub; sqrt(sum(d.^2, 2))];
end
dsub = dsub(dsub > 0);

if isempty(dsub)
    r_min = 1e-2;
    r_max = 1.0;
else
    ds = sort(dsub);
    i1  = max(1, round(0.01 * numel(ds)));
    i60 = min(numel(ds), round(0.60 * numel(ds)));
    r_min = ds(i1);
    r_max = ds(i60);
end
if ~(r_max > r_min)
    r_max = r_min * 10;
end

n_r = 40;
r_values = logspace(log10(r_min), log10(r_max), n_r);

% ------------------------------------------------------------------
% Correlation integral with Theiler window
% ------------------------------------------------------------------
counts = zeros(1, n_r);
for i = 1:N
    j = i + 1:N;
    keep = abs(j - i) > theiler;
    if ~any(keep)
        continue;
    end
    d = Y(j(keep), :) - Y(i, :);
    dist = sqrt(sum(d.^2, 2));
    counts = counts + sum(dist < r_values, 1);
end

C = 2 * counts / (N * (N - 1));

log_r = log(r_values);
log_C = log(C);
valid = ~isinf(log_C) & ~isnan(log_C) & log_C > -12;
log_r = log_r(valid);
log_C = log_C(valid);

if numel(log_r) < 8
    D2 = NaN;
    return;
end

% ------------------------------------------------------------------
% Automatic scaling-region selection
% ------------------------------------------------------------------
slopes = diff(log_C) ./ diff(log_r);
m = numel(slopes);

mid_lo = max(1, floor(0.20 * m));
mid_hi = min(m, ceil(0.80 * m));
ref_slope = median(slopes(mid_lo:mid_hi));

good = abs(slopes - ref_slope) < 0.05 * max(abs(ref_slope), 1e-9);

best_i = 0;
best_j = 0;
i = 1;
while i <= m
    if good(i)
        j = i;
        while j + 1 <= m && good(j + 1)
            j = j + 1;
        end
        if (j - i) > (best_j - best_i)
            best_i = i;
            best_j = j;
        end
        i = j + 1;
    else
        i = i + 1;
    end
end

if (best_j - best_i) < 2
    M = numel(log_r);
    i_fit = max(1, floor(0.15 * M));
    j_fit = min(M, ceil(0.75 * M));
else
    i_fit = best_i;
    j_fit = best_j + 1;
end

p = polyfit(log_r(i_fit:j_fit), log_C(i_fit:j_fit), 1);
D2 = p(1);

end
