function Q = computeModularity(A, community_labels)
% Modularity of a network.
% Input:
%   A: adjacency matrix (200x200), entries 0 or 1
%   community_labels: community label vector (200x1); the first 100 entries
%                     are 1 and the last 100 entries are 2
% Output:
%   Q: modularity

% total number of edges
m = sum(A(:)) / 2;  % undirected graph, hence the factor 1/2

% degree of every node
k = sum(A, 2);

% initialise the modularity
Q = 0;

% accumulate the modularity
n = size(A, 1);
for i = 1:n
    for j = 1:n
        if community_labels(i) == community_labels(j)
            % node pair inside the same community
            expected_edges = (k(i) * k(j)) / (2 * m);
            Q = Q + (A(i, j) - expected_edges);
        end
    end
end

Q = Q / (2 * m);

% fprintf('modularity Q = %.4f\n', Q);
end
