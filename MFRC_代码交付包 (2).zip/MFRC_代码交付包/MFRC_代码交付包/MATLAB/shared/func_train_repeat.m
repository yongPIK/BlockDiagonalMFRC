function mean_rmse = func_train_repeat(hyperpara_set,n,bo,repeat_num)
% repeat in each iteration to reduce fluctuations
tic
rmse_set = zeros(repeat_num,1);
parfor repeat_i = 1:repeat_num
    rng(repeat_i*20000 + (now*1000-floor(now*1000))*100000)
    rmse_set(repeat_i) = func_data_train(hyperpara_set,n,bo);    
end

mean_rmse = mean(rmse_set);
fprintf('\nmean rmse is %f\n',mean_rmse)
toc
end