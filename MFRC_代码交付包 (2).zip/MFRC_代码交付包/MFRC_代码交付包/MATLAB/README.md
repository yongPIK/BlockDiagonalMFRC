# MATLAB code (all results of the manuscript)

This directory is the MATLAB implementation of all results reported in the
manuscript. Sub-directories:

| Directory | Content |
|---|---|
| `shared/` | common functions: `gene_Win`, `gene_Wr`, `Grassberger_Procaccia`, `Grassberger_Procaccia_updated`, `computeModularity`, `mutual_information`, `func_train_repeat` |
| `MFRC_core/` | ten-system MFRC experiment (Fig. 7 / Table 3) and success-rate statistics |
| `multifunctionRC/` | unified entry `run_MFRC`, optimisation example, plotting entry, `legacy/` scripts |
| `RC_single/` | classical single-task RC (RC column of Table 3; includes the updated GP version) |
| `sprottBC_modularity_robustness/` | Sprott B/C modularity and cross-module perturbations (Fig. 8) |
| `KLD_MATLAB/` | KLD reconstruction success rates (Table 4) |

Quick start is given in the package-level `README.md`; the settings and
hyper-parameters of every part are listed below.

## 1. Common functions (`shared/`)

| Function | Arguments |
|---|---|
| `gene_Win(resSize, inSize, add_dim, W_in_a, W_in_type)` | input weight matrix: `resSize` number of nodes, `inSize` input dimension, `add_dim` extra channel (0/1), `W_in_a` amplitude, `W_in_type` (1 = uniform) |
| `gene_Wr(resSize, k, eig_rho, W_r_type)` | recurrent matrix: `k` mean degree, `eig_rho` target spectral radius, `W_r_type` (1 = symmetric Gaussian `sprandsym`) |
| `Grassberger_Procaccia(dim, data)` | correlation dimension D2 (the released estimator used in the manuscript) |
| `Grassberger_Procaccia_updated(dim, data, theiler)` | updated GP (automatic Theiler window, data-driven radius range, automatic scaling region); **used in the reviewer reply only** |
| `computeModularity(A, community_labels)` | modularity Q of a binary functional network |
| `mutual_information(X, Y, numBins)` | mutual information (used to rebuild the functional network) |

## 2. Data sets and network sizes of the ten systems

System order (all vectors and tables below follow this order):

```text
SprottA, SprottB, SprottC, SprottD, Lorenz, Roessler, Chen, Selkov, HyperOsc(Hyperchaotic Oscillator), HyperSprottB
```

| System | Data file | Input / output dimension | Nodes per module |
|---|---|---|---|
| SprottA | `data_SprottA_2000_0.01.dat` | 3 | 100 |
| SprottB | `data_SprottB_2000_0.01.dat` | 3 | 100 |
| SprottC | `data_SprottC_2000_0.01.dat` | 3 | 100 |
| SprottD | `data_SprottD_2000_0.01.dat` | 3 | 100 |
| Lorenz | `data_Lorenz.dat` | 3 | 100 |
| Roessler | `data_roessler2_1000_0.01.dat` | 3 | 100 |
| Chen | `data_chen_1000_0.01.dat` | 3 | 100 |
| Selkov | `data_sel_kov_1000_0.01.dat` | 2 | 100 |
| HyperOsc | `data_hyperchaotic_oscillator_1000_0.01.dat` | 4 | 500 |
| HyperSprottB | `data_hyper_sprottB_1000_0.01.dat` | 5 | 500 |

Corresponding vectors:

```matlab
inSize_vec  = [3 3 3 3 3 3 3 2 4 5];
outSize_vec = [3 3 3 3 3 3 3 2 4 5];
resSize_vec = [100 100 100 100 100 100 100 100 500 500];
```

## 3. Global experimental settings (Table 1 conventions)

| Parameter | Value |
|---|---|
| Number of realizations | 500 |
| Common driving length `trainLen` | 60000 steps (600 time units) |
| Washout `initLen` | 6000 steps |
| Test length `testLen` | 30000 steps (300 time units) |
| D2 down-sampling interval `gap` | 10 steps |
| Leakage rate `a` | 0.1 |
| Readout regularization `reg` (Tikhonov beta) | 1e-5 |

Per-module readout window (each subsystem trains its readout on this many steps
at the **tail** of the common driving segment):

```matlab
trainlen_vec = [50000 20000 20000 40000 5000 10000 3000 5000 10000 50000];
```

That is, SprottA / HyperSprottB use 50000 steps, Lorenz 5000 steps, Chen
3000 steps, and so on; `trainLen = 60000` lets all subsystems share one driving
signal (longest subsystem 50000 plus washout margin).

## 4. Reservoir hyper-parameters (`[W_in_a, k, eig_rho]`)

| System | `W_in_a` | `k` | `eig_rho` |
|---|---:|---:|---:|
| SprottA | 0.166903974271684 | 59.1510248401282 | -2.82953128218694 |
| SprottB | 0.524801417382458 | 2.80696270207184 | 2.72180624436781 |
| SprottC | 0.287709384851287 | 74.0972678053068 | 1.97938743778260 |
| SprottD | 1.03375020271522 | 1.0 | 3.0 |
| Lorenz | 2.81262506997391 | 94.9666913419282 | -0.730966611140523 |
| Roessler | 0.958860215120228 | 1.02505593204508 | 2.70376617790837 |
| Chen | 2.88942563792231 | 6.20808716642222 | -0.0376176384094279 |
| Selkov | 2.23394122119754 | 24.5498565590683 | -0.00227173616567419 |
| HyperOsc | 0.299007202733509 | 171.705780833805 | -1.21189202441243 |
| HyperSprottB | 0.125746762061917 | 405.335058731385 | 1.53843634290604 |

Matrix construction:

```matlab
Win = gene_Win(resSize, inSize, 0, W_in_a, 1);
W   = gene_Wr(resSize, k, eig_rho, 1);
```

The hyper-parameters are optimised with the MATLAB `surrogateopt` solver
(DYCORS-type stochastic RBF) over the ranges `a` in [0,1], `W_in_a` in [0,3],
`k` in [1,100] ([1,500] for Lorenz / HyperSprottB), `eig_rho` in [-3,3] and
`reg` in [1e-8,1e-3]; one objective evaluation is one full training run
followed by a short closed-loop rollout, averaged over 10 independent
realizations, and the search stops after 200 (occasionally 300) evaluations.

## 5. Unified entry point (`multifunctionRC/`)

```matlab
addpath(genpath('MATLAB'));

run_MFRC('10sys')                   % ten-system MFRC -> Fig.7 / Table 3
run_MFRC('lorenz_roessler')         % two decoupled modules, Lorenz + Roessler (Sec. 5.1)
run_MFRC('lorenz_roessler_coupled') % weakly coupled Lorenz-Roessler -> Fig.6
run_MFRC('sprottbc')                % two Sprott B/C modules + functional modularity Q
run_MFRC('sprottbc_addnoise')       % cross-module perturbation success rate eta(s_p, n_sigma) -> Fig.8(a-c)
run_MFRC('sprottbc_muinfo')         % mutual-information functional network -> modularity map -> Fig.8(d)
```

| mode | underlying script |
|---|---|
| `10sys` / `10sys_fractal` | `MFRC_core/multi_regress_RC_10sys_fractaldim.m` |
| `lorenz_roessler` | `multifunctionRC/legacy/multi_regress_RC.m` |
| `lorenz_roessler_coupled` | `multifunctionRC/regress_RC_lorenzcouplingroessler.m` |
| `sprottbc` | `sprottBC_modularity_robustness/multi_regress_RC_sprottBC.m` |
| `sprottbc_addnoise` | `sprottBC_modularity_robustness/multi_regress_RC_sprottBC_addnoise.m` |
| `sprottbc_muinfo` | `sprottBC_modularity_robustness/multi_regress_RC_sprottBC_addnoise_corr_mu_info.m` |

Every script adds `shared/` and `Data/TimeSeries/` to the path itself, so it can
also be run on its own.

### Length settings of the other experiment sets

| Experiment | `trainLen` | `initLen` | `testLen` | Note |
|---|---:|---:|---:|---|
| SprottABCD (n = 4 arm of Table 7) | 60000 | 6000 | 10000 | four systems in parallel, optimisation objective |
| SprottBC (Fig. 8) | 40000 | 4000 | 30000 | two systems in parallel, with cross-module perturbations |
| Lorenz + Roessler (Sec. 5.1) | 30000 | 3000 | 20000 | two decoupled systems |
| weakly coupled Lorenz-Roessler (Fig. 6) | 30000 | 3000 | 20000 | coupling strength 0.01 |

`multi_regress_RC_sprottBC.m` builds the improved single reservoir from 50 + 50
nodes (the "lower-dimensional reservoir" of Section 8); the other perturbation
experiments use 100 + 100 nodes.

## 6. Plotting entry point

```matlab
plot_MFRC_figures('main')        % attractors and D2 distributions of the ten systems (Fig.2-5, Fig.7)
plot_MFRC_figures('modularity')  % success rate vs modularity
plot_MFRC_figures('addnoise')    % Sprott B/C (s_p, n_sigma) success-rate map (Fig.8a-c)
plot_MFRC_figures('wout')        % readout-weight norm figure (Fig.12)
```

The original plotting scripts are in `multifunctionRC/legacy_plot/`; the
plotting data are in `Data/`.

## 7. Classical single-task RC (`RC_single/`)

`regress_RC_fractal.m` reproduces the RC column of Table 3 (single task, same
size as the corresponding MFRC module). For each system only the `para` block
at the top of the script (the ten systems are listed there) and the data file
are changed; the training / initialization / test lengths are:

| System | Nodes | `trainLen` | `initLen` | `testLen` |
|---|---:|---:|---:|---:|
| SprottA | 100 | 50000 | 500 | 60000 |
| SprottB | 100 | 20000 | 2000 | 2000 |
| SprottC | 100 | 20000 | 2000 | 2000 |
| SprottD | 100 | 40000 | 4000 | 3000 |
| Lorenz | 100 | 5000 | 500 | 500 |
| Roessler | 100 | 10000 | 1000 | 500 |
| Chen | 100 | 3000 | 300 | 300 |
| Selkov | 100 | 5000 | 500 | 1000 |
| HyperOsc | 500 | 10000 | 1000 | 600 |
| HyperSprottB | 500 | 50000 | 5000 | 3000 |

`regress_RC_fractal_updated.m` is the same experiment with the updated GP; its
output files carry the `_updated` suffix and it is **used in the reviewer reply
only**.

## 8. Sprott B/C modularity and robustness (`sprottBC_modularity_robustness/`)

| Script | Purpose | Manuscript / reply |
|---|---|---|
| `multi_regress_RC_sprottBC.m` | two modules of 50 + 50, 500 realizations, writes the functional modularity `Q_max` and D2 | supports Fig. 8; Q versus success rate for R1-10 / R2-7 |
| `multi_regress_RC_sprottBC_addnoise.m` | cross-module perturbation success rate eta(s_p, n_sigma) on a 21 x 8 grid, spmd parallel | Fig. 8(a-c) |
| `multi_regress_RC_sprottBC_addnoise_corr_mu_info.m` | mutual-information functional network -> modularity map Q(s_p, n_sigma) | Fig. 8(d), eta-Q correlation r = 0.84 |

Perturbation model: a fraction `s_p` of the zero off-diagonal entries is
replaced by uniform random values in [-n_sigma, n_sigma], with
`n_sigma = [0 1e-4 5e-4 1e-3 5e-3 1e-2 5e-2 1e-1]` and
`s_p = 0 : 0.05 : 1`. The results are written to
`Data/sprottBC_modularity_robustness/` (success-rate grid) and
`Data/multifunctionRC/result_add_noise/` (Q grid).

## 9. KLD reconstruction success rates (`KLD_MATLAB/`, Table 4)

For every system and every realization the MFRC and a classical single-task RC
are trained, rolled out in closed loop, the PDFs of the `x` component of the
true and predicted trajectories are taken and the symmetric KLD is computed,

$$
D_{\rm sym}(p,q)=\frac12\left[\sum_i p_i\ln\frac{p_i}{q_i}+\sum_i q_i\ln\frac{q_i}{p_i}\right]
$$

after which the success rates are counted for
$D_{\rm sym}<0.10/0.20/0.30/0.50$. Run:

```matlab
cd('MATLAB/KLD_MATLAB'); run_KLD_success_10sys
```
