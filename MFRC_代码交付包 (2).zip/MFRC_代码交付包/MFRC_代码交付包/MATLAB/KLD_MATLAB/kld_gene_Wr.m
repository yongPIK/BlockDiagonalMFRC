function W = kld_gene_Wr(n, k, eig_rho, stream)
% KLD_GENE_WR  Symmetric random recurrent matrix, in the sprandsym style of the
% released implementation. Renamed to avoid a name clash with shared/gene_Wr on
% the MATLAB path.

density = min(k / n, 1);
U = triu(rand(stream, n, n) < density);
V = randn(stream, n, n);
W = U .* V;
W = W + triu(W, 1)';

if any(W(:))
    W = (eig_rho / abs(max(abs(eig(W))))) * W;
end

end
