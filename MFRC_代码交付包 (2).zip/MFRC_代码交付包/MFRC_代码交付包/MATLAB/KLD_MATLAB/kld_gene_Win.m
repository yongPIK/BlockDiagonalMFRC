function W_in = kld_gene_Win(n, dim, W_in_a, stream)
% KLD_GENE_WIN  Uniformly distributed input matrix (the W_in_type = 1 branch of
% shared/gene_Win). Renamed to avoid a name clash with shared/gene_Win on the
% MATLAB path.

W_in = W_in_a * (2 * rand(stream, n, dim) - 1);

end
