function cfg = system_config()
% SYSTEM_CONFIG  Data files, dimensions, reservoir parameters and training
% windows of the ten benchmark systems.

cfg.names = {'SprottA','SprottB','SprottC','SprottD','Lorenz', ...
             'Roessler','Chen','Selkov','HyperOsc','HyperSprottB'};

cfg.files = {'data_SprottA_2000_0.01.dat', ...
             'data_SprottB_2000_0.01.dat', ...
             'data_SprottC_2000_0.01.dat', ...
             'data_SprottD_2000_0.01.dat', ...
             'data_Lorenz.dat', ...
             'data_roessler2_1000_0.01.dat', ...
             'data_chen_1000_0.01.dat', ...
             'data_sel_kov_1000_0.01.dat', ...
             'data_hyperchaotic_oscillator_1000_0.01.dat', ...
             'data_hyper_sprottB_1000_0.01.dat'};

cfg.in_size  = [3 3 3 3 3 3 3 2 4 5];
cfg.res_size = [100 100 100 100 100 100 100 100 500 500];

% [W_in_a, k, eig_rho]
cfg.para = [ ...
    0.166903974271684   59.1510248401282   -2.82953128218694;
    0.524801417382458    2.80696270207184   2.72180624436781;
    0.287709384851287   74.0972678053068    1.97938743778260;
    1.03375020271522     1.0                 3.0;
    2.81262506997391    94.9666913419282   -0.730966611140523;
    0.958860215120228    1.02505593204508   2.70376617790837;
    2.88942563792231     6.20808716642222  -0.0376176384094279;
    2.23394122119754    24.5498565590683   -0.00227173616567419;
    0.299007202733509  171.705780833805   -1.21189202441243;
    0.125746762061917  405.335058731385    1.53843634290604];

cfg.trainlen_vec = [50000 20000 20000 40000 5000 10000 3000 5000 10000 50000];
cfg.trainLen     = 60000;
cfg.testLen      = 30000;
cfg.initLen      = 6000;
cfg.alpha        = 0.1;
cfg.reg          = 1e-5;

% released protocol of the classical single-task RC
cfg.rc_trainLen = 50000;
cfg.rc_initLen  = 5000;

% Per-system RC protocol. Only Hyper-osc uses the Table-III-matched protocol.
cfg.rc_trainlen_vec = 50000 * ones(1, numel(cfg.names));
cfg.rc_initlen_vec  =  5000 * ones(1, numel(cfg.names));
cfg.rc_trainlen_vec(9) = 10000;   % HyperOsc
cfg.rc_initlen_vec(9)  =  1000;

end
