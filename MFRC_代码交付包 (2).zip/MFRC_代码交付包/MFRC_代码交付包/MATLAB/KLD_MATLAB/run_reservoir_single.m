function X = run_reservoir_single(W_in, W, data, trainLen, initLen, a)
% RUN_RESERVOIR_SINGLE  Teacher-forced reservoir pass.

n = size(W, 1);
X = zeros(n, trainLen - initLen);
x = zeros(n, 1);

for t = 1:trainLen
    u = data(:, t);
    x = (1 - a) * x + a * tanh(W_in * u + W * x);
    if t > initLen
        X(:, t - initLen) = x;
    end
end

end
