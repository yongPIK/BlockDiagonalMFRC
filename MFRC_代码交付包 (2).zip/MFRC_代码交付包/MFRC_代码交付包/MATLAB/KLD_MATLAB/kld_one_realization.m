function [kld_mfrc, kld_rc] = kld_one_realization(all_data, cfg, stream, pair_rc, bins, span)
% KLD_ONE_REALIZATION  Symmetric KLD of the MFRC and RC arms for one realization.

n_sys = numel(cfg.names);
kld_mfrc = zeros(1, n_sys);
kld_rc   = zeros(1, n_sys);

for i = 1:n_sys
    data = all_data{i};
    W_in_a = cfg.para(i, 1);
    k      = cfg.para(i, 2);
    rho    = cfg.para(i, 3);
    n_in   = cfg.in_size(i);
    n_res  = cfg.res_size(i);

    % ---------------- MFRC block-local ----------------
    W_in = kld_gene_Win(n_res, n_in, W_in_a, stream);
    W    = kld_gene_Wr(n_res, k, rho, stream);

    X = run_reservoir_single(W_in, W, data, cfg.trainLen, cfg.initLen, cfg.alpha);
    L = cfg.trainlen_vec(i);
    Yt = data(:, cfg.trainLen - L + 2 : cfg.trainLen + 1);
    Wout = ridge_readout(X(:, end - L + 1 : end), Yt, cfg.reg);
    Y_m = rollout_single(W_in, W, Wout, data, cfg.trainLen, cfg.testLen, ...
                         cfg.alpha, X(:, end));
    x_true_m = data(1, cfg.trainLen + 2 : cfg.trainLen + cfg.testLen + 1);
    kld_mfrc(i) = kld_pdf_sym(x_true_m, Y_m(1, :), bins, span);

    % ---------------- single-task RC ----------------
    if pair_rc
        W_in_rc = W_in;
        W_rc    = W;
    else
        W_in_rc = kld_gene_Win(n_res, n_in, W_in_a, stream);
        W_rc    = kld_gene_Wr(n_res, k, rho, stream);
    end

    rc_trainLen = cfg.rc_trainlen_vec(i);
    rc_initLen  = cfg.rc_initlen_vec(i);
    X_rc = run_reservoir_single(W_in_rc, W_rc, data, rc_trainLen, ...
                                rc_initLen, cfg.alpha);
    Yt_rc = data(:, rc_initLen + 2 : rc_trainLen + 1);
    Wout_rc = ridge_readout(X_rc, Yt_rc, cfg.reg);
    Y_rc = rollout_single(W_in_rc, W_rc, Wout_rc, data, rc_trainLen, ...
                          cfg.testLen, cfg.alpha, X_rc(:, 1));
    x_true_rc = data(1, rc_trainLen + 2 : rc_trainLen + cfg.testLen + 1);
    kld_rc(i) = kld_pdf_sym(x_true_rc, Y_rc(1, :), bins, span);
end

end
