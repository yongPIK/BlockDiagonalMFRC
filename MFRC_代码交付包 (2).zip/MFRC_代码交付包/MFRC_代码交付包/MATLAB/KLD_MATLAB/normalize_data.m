function data = normalize_data(data)
% NORMALIZE_DATA  Normalize every dimension by its maximum absolute value, as in
% the released MATLAB scripts.

for i = 1:size(data, 1)
    data(i, :) = data(i, :) ./ max(abs(data(i, :)));
end

end
