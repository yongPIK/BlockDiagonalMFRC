function [kld_sym, kld_true_pred, kld_pred_true] = kld_pdf_sym(x_true, x_pred, bins, span)
% KLD_PDF_SYM  PDF-based symmetric KLD for the x marginal.
%
% p = true PDF, q = predicted PDF
% kld_true_pred = sum p log(p/q)
% kld_pred_true = sum q log(q/p)
% kld_sym       = 0.5*(kld_true_pred + kld_pred_true)

if nargin < 3 || isempty(bins), bins = 60; end
if nargin < 4 || isempty(span), span = 1.05; end

edges = linspace(-span, span, bins + 1);
p = pdf_hist(x_true, edges);
q = pdf_hist(x_pred, edges);

kld_true_pred = sum(p .* log(p ./ q));
kld_pred_true = sum(q .* log(q ./ p));
kld_sym       = 0.5 * (kld_true_pred + kld_pred_true);

end

function p = pdf_hist(x, edges)
x = x(:);
x(~isfinite(x)) = 0;
x = min(max(x, edges(1)), edges(end));
counts = histcounts(x, edges);
p = counts + 0.5;
p = p / sum(p);
end
