function Wout = ridge_readout(X, Yt, reg)
% RIDGE_READOUT  Wout = Yt X^T (X X^T + reg I)^(-1).

Wout = Yt * X' / (X * X' + reg * eye(size(X, 1)));

end
