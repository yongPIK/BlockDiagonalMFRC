% RUN_KLD_SUCCESS_10SYS
% PDF/KLD reconstruction success rates for the ten benchmark systems.
%
% Output files follow the style of the existing MATLAB 10-system scripts:
%   KLD_sym_matrix_MFRC_10sys_30000length_gap10_500times.dat
%   KLD_sym_matrix_RC_10sys_30000length_gap10_500times.dat
%   KLD_success_MFRC_10sys_30000length_gap10_500times.dat
%   KLD_success_RC_10sys_30000length_gap10_500times.dat

clear; clc; close all;

%% ------------------------- user settings -------------------------
this_dir       = fileparts(mfilename('fullpath'));

% Data directory: use the Data/TimeSeries shipped with this package first, and
% fall back to the original Desktop path otherwise.
data_dir = fullfile(this_dir, '..', '..', 'Data', 'TimeSeries');
if ~exist(fullfile(data_dir, 'data_Lorenz.dat'), 'file')
    data_dir = 'C:\Users\KevinJiang\Desktop\MFRC';
end

% Results directory: Data/KLD_MATLAB/results.
out_dir = fullfile(this_dir, '..', '..', 'Data', 'KLD_MATLAB', 'results');

num_experiments = 500;
n_workers      = 4;        % keep small to avoid blocking the machine
pair_rc        = false;    % true: RC reuses the same W_in/W_r as the MFRC block
bins           = 60;
span           = 1.05;
thresholds     = [0.10 0.20 0.30 0.50];

if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

cfg = system_config();
n_sys = numel(cfg.names);

%% ------------------------- load data once -------------------------
fprintf('Loading and preprocessing data...\n');
all_data = cell(n_sys, 1);
for i = 1:n_sys
    raw = dlmread(fullfile(data_dir, cfg.files{i}));
    all_data{i} = normalize_data(raw');
end

%% ------------------------- parallel pool -------------------------
use_parallel = true;
try
    pool = gcp('nocreate');
    if isempty(pool)
        parpool('local', n_workers);
    elseif pool.NumWorkers ~= n_workers
        delete(pool);
        parpool('local', n_workers);
    end
catch
    warning('Parallel pool unavailable; falling back to serial execution.');
    use_parallel = false;
end

%% ------------------------- main loop -------------------------
fprintf('Starting %d realizations...\n', num_experiments);
kld_mfrc = zeros(num_experiments, n_sys);
kld_rc   = zeros(num_experiments, n_sys);
t0 = tic;

if use_parallel
    parfor exp_idx = 1:num_experiments
        stream = RandStream('mt19937ar', 'Seed', exp_idx);
        [km, kr] = kld_one_realization(all_data, cfg, stream, pair_rc, bins, span);
        kld_mfrc(exp_idx, :) = km;
        kld_rc(exp_idx, :)   = kr;
    end
else
    for exp_idx = 1:num_experiments
        stream = RandStream('mt19937ar', 'Seed', exp_idx);
        [km, kr] = kld_one_realization(all_data, cfg, stream, pair_rc, bins, span);
        kld_mfrc(exp_idx, :) = km;
        kld_rc(exp_idx, :)   = kr;
        if mod(exp_idx, 50) == 0
            fprintf('  realization %d / %d\n', exp_idx, num_experiments);
        end
    end
end

fprintf('Finished in %.1f s.\n', toc(t0));

%% ------------------------- success rates -------------------------
n_thr = numel(thresholds);
eta_mfrc = zeros(n_thr, n_sys);
eta_rc   = zeros(n_thr, n_sys);
for j = 1:n_thr
    eta_mfrc(j, :) = mean(kld_mfrc < thresholds(j), 1);
    eta_rc(j, :)   = mean(kld_rc   < thresholds(j), 1);
end

%% ------------------------- save results -------------------------
tag = sprintf('10sys_30000length_gap10_%dtimes', num_experiments);
dlmwrite(fullfile(out_dir, ['KLD_sym_matrix_MFRC_' tag '.dat']), ...
         kld_mfrc, 'delimiter', '\t', 'precision', '%.8f');
dlmwrite(fullfile(out_dir, ['KLD_sym_matrix_RC_' tag '.dat']), ...
         kld_rc, 'delimiter', '\t', 'precision', '%.8f');
dlmwrite(fullfile(out_dir, ['KLD_success_MFRC_' tag '.dat']), ...
         eta_mfrc, 'delimiter', '\t', 'precision', '%.8f');
dlmwrite(fullfile(out_dir, ['KLD_success_RC_' tag '.dat']), ...
         eta_rc, 'delimiter', '\t', 'precision', '%.8f');

save(fullfile(out_dir, ['KLD_success_results_' tag '.mat']), ...
     'kld_mfrc', 'kld_rc', 'eta_mfrc', 'eta_rc', ...
     'thresholds', 'cfg', 'num_experiments', 'pair_rc', 'bins', 'span');

%% ------------------------- text summary -------------------------
summary_file = fullfile(out_dir, ['KLD_success_summary_' tag '.txt']);
fid = fopen(summary_file, 'w');
fprintf(fid, 'KLD symmetric success rates\n');
fprintf(fid, 'realizations = %d\n', num_experiments);
fprintf(fid, 'pair_rc = %d\n\n', pair_rc);

fprintf(fid, '%-14s', 'System');
for j = 1:n_thr
    fprintf(fid, '  MFRC<%.2f  RC<%.2f', thresholds(j), thresholds(j));
end
fprintf(fid, '\n');

for i = 1:n_sys
    fprintf(fid, '%-14s', cfg.names{i});
    for j = 1:n_thr
        fprintf(fid, '  %8.3f  %8.3f', eta_mfrc(j, i), eta_rc(j, i));
    end
    fprintf(fid, '\n');
end

fclose(fid);

%% ------------------------- print summary -------------------------
fprintf('\n%-14s %8s %8s\n', 'System', 'MFRC', 'RC');
for i = 1:n_sys
    fprintf('%-14s %8.3f %8.3f\n', ...
            cfg.names{i}, eta_mfrc(2, i), eta_rc(2, i));
end
fprintf('\nResults written to:\n%s\n', out_dir);
