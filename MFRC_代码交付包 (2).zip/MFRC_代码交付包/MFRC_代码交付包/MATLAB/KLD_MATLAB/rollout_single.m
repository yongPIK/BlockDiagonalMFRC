function Y = rollout_single(W_in, W, Wout, data, trainLen, testLen, a, x_init)
% ROLLOUT_SINGLE  Generative rollout used by the released RC script.

out_dim = size(Wout, 1);
Y = zeros(out_dim, testLen);

x = x_init;
u = data(:, trainLen + 1);

for t = 1:testLen
    x = (1 - a) * x + a * tanh(W_in * u + W * x);
    u = Wout * x;
    Y(:, t) = u;
end

end
