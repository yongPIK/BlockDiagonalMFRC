clc; clear;

% requires gene_Win / gene_Wr / Grassberger_Procaccia from shared/
here = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data', 'TimeSeries')));

delete(gcp('nocreate'))
noSize = 21; 
myCluster = parcluster('Processes')
myCluster.NumWorkers = noSize; 
saveProfile(myCluster)
poolobj = parpool(noSize); 


P_datas2 = load('data_SprottB_2000_0.01.dat');
data2 = P_datas2';

P_datas3 = load('data_SprottC_2000_0.01.dat');
data3 = P_datas3';

for i=1:3
    data2(i,:)=data2(i,:)./max(abs(data2(i,:))); %normalized
end
for i=1:3
    data3(i,:)=data3(i,:)./max(abs(data3(i,:))); %normalized
end

% generate the ESN reservoir
trainLen = 40000;

trainLen2=20000;
trainLen3=20000;

testLen = 30000;
initLen = 4000;

inSize2 = 3;
outSize2 =3;

inSize3 = 3;
outSize3 =3;

resSize2 = 100;
resSize3 = 100;

resSize=resSize2+resSize3;
add_dim = 0;

% para1=[0.0390185235830287	3	1.24161295887415	74.2934015625509	8.38392246535097	-0.858692115293726	-0.234715964773395	0.000945227125799516];% first optimization run
para1=[0.1	0.524801417382458	0.287709384851287	2.80696270207184	74.0972678053068	2.72180624436781	1.97938743778260		1.00000000000000e-05]; % second optimization result
a = para1(1) ; % leaking rate

W_in_a2 = para1(2);
W_in_a3 = para1(3);

k2 = para1(4);
k3 = para1(5);

eig_rho2 = para1(6);
eig_rho3 = para1(7);

reg = para1(8);  % regularization coefficient

W_in_type = 1;   W_r_type = 1;

gap=10;
success_rate_matrix_sprottB=zeros(21,8);
success_rate_matrix_sprottC=zeros(21,8);
alp_vec=[0 0.0001 0.0005 0.001 0.005 0.01 0.05 0.1];

% results directory (archive location inside this package)
out_dir = fullfile(here, '..', '..', 'Data', 'sprottBC_modularity_robustness', ...
                   'addnoise_results', 'result_add_noise');
if ~exist(out_dir, 'dir'); mkdir(out_dir); end

spmd(noSize)
    % labindex = 2; 
    % outFile = ['result_TCRC_general2_HR', filesep, 'HR_TCRC_general2_index1_iLabindex', num2str(labindex, '%02d'), '.txt']; 
    outFileB = fullfile(out_dir, ['success_rate_matrix_sprottB_labIndex', num2str(labindex, '%02d'), '.txt']); 
    outFileC = fullfile(out_dir, ['success_rate_matrix_sprottC_labIndex', num2str(labindex, '%02d'), '.txt']); 
    % fid = fopen(outFile, 'w');

    warning('off'); %, 'MATLAB:SingularityWarnings');

    iSp = labindex; 
    sp = (iSp - 1) * 0.05; 
% for sp=0:0.05:1
    for alp_index=1:8
        alp=alp_vec(alp_index);

        Dim_fractal_matrix_ture=zeros(500,2);
        Dim_fractal_matrix_pre=zeros(500,2);

        for iii=1:500
            Win2= gene_Win(resSize2,inSize2,add_dim,W_in_a2,W_in_type);
            W2 = gene_Wr(resSize2,k2,eig_rho2,W_r_type);

            Win3= gene_Win(resSize3,inSize3,add_dim,W_in_a3,W_in_type);
            W3 = gene_Wr(resSize3,k3,eig_rho3,W_r_type);

            % alp=0.001;
            % con_matrix = alp*(2 * rand(resSize2) - 1);

            % sp = 0.2; % sparsity
            k = round(sp * resSize2 * resSize2); % number of non-zero entries
            con_matrix = zeros(resSize2, resSize2);
            idx = randperm(resSize2 * resSize2, k);
            con_matrix(idx) = alp*(2 * rand(k, 1) - 1);

            W = [W2,con_matrix;con_matrix,W3];

            MODEL={'SprottB', 'SprottC'};
            for jjj=1:2
                model=MODEL{jjj}; 

                % b=rand(resSize,1)-0.5;
                % allocated memory for the design (collected states) matrix
                 X = zeros(resSize,trainLen-initLen);                                             %%%%%  1+inSize+resSize
                % X = zeros(1+inSize+resSize,trainLen-initLen);    % need to change while with bias  

                % set the corresponding target matrix directly
                Yt2 = data2(:,trainLen-trainLen2+2:trainLen+1);
                Yt3 = data3(:,trainLen-trainLen3+2:trainLen+1);

                % run the reservoir with the data and collect X
                x = zeros(resSize,1);
                for t = 1:trainLen

                    u2 = data2(:,t);
                    u3 = data3(:,t);


                    temp2=Win2*u2;
                    temp3=Win3*u3;

                    temp=[temp2;temp3];
                    x = (1-a)*x + a*tanh( temp + W*x );               

                    if t > initLen
                         X(:,t-initLen) = x;                       
                        % X(:,t-initLen) = [1;u;x]; 
                    end
                end

                % train the output

                X2=X(1:resSize2,end-trainLen2+1:end);
                % X2(2:2:end, :) = X2(2:2:end, :).^2; % squaring of the even-indexed entries
                X2_T = X2';
                Wout2 = Yt2*X2_T / (X2*X2_T + reg*eye(resSize2));   

                X3=X(resSize2+1:resSize2+resSize3,end-trainLen3+1:end);
                X3_T = X3';
                Wout3 = Yt3*X3_T / (X3*X3_T + reg*eye(resSize3)); 

                Y2 = zeros(outSize2,testLen);
                Y3 = zeros(outSize3,testLen);

                u2 = data2(:,trainLen+1);
                u3 = data3(:,trainLen+1);

                errorLen = testLen;

                Y_t2 =data2(:,trainLen+2:trainLen+errorLen+1);
                Y_t3 =data3(:,trainLen+2:trainLen+errorLen+1);

                u=[u2;u3];

                switch model
                    case 'SprottB'
                        x=X(:,end);
                        for t = 1:testLen 

                            u2 = u(1:inSize2);
                            u3 = u(inSize2+1:inSize2+inSize3);


                            temp2=Win2*u2;
                            temp3=Win3*u3;

                            temp=[temp2;temp3];
                            x = (1-a)*x + a*tanh( temp + W*x );  
                            % temp3=x(1+resSize1:end);    % squaring of the even-indexed entries
                            % temp3(2:2:end)=temp3(2:2:end).^2; % squaring of the even-indexed entries
                            % u2 = Wout2*temp3;   % squaring of the even-indexed entries
                            u2 = Wout2*x(1:resSize2);                            
                            u = [u2;0;0;0];
                            Y2(:,t) = u2;   
                        end
                        Y_t2_T=Y_t2';
                        Y2_T=Y2';
                        Dim_fractal_matrix_ture(iii,jjj)=Grassberger_Procaccia(inSize2,Y_t2_T(1:gap:errorLen,:));
                        Dim_fractal_matrix_pre(iii,jjj)=Grassberger_Procaccia(inSize2,Y2_T(1:gap:errorLen,:));

                    % figure(2);
                    % plot( Y_t2(1,1:errorLen), 'color', [0,0.75,0] );
                    % hold on;
                    % plot( Y2(1,1:errorLen), 'b' );
                    % hold off;
                    % axis tight;
                    % title('The predicted and true values of the Roessler system');
                    % legend('Target signal', ' predicted signal');
                    % 
                    % figure(3);
                    % plot3(Y2(1,:),Y2(2,:),Y2(3,:))

                    case 'SprottC'
                        x=X(:,end);
                        for t = 1:testLen 

                            u2 = u(1:inSize2);
                            u3 = u(inSize2+1:inSize2+inSize3);


                            temp2=Win2*u2;
                            temp3=Win3*u3;

                            temp=[temp2;temp3];
                            x = (1-a)*x + a*tanh( temp + W*x );  
                            % temp3=x(1+resSize1:end);    % squaring of the even-indexed entries
                            % temp3(2:2:end)=temp3(2:2:end).^2; % squaring of the even-indexed entries
                            % u2 = Wout2*temp3;   % squaring of the even-indexed entries
                            u3 = Wout3*x(resSize2+1:resSize2+resSize3);                            
                            u = [0;0;0;u3];
                            Y3(:,t) = u3;   
                        end
                        Y_t3_T=Y_t3';
                        Y3_T=Y3';
                        Dim_fractal_matrix_ture(iii,jjj)=Grassberger_Procaccia(inSize3,Y_t3_T(1:gap:errorLen,:));
                        Dim_fractal_matrix_pre(iii,jjj)=Grassberger_Procaccia(inSize3,Y3_T(1:gap:errorLen,:));

                    % figure(2);
                    % plot( Y_t3(1,1:errorLen), 'color', [0,0.75,0] );
                    % hold on;
                    % plot( Y3(1,1:errorLen), 'b' );
                    % hold off;
                    % axis tight;
                    % title('The predicted and true values of the Roessler system');
                    % legend('Target signal', ' predicted signal');
                    % 
                    % figure(3);
                    % plot3(Y3(1,:),Y3(2,:),Y3(3,:))
                end
            end % end of jjj 
        end  % end of iii

        % Dim_fractal_matrix_ture

        err_fractal_dim=abs((Dim_fractal_matrix_pre -Dim_fractal_matrix_ture)./Dim_fractal_matrix_ture);
        fail_num = sum(err_fractal_dim > 0.2, 1);
        fail_rat = fail_num/500;


        success_rate_matrix_sprottB(alp_index) = 1 - fail_rat(1) ;
        success_rate_matrix_sprottC(alp_index) = 1 - fail_rat(2) ;
        
    end % end of alpha_index 

    dlmwrite(outFileB, success_rate_matrix_sprottB, 'delimiter', '\t'); 
    dlmwrite(outFileC, success_rate_matrix_sprottC, 'delimiter', '\t'); 

end % end of sp 

% addpath ('result_add_noise/')
% dlmwrite('result_add_noise/success_rate_matrix_sprottB_30000_gap5_500times.dat', success_rate_matrix_sprottB, 'delimiter', '\t');
% dlmwrite('result_add_noise/success_rate_matrix_sprottC_30000_gap5_500times.dat', success_rate_matrix_sprottC, 'delimiter', '\t');

delete(poolobj); 

% mse1 = sum((Y_t1(1,1:errorLen)-Y1(1,1:errorLen)).^2)./errorLen;

% mse = sum((Y_t(1,1:errorLen)-Y(1,1:errorLen)).^2)./errorLen+sum((Y_t(3,1:errorLen)-Y(3,1:errorLen)).^2)./errorLen;
% rmse1 = sqrt(mse1);
% disp( ['MSE = ', num2str( rmse )] );


% plot(Y2(2,:),Y2(3,:))
% hold on;
% plot(Y3(2,:),Y3(3,:))
% xlabel('x')
% ylabel('y')
% 
% 
% 
% plot(data2(2,1:30000),data2(3,1:30000),'k')
% hold on;
% plot(data3(2,1:30000),data3(3,1:30000),'k')
% ylim([-1.1 1.1])
% xlim([-1.1 1.1])
% xlabel('x')
% ylabel('y')
