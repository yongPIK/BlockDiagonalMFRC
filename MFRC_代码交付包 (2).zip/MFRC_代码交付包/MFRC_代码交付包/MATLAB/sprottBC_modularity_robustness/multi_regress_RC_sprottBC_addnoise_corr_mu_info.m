clc;
clear;

% Rebuild the structural network from the mutual information matrix and compute the
% modularity of the two Sprott B and Sprott C communities as a function of the

% requires gene_Win / gene_Wr / mutual_information / computeModularity from shared/
here = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data', 'TimeSeries')));




P_datas2 = load('data_SprottB_2000_0.01.dat');
data2 = P_datas2';

P_datas3 = load('data_SprottC_2000_0.01.dat');
data3 = P_datas3';




for i=1:3
    data2(i,:)=data2(i,:)./max(abs(data2(i,:))); %normalized
end

for i=1:3
    data3(i,:)=data3(i,:)./max(abs(data3(i,:))); %normalized
end



% generate the ESN reservoir
trainLen = 40000;

initLen = 4000;

inSize2 = 3;

inSize3 = 3;

resSize2 = 100;
resSize3 = 100;

resSize=resSize2+resSize3;
add_dim = 0;



para1=[0.1	0.524801417382458	0.287709384851287	2.80696270207184	74.0972678053068	2.72180624436781	1.97938743778260		1.00000000000000e-05]; % second optimization result
a = para1(1) ; % leaking rate

W_in_a2 = para1(2);
W_in_a3 = para1(3);


k2 = para1(4);
k3 = para1(5);


eig_rho2 = para1(6);
eig_rho3 = para1(7);

W_in_type = 1;   W_r_type = 1;


Q_matrix_sprottBC=zeros(21,8);
alp_vec=[0 0.0001 0.0005 0.001 0.005 0.01 0.05 0.1];
for sp_idx=1:21
% sp=1;
sp=(sp_idx-1)*0.05;
for alp_index=1:8
% alp=0.1;
alp=alp_vec(alp_index);
Q_max_vec=zeros(5,1);
parfor iii=1:5

Win2= gene_Win(resSize2,inSize2,add_dim,W_in_a2,W_in_type);
W2 = gene_Wr(resSize2,k2,eig_rho2,W_r_type);

Win3= gene_Win(resSize3,inSize3,add_dim,W_in_a3,W_in_type);
W3 = gene_Wr(resSize3,k3,eig_rho3,W_r_type);

% alp=0.001;
% con_matrix = alp*(2 * rand(resSize2) - 1);


% sp = 0.2; % sparsity
k = round(sp * resSize2 * resSize2); % number of non-zero entries
con_matrix = zeros(resSize2, resSize2);
idx = randperm(resSize2 * resSize2, k);
con_matrix(idx) = alp*(2 * rand(k, 1) - 1);



W = [W2,con_matrix;con_matrix,W3];


% b=rand(resSize,1)-0.5;
% allocated memory for the design (collected states) matrix
 X = zeros(resSize,trainLen-initLen);                                             %%%%%  1+inSize+resSize
% X = zeros(1+inSize+resSize,trainLen-initLen);    % need to change while with bias  

% run the reservoir with the data and collect X
x = zeros(resSize,1);
for t = 1:trainLen
   
    u2 = data2(:,t);
    u3 = data3(:,t);
   

    temp2=Win2*u2;
    temp3=Win3*u3;
 
    temp=[temp2;temp3];
    x = (1-a)*x + a*tanh( temp + W*x );               
     
    if t > initLen
         X(:,t-initLen) = x;                       
        % X(:,t-initLen) = [1;u;x]; 
    end
end

mu_info_matrix=zeros(resSize,resSize);

for cor_i=1:resSize
    for cor_j=1:resSize
        mu_info_matrix(cor_i,cor_j)=mutual_information(X(cor_i,:), X(cor_j,:), 100);
    end
end



% corr_matrix = corr(X2, X3);% column-wise correlation matrix of X2 and X3; (i,j) is the
% diag_corr = diag(corr_matrix);% correlation between column i of X2 and column i of X3
% numBins=100;
% mu_info=mutual_information(X2, X3, numBins);
% mu_info_vec(iii)=mu_info;
% cos_matrix=compute_cosine_matrix(X(:,end-1000:end));

% T=5050;
% cor_matrix=zeros(resSize,resSize);
% 
% for cor_i=1:resSize
%     for cor_j=1:resSize
%         cor_matrix(cor_i,cor_j)=cos(X(cor_i,T)-X(cor_j,T));
%     end
% end

community_labels = [ones(100, 1); 2 * ones(100, 1)];
% threshold=0.8;
Q_vec=zeros(8,1);
for threshold_i=1:8
    threshold=(threshold_i-1)*0.05+0.5;
    mu_info_matrix_adj = mu_info_matrix > threshold;
    Q_vec(threshold_i) = computeModularity(mu_info_matrix_adj, community_labels);
end
Q_max=max(Q_vec);


Q_max_vec(iii)=Q_max;
end














    
 






Q_matrix_sprottBC(sp_idx,alp_index)=mean(Q_max_vec);
end

end

out_dir = fullfile(here, '..', '..', 'Data', 'multifunctionRC', 'result_add_noise');
if ~exist(out_dir, 'dir'); mkdir(out_dir); end

dlmwrite(fullfile(out_dir, 'Q_matrix_sprottBC_500times.dat'), Q_matrix_sprottBC, 'delimiter', '\t');
% 
