clc;
clear;

% requires gene_Win / gene_Wr / mutual_information / computeModularity / Grassberger_Procaccia from shared/
here = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data', 'TimeSeries')));
addpath(genpath(fullfile(here, '..', '..', 'Data', 'sprottBC_modularity_robustness')));






P_datas2 = load('data_SprottB_2000_0.01.dat');
data2 = P_datas2';

P_datas3 = load('data_SprottC_2000_0.01.dat');
data3 = P_datas3';




for i=1:3
    data2(i,:)=data2(i,:)./max(abs(data2(i,:))); %normalized
end

for i=1:3
    data3(i,:)=data3(i,:)./max(abs(data3(i,:))); %normalized
end



% generate the ESN reservoir
trainLen = 40000;

trainLen2=20000;
trainLen3=30000;

testLen = 30000;
initLen = 4000;

inSize2 = 3;
outSize2 =3;

inSize3 = 3;
outSize3 =3;



resSize2 = 50;
resSize3 = 50;

resSize=resSize2+resSize3;
add_dim = 0;

% MODEL={'SprottB','SprottC'};
% model=MODEL{1};

% para1=[0.0390185235830287	3	1.24161295887415	74.2934015625509	8.38392246535097	-0.858692115293726	-0.234715964773395	0.000945227125799516];% first optimization run
para1=[0.113323477733598	0.141516492227675	0.121611850388603	9.87235390624925	-2.82167957063719	2.07267505926544e-06];
a = para1(1) ; % leaking rate
W_in_a2 = para1(2);
W_in_a3 = para1(3);
k = para1(4);
eig_rho = para1(5);
reg = para1(6);  % regularization coefficient
gap=10;
W_in_type = 1;   W_r_type = 1;

Dim_fractal_matrix_ture=zeros(500,1);
Dim_fractal_matrix_pre=zeros(500,1);
% bool_recon_vec=true(500,1);
Q_max_vec=zeros(500,1);
parfor iii=1:500

Win2= gene_Win(resSize2,inSize2,add_dim,W_in_a2,W_in_type);
Win3= gene_Win(resSize3,inSize3,add_dim,W_in_a3,W_in_type);

W = gene_Wr(resSize,k,eig_rho,W_r_type);
scale_factor=1;
W(1:resSize2, resSize2+1:resSize) = W(1:resSize2, resSize2+1:resSize) * scale_factor;
W(resSize2+1:resSize, 1:resSize2) = W(resSize2+1:resSize, 1:resSize2) * scale_factor;

MODEL={'SprottB','SprottC'};
% for jjj=1:2
% model=MODEL{jjj}; 
% model = MODEL{1} writes Q_max_vec_sprottBC1_500times.dat and the SprottB D2;
% model = MODEL{2} writes Q_max_vec_sprottBC2_500times.dat and the SprottC D2.
model=MODEL{2}; 


% W = blkdiag( W2, W3);
 % b=rand(resSize,1)-0.5;
% allocated memory for the design (collected states) matrix
 X = zeros(resSize,trainLen-initLen);                                             %%%%%  1+inSize+resSize
% X = zeros(1+inSize+resSize,trainLen-initLen);    % need to change while with bias  

% set the corresponding target matrix directly

Yt2 = data2(:,trainLen-trainLen2+2:trainLen+1);
Yt3 = data3(:,trainLen-trainLen3+2:trainLen+1);


% run the reservoir with the data and collect X
x = zeros(resSize,1);
for t = 1:trainLen
   
    u2 = data2(:,t);
    u3 = data3(:,t);
   

    temp2=Win2*u2;
    temp3=Win3*u3;
 
    temp=[temp2;temp3];
    x = (1-a)*x + a*tanh( temp + W*x );               
     
    if t > initLen
         X(:,t-initLen) = x;                       
        % X(:,t-initLen) = [1;u;x]; 
    end
end

% train the output

                           

X2=X(1:resSize2,end-trainLen2+1:end);
% X2(2:2:end, :) = X2(2:2:end, :).^2; % squaring of the even-indexed entries
X2_T = X2';
Wout2 = Yt2*X2_T / (X2*X2_T + reg*eye(resSize2));   

X3=X(resSize2+1:resSize2+resSize3,end-trainLen3+1:end);
X3_T = X3';
Wout3 = Yt3*X3_T / (X3*X3_T + reg*eye(resSize3)); 

mu_info_matrix=zeros(resSize,resSize);
for cor_i=1:resSize
    for cor_j=1:resSize
        mu_info_matrix(cor_i,cor_j)=mutual_information(X(cor_i,:), X(cor_j,:), 100);
    end
end
community_labels = [ones(resSize2, 1); 2 * ones(resSize2, 1)];
% threshold=0.8;
Q_vec=zeros(8,1);
for threshold_i=1:8
    threshold=(threshold_i-1)*0.05+0.5;
    mu_info_matrix_adj = mu_info_matrix > threshold;
    Q_vec(threshold_i) = computeModularity(mu_info_matrix_adj, community_labels);
end
Q_max=max(Q_vec);
Q_max_vec(iii)=Q_max;



Y2 = zeros(outSize2,testLen);
Y3 = zeros(outSize3,testLen);



u2 = data2(:,trainLen+1);
u3 = data3(:,trainLen+1);

errorLen = testLen;

Y_t2 =data2(:,trainLen+2:trainLen+errorLen+1);
Y_t3 =data3(:,trainLen+2:trainLen+errorLen+1);

u=[u2;u3];

switch model

   

    case 'SprottB'
        x=X(:,end);
    for t = 1:testLen 
        
        u2 = u(1:inSize2);
        u3 = u(inSize2+1:inSize2+inSize3);
        
        
        temp2=Win2*u2;
        temp3=Win3*u3;
        
        temp=[temp2;temp3];
        x = (1-a)*x + a*tanh( temp + W*x );  
        % temp3=x(1+resSize1:end);    % squaring of the even-indexed entries
        % temp3(2:2:end)=temp3(2:2:end).^2; % squaring of the even-indexed entries
        % u2 = Wout2*temp3;   % squaring of the even-indexed entries
        u2 = Wout2*x(1:resSize2);                            
        u = [u2;0;0;0];
        Y2(:,t) = u2;   
    end
    Y_t2_T=Y_t2';
Y2_T=Y2';
% Dim_fractal_matrix_ture(iii,jjj)=Grassberger_Procaccia(inSize2,Y_t2_T(1:gap:errorLen,:));
% Dim_fractal_matrix_pre(iii,jjj)=Grassberger_Procaccia(inSize2,Y2_T(1:gap:errorLen,:));

Dim_fractal_matrix_ture(iii)=Grassberger_Procaccia(inSize2,Y_t2_T(1:gap:errorLen,:));
Dim_fractal_matrix_pre(iii)=Grassberger_Procaccia(inSize2,Y2_T(1:gap:errorLen,:));

    % figure(2);
    % plot( Y_t2(1,1:errorLen), 'color', [0,0.75,0] );
    % hold on;
    % plot( Y2(1,1:errorLen), 'b' );
    % hold off;
    % axis tight;
    % title('The predicted and true values of the Roessler system');
    % legend('Target signal', ' predicted signal');
    % 
    % figure(3);
    % plot3(Y2(1,:),Y2(2,:),Y2(3,:))

    case 'SprottC'
        x=X(:,end);
    for t = 1:testLen 
        
        u2 = u(1:inSize2);
        u3 = u(inSize2+1:inSize2+inSize3);
        
        
        temp2=Win2*u2;
        temp3=Win3*u3;
        
        temp=[temp2;temp3];
        x = (1-a)*x + a*tanh( temp + W*x );  
        % temp3=x(1+resSize1:end);    % squaring of the even-indexed entries
        % temp3(2:2:end)=temp3(2:2:end).^2; % squaring of the even-indexed entries
        % u2 = Wout2*temp3;   % squaring of the even-indexed entries
        u3 = Wout3*x(resSize2+1:resSize2+resSize3);                            
        u = [0;0;0;u3];
        Y3(:,t) = u3;   
    end
    % figure(2);
    % plot( Y_t3(1,1:errorLen), 'color', [0,0.75,0] );
    % hold on;
    % plot( Y3(1,1:errorLen), 'b' );
    % hold off;
    % axis tight;
    % title('The predicted and true values of the Roessler system');
    % legend('Target signal', ' predicted signal');
    % 
    % figure(3);
    % plot3(Y3(1,:),Y3(2,:),Y3(3,:))

   Y_t3_T=Y_t3';
Y3_T=Y3';
% Dim_fractal_matrix_ture(iii,jjj)=Grassberger_Procaccia(inSize3,Y_t3_T(1:gap:errorLen,:));
% Dim_fractal_matrix_pre(iii,jjj)=Grassberger_Procaccia(inSize3,Y3_T(1:gap:errorLen,:)); 
Dim_fractal_matrix_ture(iii)=Grassberger_Procaccia(inSize3,Y_t3_T(1:gap:errorLen,:));
Dim_fractal_matrix_pre(iii)=Grassberger_Procaccia(inSize3,Y3_T(1:gap:errorLen,:));




% err_fractal=abs((Dim_fractal_matrix_pre(iii) -Dim_fractal_matrix_ture(iii))/Dim_fractal_matrix_ture(iii));
% bool_recon_vec(iii)=err_fractal< 0.2;


end



end
% end

out_dir = fullfile(here, '..', '..', 'Data', 'sprottBC_modularity_robustness', ...
                   'undiag_results', 'modularity_successrate');
if ~exist(out_dir, 'dir'); mkdir(out_dir); end
dlmwrite(fullfile(out_dir, 'Q_max_vec_sprottBC2_500times.dat'), Q_max_vec, 'delimiter', '\t');
dlmwrite(fullfile(out_dir, 'Dim_fractal_matrix_ture_sprottC_500times.dat'), Dim_fractal_matrix_ture, 'delimiter', '\t');
dlmwrite(fullfile(out_dir, 'Dim_fractal_matrix_pre_sprottC_500times.dat'), Dim_fractal_matrix_pre, 'delimiter', '\t');



% mse1 = sum((Y_t1(1,1:errorLen)-Y1(1,1:errorLen)).^2)./errorLen;

% mse = sum((Y_t(1,1:errorLen)-Y(1,1:errorLen)).^2)./errorLen+sum((Y_t(3,1:errorLen)-Y(3,1:errorLen)).^2)./errorLen;
% rmse1 = sqrt(mse1);
% disp( ['MSE = ', num2str( rmse )] );


% plot(Y2(2,:),Y2(3,:))
% hold on;
% plot(Y3(2,:),Y3(3,:))
% xlabel('x')
% ylabel('y')
% 
% 
% 
% plot(data2(2,1:30000),data2(3,1:30000),'k')
% hold on;
% plot(data3(2,1:30000),data3(3,1:30000),'k')
% ylim([-1.1 1.1])
% xlim([-1.1 1.1])
% xlabel('x')
% ylabel('y')




err_fractal_dim=abs((Dim_fractal_matrix_pre -Dim_fractal_matrix_ture)./Dim_fractal_matrix_ture);
bool_fractal=err_fractal_dim<0.2;
positions_fractal = find(bool_fractal == 0);
Q_fail=Q_max_vec(positions_fractal);   % modularity of the failed realizations
Q_success= setdiff(Q_max_vec, Q_fail);% modularity of the successful realizations
