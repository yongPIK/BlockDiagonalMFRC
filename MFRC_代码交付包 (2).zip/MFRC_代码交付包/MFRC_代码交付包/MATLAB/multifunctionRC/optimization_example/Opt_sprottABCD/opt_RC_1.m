clear all;
close all;
clc;
% %% config
% addpath '..\Functions'n

iter_max = 300; % number of optimization iterations
n = 400; % size of reservoir network
bo = 1; % best of. onlying pick the best one among bo reservoirs
repeat_num = 10; % repeating time in each iteration to reduce fluctuations
func = @(x) (func_train_repeat(x,n,bo,repeat_num));

% optimizatin config
% 1~5: a  W_in_a  k  eig_rho  reg
% 
lb = [0  0  0  0  0 1   1   1   1 -3  -3 -3  -3 0.00000001 ]; % upper bounds
ub = [1  3  3  3  3 100  100 100  100 3  3 3  3 0.001 ]; % lower bounds

options = optimoptions('surrogateopt','MaxFunctionEvaluations',iter_max,'PlotFcn','surrogateoptplot');

filename = ['opt_multiRC_1' datestr(now,'yyyy_mm_dd_HH_MM_SS')  '.mat'];

rng('shuffle')

%% optimization
tic
[opt_result,opt_fval,opt_exitflag,opt_output,opt_trials] = surrogateopt(func,lb,ub,options);
toc

%% save and exit
save(filename)
% if ~ispc
%     exit;
% end


