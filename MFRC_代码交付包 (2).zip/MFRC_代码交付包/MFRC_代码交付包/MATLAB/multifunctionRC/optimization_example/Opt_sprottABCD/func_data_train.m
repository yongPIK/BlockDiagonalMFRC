function rmse = func_data_train(hyperpara_set,resSize,bo)

P_datas1 = load('data_SprottA_2000_0.01.dat');
data1 = P_datas1';

P_datas2 = load('data_SprottB_2000_0.01.dat');
data2 = P_datas2';

P_datas3 = load('data_SprottC_2000_0.01.dat');
data3 = P_datas3';

P_datas4 = load('data_SprottD_2000_0.01.dat');
data4 = P_datas4';

% data(1,:)=data(1,:)./max(abs(data(1,:))); %normalized
% data(2,:)=data(2,:)./max(abs(data(2,:)));
% data(3,:)=data(3,:)./max(abs(data(3,:)));
for i=1:3
    data1(i,:)=data1(i,:)./max(abs(data1(i,:))); %normalized
end

for i=1:3
    data2(i,:)=data2(i,:)./max(abs(data2(i,:))); %normalized
end

for i=1:3
    data3(i,:)=data3(i,:)./max(abs(data3(i,:))); %normalized
end

for i=1:3
    data4(i,:)=data4(i,:)./max(abs(data4(i,:))); %normalized
end

% generate the ESN reservoir
trainLen = 60000;
trainLen1=50000;
trainLen2=20000;
trainLen3=30000;
trainLen4=40000;
testLen = 10000;
initLen = 6000;
inSize1 = 3;
outSize1 =3;

inSize2 = 3;
outSize2 =3;

inSize3 = 3;
outSize3 =3;

inSize4 = 3;
outSize4 =3;

resSize1 = 100;
resSize2 = 100;
resSize3 = 100;
resSize4 = 100;
% resSize=resSize1+resSize2+resSize3+resSize4;
add_dim = 0;

a = hyperpara_set(1) ; % leaking rate
W_in_a1 = hyperpara_set(2);
W_in_a2 = hyperpara_set(3);
W_in_a3 = hyperpara_set(4);
W_in_a4 = hyperpara_set(5);
k1 = hyperpara_set(6);
k2 = hyperpara_set(7);
k3 = hyperpara_set(8);
k4 = hyperpara_set(9);
eig_rho1 = hyperpara_set(10);
eig_rho2 = hyperpara_set(11);
eig_rho3 = hyperpara_set(12);
eig_rho4 = hyperpara_set(13);
reg = hyperpara_set(14);  % regularization coefficient

W_in_type = 1;   W_r_type = 1;
Win1= gene_Win(resSize1,inSize1,add_dim,W_in_a1,W_in_type);
W1 = gene_Wr(resSize1,k1,eig_rho1,W_r_type);

Win2= gene_Win(resSize2,inSize2,add_dim,W_in_a2,W_in_type);
W2 = gene_Wr(resSize2,k2,eig_rho2,W_r_type);

Win3= gene_Win(resSize3,inSize3,add_dim,W_in_a3,W_in_type);
W3 = gene_Wr(resSize3,k3,eig_rho3,W_r_type);

Win4= gene_Win(resSize4,inSize4,add_dim,W_in_a4,W_in_type);
W4 = gene_Wr(resSize4,k4,eig_rho4,W_r_type);

W = blkdiag(W1, W2, W3, W4);
 % b=rand(resSize,1)-0.5;
% allocated memory for the design (collected states) matrix
 X = zeros(resSize,trainLen-initLen);                                             %%%%%  1+inSize+resSize
% X = zeros(1+inSize+resSize,trainLen-initLen);    % need to change while with bias  

% set the corresponding target matrix directly
Yt1 = data1(:,trainLen-trainLen1+2:trainLen+1);
Yt2 = data2(:,trainLen-trainLen2+2:trainLen+1);
Yt3 = data3(:,trainLen-trainLen3+2:trainLen+1);
Yt4 = data4(:,trainLen-trainLen4+2:trainLen+1);

% run the reservoir with the data and collect X
x = zeros(resSize,1);
for t = 1:trainLen
    u1 = data1(:,t);
    u2 = data2(:,t);
    u3 = data3(:,t);
    u4 = data4(:,t);
    temp1=Win1*u1;
    temp2=Win2*u2;
    temp3=Win3*u3;
    temp4=Win4*u4;
    temp=[temp1;temp2;temp3;temp4];
    x = (1-a)*x + a*tanh( temp + W*x );               
     
    if t > initLen
         X(:,t-initLen) = x;                       
        % X(:,t-initLen) = [1;u;x]; 
    end
end

% train the output

X1=X(1:resSize1,end-trainLen1+1:end);
X1_T = X1';
Wout1 = Yt1*X1_T / (X1*X1_T + reg*eye(resSize1));                             

X2=X(resSize1+1:resSize1+resSize2,end-trainLen2+1:end);
% X2(2:2:end, :) = X2(2:2:end, :).^2; % squaring of the even-indexed entries
X2_T = X2';
Wout2 = Yt2*X2_T / (X2*X2_T + reg*eye(resSize2));   

X3=X(resSize1+resSize2+1:resSize1+resSize2+resSize3,end-trainLen3+1:end);
X3_T = X3';
Wout3 = Yt3*X3_T / (X3*X3_T + reg*eye(resSize3)); 

X4=X(resSize1+resSize2+resSize3+1:end,end-trainLen4+1:end);
X4_T = X4';
Wout4 = Yt4*X4_T / (X4*X4_T + reg*eye(resSize4)); 

Y1 = zeros(outSize1,testLen);
Y2 = zeros(outSize2,testLen);
Y3 = zeros(outSize3,testLen);
Y4 = zeros(outSize4,testLen);

u1 = data1(:,trainLen+1);
u2 = data2(:,trainLen+1);
u3 = data3(:,trainLen+1);
u4 = data4(:,trainLen+1);
errorLen = testLen;
Y_t1 =data1(:,trainLen+2:trainLen+errorLen+1);
Y_t2 =data2(:,trainLen+2:trainLen+errorLen+1);
Y_t3 =data3(:,trainLen+2:trainLen+errorLen+1);
Y_t4 =data4(:,trainLen+2:trainLen+errorLen+1);
u=[u1;u2;u3;u4];


        x=X(:,end);
    for t = 1:testLen 
        u1 = u(1:inSize1);
        u2 = u(inSize1+1:inSize1+inSize2);
        u3 = u(inSize1+inSize2+1:inSize1+inSize2+inSize3);
        u4 = u(inSize1+inSize2+inSize3+1:end);
        temp1=Win1*u1;
        temp2=Win2*u2;
        temp3=Win3*u3;
        temp4=Win4*u4;
        temp=[temp1;temp2;temp3;temp4];
        x = (1-a)*x + a*tanh( temp + W*x );                
        u1 = Wout1*x(1:resSize1);                            
        u = [u1;0;0;0;0;0;0;0;0;0];
        Y1(:,t) = u1;
    end
    errorLen=5000;
     mse = sum((Y_t1(1,1:errorLen)-Y1(1,1:errorLen)).^2)./errorLen+sum((Y_t1(2,1:errorLen)-Y1(2,1:errorLen)).^2)./errorLen+sum((Y_t1(3,1:errorLen)-Y1(3,1:errorLen)).^2)./errorLen;
 rmse1 = sqrt(mse); 

        x=X(:,end);
    for t = 1:testLen 
        u1 = u(1:inSize1);
        u2 = u(inSize1+1:inSize1+inSize2);
        u3 = u(inSize1+inSize2+1:inSize1+inSize2+inSize3);
        u4 = u(inSize1+inSize2+inSize3+1:end);
        temp1=Win1*u1;
        temp2=Win2*u2;
        temp3=Win3*u3;
        temp4=Win4*u4;
        temp=[temp1;temp2;temp3;temp4];
        x = (1-a)*x + a*tanh( temp + W*x );  
        % temp3=x(1+resSize1:end);    % squaring of the even-indexed entries
        % temp3(2:2:end)=temp3(2:2:end).^2; % squaring of the even-indexed entries
        % u2 = Wout2*temp3;   % squaring of the even-indexed entries
        u2 = Wout2*x(resSize1+1:resSize1+resSize2);                            
        u = [0;0;0;u2;0;0;0;0;0;0];
        Y2(:,t) = u2;   
    end
    errorLen=500;
     mse = sum((Y_t2(1,1:errorLen)-Y2(1,1:errorLen)).^2)./errorLen+sum((Y_t2(2,1:errorLen)-Y2(2,1:errorLen)).^2)./errorLen+sum((Y_t2(3,1:errorLen)-Y2(3,1:errorLen)).^2)./errorLen;
 rmse2 = sqrt(mse); 

        x=X(:,end);
    for t = 1:testLen 
        u1 = u(1:inSize1);
        u2 = u(inSize1+1:inSize1+inSize2);
        u3 = u(inSize1+inSize2+1:inSize1+inSize2+inSize3);
        u4 = u(inSize1+inSize2+inSize3+1:end);
        temp1=Win1*u1;
        temp2=Win2*u2;
        temp3=Win3*u3;
        temp4=Win4*u4;
        temp=[temp1;temp2;temp3;temp4];
        x = (1-a)*x + a*tanh( temp + W*x );  
        % temp3=x(1+resSize1:end);    % squaring of the even-indexed entries
        % temp3(2:2:end)=temp3(2:2:end).^2; % squaring of the even-indexed entries
        % u2 = Wout2*temp3;   % squaring of the even-indexed entries
        u3 = Wout3*x(resSize1+resSize2+1:resSize1+resSize2+resSize3);                            
        u = [0;0;0;0;0;0;u3;0;0;0];
        Y3(:,t) = u3;   
    end
    errorLen=600;
     mse = sum((Y_t3(1,1:errorLen)-Y3(1,1:errorLen)).^2)./errorLen+sum((Y_t3(2,1:errorLen)-Y3(2,1:errorLen)).^2)./errorLen+sum((Y_t3(3,1:errorLen)-Y3(3,1:errorLen)).^2)./errorLen;
 rmse3 = sqrt(mse); 

        x=X(:,end);
    for t = 1:testLen 
        u1 = u(1:inSize1);
        u2 = u(inSize1+1:inSize1+inSize2);
        u3 = u(inSize1+inSize2+1:inSize1+inSize2+inSize3);
        u4 = u(inSize1+inSize2+inSize3+1:end);
        temp1=Win1*u1;
        temp2=Win2*u2;
        temp3=Win3*u3;
        temp4=Win4*u4;
        temp=[temp1;temp2;temp3;temp4];
        x = (1-a)*x + a*tanh( temp + W*x );  
        % temp3=x(1+resSize1:end);    % squaring of the even-indexed entries
        % temp3(2:2:end)=temp3(2:2:end).^2; % squaring of the even-indexed entries
        % u2 = Wout2*temp3;   % squaring of the even-indexed entries
        u4 = Wout4*x(resSize1+resSize2+resSize3+1:end);                            
        u = [0;0;0;0;0;0;0;0;0;u4];
        Y4(:,t) = u4;   
    end
    
errorLen=1000;
  mse = sum((Y_t4(1,1:errorLen)-Y4(1,1:errorLen)).^2)./errorLen+sum((Y_t4(2,1:errorLen)-Y4(2,1:errorLen)).^2)./errorLen+sum((Y_t4(3,1:errorLen)-Y4(3,1:errorLen)).^2)./errorLen;
 rmse4 = sqrt(mse);  

 rmse=rmse1+rmse2+rmse3+rmse4;
end













