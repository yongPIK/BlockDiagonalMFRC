function run_MFRC(mode)
% RUN_MFRC Unified entry point for the multifunction/MFRC experiments.
%
% Usage:
%   run_MFRC('10sys')                 % 10-system MFRC (Fig.7 / Table 3, Table 4 support)
%   run_MFRC('lorenz_roessler')       % two decoupled modules: Lorenz + Roessler (Fig.2)
%   run_MFRC('lorenz_roessler_coupled') % weakly coupled Lorenz-Roessler (Fig.6)
%   run_MFRC('sprottBC')              % Sprott B/C modules + functional modularity Q (Fig.8 support)
%   run_MFRC('sprottBC_addnoise')     % cross-module perturbation eta(s_p, n_sigma) (Fig.8a-c)
%   run_MFRC('sprottBC_muinfo')       % mutual-information network -> modularity map (Fig.8d)
%
% Note: only the experiment entry points actually used in the manuscript and in
% the reply are kept, to avoid duplicate scripts.

if nargin < 1 || isempty(mode)
    mode = '10sys';
end

here = fileparts(mfilename('fullpath'));
addpath(genpath(here));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data')));

switch lower(mode)
    case 'lorenz_roessler'
        script = 'multi_regress_RC.m';
        script_dir = fullfile(here, 'legacy');
    case 'lorenz_roessler_coupled'
        script = 'regress_RC_lorenzcouplingroessler.m';
        script_dir = here;
    case {'10sys', '10sys_fractal'}
        % Production 10-system fractal-dimension experiment (Fig.7 / Table 3).
        script = 'multi_regress_RC_10sys_fractaldim.m';
        script_dir = fullfile(here, '..', 'MFRC_core');
    case 'sprottbc'
        script = 'multi_regress_RC_sprottBC.m';
        script_dir = fullfile(here, '..', 'sprottBC_modularity_robustness');
    case 'sprottbc_addnoise'
        script = 'multi_regress_RC_sprottBC_addnoise.m';
        script_dir = fullfile(here, '..', 'sprottBC_modularity_robustness');
    case 'sprottbc_muinfo'
        script = 'multi_regress_RC_sprottBC_addnoise_corr_mu_info.m';
        script_dir = fullfile(here, '..', 'sprottBC_modularity_robustness');
    otherwise
        error('Unknown mode: %s', mode);
end

if ~exist('script_dir', 'var')
    script_dir = fullfile(here, 'legacy');
end
script_path = fullfile(script_dir, script);
if ~exist(script_path, 'file')
    error('Legacy script not found: %s', script_path);
end

% Legacy scripts use relative output folders such as RC_fractal_10sys/.
% Run them from the legacy directory so those relative paths resolve.
cd(script_dir);
run(script_path);
end
