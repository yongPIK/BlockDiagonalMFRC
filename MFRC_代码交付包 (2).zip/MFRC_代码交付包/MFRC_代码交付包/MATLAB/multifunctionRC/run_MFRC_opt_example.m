% RUN_MFRC_OPT_EXAMPLE
% Single optimization example for the SprottABCD MFRC experiment.
%
% This uses surrogateopt and the same objective function as the original
% Opt_sprottABCD example (the n=4 arm of the optimization-cost comparison in
% Table 7). It is intentionally kept as the only optimization template; the
% remaining optimization variants are not part of the paper.

here = fileparts(mfilename('fullpath'));
addpath(genpath(here));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data')));

example_dir = fullfile(here, 'optimization_example', 'Opt_sprottABCD');
cd(example_dir);
run('opt_RC_1.m');
