% plot for Sprott B and C

clear; clc; close all; 

success_rate_matrix_sprottB = []; 
success_rate_matrix_sprottC = []; 
for ix = 1:1:21
    dataFileB = ['result_add_noise', filesep, 'success_rate_matrix_sprottB_labIndex', num2str(ix, '%02d'), '.txt']; 
    dataFileC = ['result_add_noise', filesep, 'success_rate_matrix_sprottC_labIndex', num2str(ix, '%02d'), '.txt']; 

    data = load(dataFileB); 
%    size(data)
    
    success_rate_matrix_sprottB = cat(1, success_rate_matrix_sprottB, data(1:8, 1)');  

    data = load(dataFileC); 
%    size(data)
    
    success_rate_matrix_sprottC = cat(1, success_rate_matrix_sprottC, data(1:8, 1)');  
end

size(success_rate_matrix_sprottB)
size(success_rate_matrix_sprottC)

A = 0:0.05:1; 
B = 1:8; 

alp_vec=[0 0.0001 0.0005 0.001 0.005 0.01 0.05 0.1];

hps = figure('Position', [100 100 800 600], 'DefaultTextFontName', 'times', 'DefaultAxesFontName', 'times', 'DefaultTextFontSize', 24, 'DefaultAxesFontSize', 24);
% nexttile
axes('Position', [0.30 0.37 0.18 0.5]);
imagesc(A, B, success_rate_matrix_sprottB); 
axis xy; 
colormap default;
colorbar; 
set(gca, 'yticklabel', {num2str(alp_vec(1), '%g'), num2str(alp_vec(2), '%g'), num2str(alp_vec(3), '%g'), ...
    num2str(alp_vec(4), '%g'), num2str(alp_vec(5), '%g'), num2str(alp_vec(6), '%g'), ... 
    num2str(alp_vec(7), '%g'), num2str(alp_vec(8), '%g') });
xlabel('$s_p$', 'interpreter', 'latex'); 
ylabel('$n_\sigma$', 'interpreter', 'latex'); 
text(-0.9, 8, '(a)', 'FontSize', 28); 

axes('Position', [0.62 0.37 0.18 0.5]);
imagesc(A, B, success_rate_matrix_sprottC); 
axis xy; 
colormap default;
colorbar; 
set(gca, 'yticklabel', {num2str(alp_vec(1), '%g'), num2str(alp_vec(2), '%g'), num2str(alp_vec(3), '%g'), ...
    num2str(alp_vec(4), '%g'), num2str(alp_vec(5), '%g'), num2str(alp_vec(6), '%g'), ... 
    num2str(alp_vec(7), '%g'), num2str(alp_vec(8), '%g') });
xlabel('$s_p$', 'interpreter', 'latex'); 
ylabel('$n_\sigma$', 'interpreter', 'latex'); 
text(-0.9, 8, '(b)', 'FontSize', 28); 

% tightfig(hps); 
print(hps, '-dpdf', 'sp_ns_SprottBC.pdf');
