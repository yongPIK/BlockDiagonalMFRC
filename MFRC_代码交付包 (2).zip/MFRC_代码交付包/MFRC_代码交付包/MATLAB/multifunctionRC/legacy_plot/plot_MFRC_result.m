
addpath ('result_MFRC/')
%% predicted and ground-truth attractors of the ten systems
sprottA_pre = load('sprottA_pre.dat');
sprottA_true = load('sprottA_true.dat');

sprottB_pre = load('sprottB_pre.dat');
sprottB_true = load('sprottB_true.dat');

sprottC_pre = load('sprottC_pre.dat');
sprottC_true = load('sprottC_true.dat');

sprottD_pre = load('sprottD_pre.dat');
sprottD_true = load('sprottD_true.dat');

Lorenz_pre = load('Lorenz_pre.dat');
Lorenz_true = load('Lorenz_true.dat');

roessler_pre = load('roessler_pre.dat');
roessler_true = load('roessler_true.dat');

chen_pre = load('chen_pre.dat');
chen_true = load('chen_true.dat');

sel_kov_pre = load('sel_kov_pre.dat');
sel_kov_true = load('sel_kov_true.dat');

hyperchaotic_oscillator_pre = load('hyperchaotic_oscillator_pre.dat');
hyperchaotic_oscillator_true = load('hyperchaotic_oscillator_true.dat');

hyper_sprottB_pre = load('hyper_sprottB_pre.dat');
hyper_sprottB_true = load('hyper_sprottB_true.dat');


hps=figure % coexisting Lorenz and Roessler attractors, predicted
plot3(Lorenz_pre(1,:),Lorenz_pre(2,:),Lorenz_pre(3,:))
hold on;
plot3(roessler_pre(1,:),roessler_pre(2,:),roessler_pre(3,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'Lorenz_roessler_pre_3Dxyz.pdf');


hps=figure % coexisting Lorenz and Roessler attractors, ground truth
plot3(Lorenz_true(1,:),Lorenz_true(2,:),Lorenz_true(3,:))
hold on;
plot3(roessler_true(1,:),roessler_true(2,:),roessler_true(3,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'Lorenz_roessler_true_3Dxyz.pdf');


hps=figure % coexisting Chen and hyperchaotic-oscillator attractors, predicted
plot3(chen_pre(1,:),chen_pre(2,:),chen_pre(3,:))
hold on;
plot3(hyperchaotic_oscillator_pre(1,:),hyperchaotic_oscillator_pre(2,:),hyperchaotic_oscillator_pre(3,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'chen_hyperchaotic_oscillator_pre_3Dxyz.pdf');

hps=figure % coexisting Chen and hyperchaotic-oscillator attractors, ground truth
plot3(chen_true(1,:),chen_true(2,:),chen_true(3,:))
hold on;
plot3(hyperchaotic_oscillator_true(1,:),hyperchaotic_oscillator_true(2,:),hyperchaotic_oscillator_true(3,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'chen_hyperchaotic_oscillator_true_3Dxyz.pdf');


hps=figure % hyperchaotic oscillator: xyz projection of the predicted and true attractors
plot3(hyperchaotic_oscillator_pre(1,:),hyperchaotic_oscillator_pre(2,:),hyperchaotic_oscillator_pre(3,:))
hold on;
plot3(hyperchaotic_oscillator_true(1,:),hyperchaotic_oscillator_true(2,:),hyperchaotic_oscillator_true(3,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'hyperchaotic_oscillator_pre_true_3Dxyz.pdf');

hps=figure % hyperchaotic oscillator: xyw projection of the predicted and true attractors
plot3(hyperchaotic_oscillator_pre(1,:),hyperchaotic_oscillator_pre(2,:),hyperchaotic_oscillator_pre(4,:))
hold on;
plot3(hyperchaotic_oscillator_true(1,:),hyperchaotic_oscillator_true(2,:),hyperchaotic_oscillator_true(4,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'hyperchaotic_oscillator_pre_true_3Dxyw.pdf');

hps=figure % hyperchaotic oscillator: xzw projection of the predicted and true attractors
plot3(hyperchaotic_oscillator_pre(1,:),hyperchaotic_oscillator_pre(3,:),hyperchaotic_oscillator_pre(4,:))
hold on;
plot3(hyperchaotic_oscillator_true(1,:),hyperchaotic_oscillator_true(3,:),hyperchaotic_oscillator_true(4,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'hyperchaotic_oscillator_pre_true_3Dxzw.pdf');

hps=figure % hyperchaotic oscillator: yzw projection of the predicted and true attractors
plot3(hyperchaotic_oscillator_pre(2,:),hyperchaotic_oscillator_pre(3,:),hyperchaotic_oscillator_pre(4,:))
hold on;
plot3(hyperchaotic_oscillator_true(2,:),hyperchaotic_oscillator_true(3,:),hyperchaotic_oscillator_true(4,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'hyperchaotic_oscillator_pre_true_3Dyzw.pdf');





hps=figure % coexisting Lorenz, Roessler, Selkov and hyperchaotic-oscillator attractors, predicted
plot(Lorenz_pre(1,:),Lorenz_pre(2,:))
hold on;
plot(roessler_pre(1,:),roessler_pre(2,:))
plot(sel_kov_pre(1,:),sel_kov_pre(2,:))
plot(hyperchaotic_oscillator_pre(1,:),hyperchaotic_oscillator_pre(2,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'Lorenz_roessler_sel_kov_hyperchaotic_oscillator_pre_2Dxy.pdf');


hps=figure % coexisting Lorenz, Roessler, Selkov and hyperchaotic-oscillator attractors, ground truth
plot(Lorenz_true(1,:),Lorenz_true(2,:))
hold on;
plot(roessler_true(1,:),roessler_true(2,:))
plot(sel_kov_true(1,:),sel_kov_true(2,:))
plot(hyperchaotic_oscillator_true(1,:),hyperchaotic_oscillator_true(2,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'Lorenz_roessler_sel_kov_hyperchaotic_oscillator_true_2Dxy.pdf');


%% attractors of the coupled Lorenz-Roessler model

Lorenz_pre = load('Lorenz_coupling_pre.dat');
Lorenz_true = load('Lorenz_coupling_true.dat');

roessler_pre = load('roessler_coupling_pre.dat');
roessler_true = load('roessler_coupling_true.dat');

hps=figure %coupled Lorenz-Roessler model: coexisting attractors, predicted
plot3(Lorenz_pre(1,:),Lorenz_pre(2,:),Lorenz_pre(3,:))
hold on;
plot3(roessler_pre(1,:),roessler_pre(2,:),roessler_pre(3,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'Lorenz_roessler_coupling_pre_3Dxyz.pdf');


hps=figure %coupled Lorenz-Roessler model: coexisting attractors, ground truth
plot3(Lorenz_true(1,:),Lorenz_true(2,:),Lorenz_true(3,:))
hold on;
plot3(roessler_true(1,:),roessler_true(2,:),roessler_true(3,:))
axis on;
tightfig(hps); 
print(hps, '-dpdf', 'Lorenz_roessler_coupling_true_3Dxyz.pdf');


%% distribution of the correlation dimension
fractal_dim_pre = load('Dim_fractal_matrix_pre_10sys_30000length_gap10_500times.dat');  %MFRC prediction of the correlation dimension, ten systems
fractal_dim_true = load('Dim_fractal_matrix_ture_10sys_30000length_gap10_500times.dat');  %true correlation dimension, ten systems



SprottA_MFRC_pre=fractal_dim_pre(:,1);  % sprottApredicted correlation dimension of this system
SprottA_ture=fractal_dim_true(1,1);  % sprottAtrue correlation dimension of this system
SprottB_MFRC_pre=fractal_dim_pre(:,2);
SprottB_ture=fractal_dim_true(1,2);
SprottC_MFRC_pre=fractal_dim_pre(:,3);
SprottC_ture=fractal_dim_true(1,3);
SprottD_MFRC_pre=fractal_dim_pre(:,4);
SprottD_ture=fractal_dim_true(1,4);
Lorenz_MFRC_pre=fractal_dim_pre(:,5);
Lorenz_ture=fractal_dim_true(1,5);
Roessler_MFRC_pre=fractal_dim_pre(:,6);
Roessler_ture=fractal_dim_true(1,6);
Chen_MFRC_pre=fractal_dim_pre(:,7);
Chen_ture=fractal_dim_true(1,7);
Sel_kov_MFRC_pre=fractal_dim_pre(:,8);
Sel_kov_ture=fractal_dim_true(1,8);
Hyperchaotic_oscillator_MFRC_pre=fractal_dim_pre(:,9);
Hyperchaotic_oscillator_ture=fractal_dim_true(1,9);
Hyper_sprottB_MFRC_pre=fractal_dim_pre(:,10);
Hyper_sprottB_ture=fractal_dim_true(1,10);


hps=figure(1) % sprottAdistribution of the predicted correlation dimension
histogram(SprottA_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(SprottA_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(SprottA_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(SprottA_MFRC_pre)-0.1, max(SprottA_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'SprottA_predim_distribution.pdf');




hps=figure(2)  % sprottBdistribution of the predicted correlation dimension
histogram(SprottB_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(SprottB_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(SprottB_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(SprottB_MFRC_pre)-0.1, max(SprottB_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'SprottB_predim_distribution.pdf');



hps=figure(3)  % sprottCdistribution of the predicted correlation dimension
histogram(SprottC_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(SprottC_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(SprottC_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(SprottC_MFRC_pre)-0.1, max(SprottC_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'SprottC_predim_distribution.pdf');

hps=figure(4)  % sprottDdistribution of the predicted correlation dimension
histogram(SprottD_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(SprottD_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(SprottD_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(SprottD_MFRC_pre)-0.1, max(SprottD_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'SprottD_predim_distribution.pdf');

hps=figure(5)   % Lorenzdistribution of the predicted correlation dimension
histogram(Lorenz_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(Lorenz_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(Lorenz_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(Lorenz_MFRC_pre)-0.1, max(Lorenz_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'Lorenz_predim_distribution.pdf');


hps=figure(6)   % Roesslerdistribution of the predicted correlation dimension
histogram(Roessler_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(Roessler_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(Roessler_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(Roessler_MFRC_pre)-0.1, max(Roessler_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'Roessler_predim_distribution.pdf');

hps=figure(7)   % chendistribution of the predicted correlation dimension
histogram(Chen_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(Chen_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(Chen_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(Chen_MFRC_pre)-0.1, max(Chen_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'Chen_predim_distribution.pdf');

hps=figure(8)   % sel_kovdistribution of the predicted correlation dimension
histogram(Sel_kov_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(Sel_kov_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(Sel_kov_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(Sel_kov_MFRC_pre)-0.1, max(Sel_kov_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'Sel_kov_predim_distribution.pdf');

hps=figure(9)   % Hyperchaotic_oscillatordistribution of the predicted correlation dimension
histogram(Hyperchaotic_oscillator_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(Hyperchaotic_oscillator_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(Hyperchaotic_oscillator_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(Hyperchaotic_oscillator_MFRC_pre)-0.1, max(Hyperchaotic_oscillator_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'Hyperchaotic_oscillator_predim_distribution.pdf');

hps=figure(10)  % Hyper_sprottBdistribution of the predicted correlation dimension
histogram(Hyper_sprottB_MFRC_pre, 'Normalization', 'pdf', ...
          'BinWidth', 0.05, ...
          'EdgeColor', [0.5 0.5 0.5], ...
          'FaceAlpha', 0.7);
hold on;
 
vline = xline(Hyper_sprottB_ture, 'k--', 'LineWidth', 1.5);

[pdf_vals, xi] = ksdensity(Hyper_sprottB_MFRC_pre); %KDE fit
plot(xi, pdf_vals, 'LineWidth', 2, 'Color', [0.8 0.2 0.2]);
 
title('Statistical Distribution of Correlation Dimension of MFRC', 'FontSize', 12)
xlabel('Correlation Dimension', 'FontSize', 10)
ylabel('Probability Density', 'FontSize', 10)
legend({'Histogram', 'Ture Correlation Dimension','Kernel Density'}, 'Location', 'best')
grid on
set(gca, 'FontSize', 10) 
xlim([min(Hyper_sprottB_MFRC_pre)-0.1, max(Hyper_sprottB_MFRC_pre)+0.1]);

tightfig(hps); 
print(hps, '-dpdf', 'Hyper_sprottB_predim_distribution.pdf');