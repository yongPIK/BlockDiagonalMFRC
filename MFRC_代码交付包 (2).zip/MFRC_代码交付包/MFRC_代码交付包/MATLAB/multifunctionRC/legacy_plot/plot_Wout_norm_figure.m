clear; close all;

here    = fileparts(mfilename('fullpath'));
matFile = fullfile(here, '..', '..', '..', 'Data', 'Wout_norm', 'data', 'Wout_readout_data.mat');
if ~exist(matFile, 'file')
    error('Wout_readout_data.mat not found at %s', matFile);
end
S = load(matFile);

pooled = double(S.pooled_abs(:));
fro    = double(S.fro(:));
names  = S.names;

% ---- bins exactly as in the Python version -------------------------------
lo   = max(min(pooled), 1e-6);
bins = logspace(log10(lo), log10(max(pooled)), 45);

fig = figure('Units', 'inches', 'Position', [1 1 9 4], 'Color', 'w');

% ---- panel (a): pooled |w| distribution ---------------------------------
ax1 = subplot(1, 2, 1);
histogram(pooled, bins, 'FaceColor', [0.298 0.447 0.690], 'EdgeColor', 'none');
set(ax1, 'XScale', 'log');
xlabel('|w| (ten task readouts pooled)');
ylabel('count');
title(sprintf('(a) trained readout weights\nmean |w| = %.3f, max = %.1f', ...
              mean(pooled), max(pooled)), 'FontSize', 9);

% ---- panel (b): per-task Frobenius norm ---------------------------------
ax2 = subplot(1, 2, 2);
bar(1:numel(fro), fro, 'FaceColor', [0.769 0.306 0.322], 'EdgeColor', 'none');
set(ax2, 'YScale', 'log');
set(ax2, 'XTick', 1:numel(fro), 'XTickLabel', names, ...
         'TickLabelInterpreter', 'none', 'FontSize', 6);
xtickangle(90);
ylabel('||W_{out}||_F');
title('(b) readout Frobenius norm per task', 'FontSize', 9);

% ---- export -------------------------------------------------------------
pngFile = fullfile(here, 'figR2-readout-weights_MATLAB.png');
pdfFile = fullfile(here, 'figR2-readout-weights_MATLAB.pdf');
print(fig, pngFile, '-dpng', '-r220');
print(fig, pdfFile, '-dpdf', '-bestfit');
fprintf('written: %s\n', pngFile);
fprintf('written: %s\n', pdfFile);

% ---- summary ------------------------------------------------------------
fprintf('\npooled |w| over %d weights: mean = %.4f, median = %.4f, max = %.3f\n', ...
        numel(pooled), mean(pooled), median(pooled), max(pooled));
fprintf('per-task Frobenius norm: min = %.2f, max = %.2f\n', min(fro), max(fro));
