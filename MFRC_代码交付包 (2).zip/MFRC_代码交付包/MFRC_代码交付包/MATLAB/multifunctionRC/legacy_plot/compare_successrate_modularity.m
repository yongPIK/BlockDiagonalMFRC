clear; clc; close all; 
addpath ('result_add_noise/')

success_rate_matrix_sprottB = []; 
success_rate_matrix_sprottC = []; 
for ix = 1:1:21
    dataFileB = ['result_add_noise', filesep, 'success_rate_matrix_sprottB_labIndex', num2str(ix, '%02d'), '.txt']; 
    dataFileC = ['result_add_noise', filesep, 'success_rate_matrix_sprottC_labIndex', num2str(ix, '%02d'), '.txt']; 

    data = load(dataFileB); 
%    size(data)
    
    success_rate_matrix_sprottB = cat(1, success_rate_matrix_sprottB, data(1:8, 1)');  

    data = load(dataFileC); 
%    size(data)
    
    success_rate_matrix_sprottC = cat(1, success_rate_matrix_sprottC, data(1:8, 1)');  
end

success_rate_matrix=(success_rate_matrix_sprottB+success_rate_matrix_sprottC)/2;
Q_matrix = load('Q_matrix_sprottBC_500times.dat');

y_range = 0:0.05:1; 
x_range = [0 0.0001 0.0005 0.001 0.005 0.01 0.05 0.1];
% phase diagrams
figure(1)
imagesc(x_range, y_range, success_rate_matrix); % main plotting call
colorbar; % add a colour bar
xlabel('amplitude n_\sigma');
ylabel('sparsity s_p');
title('success rate');
axis xy; 

figure(2)
imagesc(x_range, y_range, Q_matrix); % main plotting call
colorbar; % add a colour bar
xlabel('amplitude n_\sigma');
ylabel('sparsity s_p');
title('modularity Q');
axis xy; 


success_rate_vec=reshape(success_rate_matrix,[168,1]);
Q_vec=reshape(Q_matrix,[168,1]);
R_pearson = corr(success_rate_vec, Q_vec, 'Type', 'Pearson');
