function plot_MFRC_figures(mode)
% PLOT_MFRC_FIGURES Unified entry point for archived plotting scripts.
%
% Usage:
%   plot_MFRC_figures('main')        % 10-system attractors + D2 distributions (Fig.2-5, Fig.7)
%   plot_MFRC_figures('modularity')  % modularity/success comparison
%   plot_MFRC_figures('addnoise')    % Sprott B/C (s_p, n_sigma) success map (Fig.8a-c)
%   plot_MFRC_figures('wout')        % Wout norm analysis figure
%
% The original plotting scripts are kept under legacy_plot/.

if nargin < 1 || isempty(mode)
    mode = 'main';
end

here = fileparts(mfilename('fullpath'));
addpath(genpath(here));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data')));
addpath(genpath(fullfile(here, 'legacy_plot')));

switch lower(mode)
    case 'main'
        script = 'plot_MFRC_result.m';
        data_dir = fullfile(here, '..', '..', 'Data', 'result_MFRC', 'result_MFRC');
    case 'modularity'
        script = 'compare_successrate_modularity.m';
        % the success-rate grid and the Q grid live in two different folders
        data_dir = fullfile(here, '..', '..', 'Data', 'sprottBC_modularity_robustness', ...
                            'addnoise_results');
        addpath(genpath(fullfile(here, '..', '..', 'Data', 'multifunctionRC', ...
                                 'result_add_noise')));
    case 'addnoise'
        script = 'plot_SprottBC.m';
        data_dir = fullfile(here, '..', '..', 'Data', 'sprottBC_modularity_robustness', ...
                            'addnoise_results');
    case 'wout'
        script = 'plot_Wout_norm_figure.m';
        data_dir = '';
    otherwise
        error('Unknown plotting mode: %s', mode);
end

% The archived scripts use relative paths such as result_MFRC/ and
% result_add_noise/, so run them from the matching data directory.  Note that
% several of them start with `clear`, which also wipes the variables of this
% function, so the working directory is restored from mfilename() instead of
% from a stored value.
script_path = fullfile(here, 'legacy_plot', script);
if ~isempty(data_dir)
    if ~exist(data_dir, 'dir')
        error('Data directory not found: %s', data_dir);
    end
    cd(data_dir);
end
try
    run(script_path);
catch err
    cd(fileparts(mfilename('fullpath')));
    rethrow(err);
end
cd(fileparts(mfilename('fullpath')));
end
