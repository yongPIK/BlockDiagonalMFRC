clc;
clear;

% requires gene_Win / gene_Wr from shared/
here = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(here, '..', 'shared')));
addpath(genpath(fullfile(here, '..', '..', 'Data', 'TimeSeries')));



% load the data
P_datas = load('data_Lorenz_roessler_1000_0.01_strength0.01.dat');
data = P_datas';

data1=data(1:3,:);
data2=data(4:end,:);

% data(1,:)=data(1,:)./max(abs(data(1,:))); %normalized
% data(2,:)=data(2,:)./max(abs(data(2,:)));
% data(3,:)=data(3,:)./max(abs(data(3,:)));
for i=1:3
    data1(i,:)=data1(i,:)./max(abs(data1(i,:))); %normalized
end

for i=1:3
    data2(i,:)=data2(i,:)./max(abs(data2(i,:))); %normalized
end

% generate the ESN reservoir
trainLen = 30000;
trainLen1=5000;
trainLen2=10000;
testLen = 20000;
initLen = 3000;
inSize1 = 3;
outSize1 =3;

inSize2 = 3;
outSize2 =3;

resSize1 = 100;
resSize2 = 100;
resSize=resSize1+resSize2;
add_dim = 0;

MODEL={'Lorenz','roessler'};
model=MODEL{2};

% para1=[0.0390185235830287	3	1.24161295887415	74.2934015625509	8.38392246535097	-0.858692115293726	-0.234715964773395	0.000945227125799516];% first optimization run
para1=[0.1	2.812625069973912	0.958860215120228	94.966691341928170	1.025055932045079	0.730966611140523	2.703766177908375	1.00000000000000e-05]; % second optimization result
a = para1(1) ; % leaking rate
W_in_a1 = para1(2);
W_in_a2 = para1(3);
k1 = para1(4);
k2 = para1(5);
eig_rho1 = para1(6);
eig_rho2 = para1(7);
reg = para1(8);  % regularization coefficient

W_in_type = 1;   W_r_type = 1;
Win1= gene_Win(resSize1,inSize1,add_dim,W_in_a1,W_in_type);
W1 = gene_Wr(resSize1,k1,eig_rho1,W_r_type);

Win2= gene_Win(resSize2,inSize2,add_dim,W_in_a2,W_in_type);
W2 = gene_Wr(resSize2,k2,eig_rho2,W_r_type);

W = blkdiag(W1, W2);
 % b=rand(resSize,1)-0.5;
% allocated memory for the design (collected states) matrix
 X = zeros(resSize,trainLen-initLen);                                             %%%%%  1+inSize+resSize
% X = zeros(1+inSize+resSize,trainLen-initLen);    % need to change while with bias  

% set the corresponding target matrix directly
Yt1 = data1(:,trainLen-trainLen1+2:trainLen+1);
Yt2 = data2(:,trainLen-trainLen2+2:trainLen+1);

% run the reservoir with the data and collect X
x = zeros(resSize,1);
for t = 1:trainLen
    u1 = data1(:,t);
    u2 = data2(:,t);
    temp1=Win1*u1;
    temp2=Win2*u2;
    temp=[temp1;temp2];
    x = (1-a)*x + a*tanh( temp + W*x );               
     
    if t > initLen
         X(:,t-initLen) = x;                       
        % X(:,t-initLen) = [1;u;x]; 
    end
end

% train the output

X1=X(1:resSize1,end-trainLen1+1:end);
X1_T = X1';
Wout1 = Yt1*X1_T / (X1*X1_T + reg*eye(resSize1));                             

X2=X(resSize1+1:end,end-trainLen2+1:end);
% X2(2:2:end, :) = X2(2:2:end, :).^2; % squaring of the even-indexed entries
X2_T = X2';
Wout2 = Yt2*X2_T / (X2*X2_T + reg*eye(resSize2));   


Y1 = zeros(outSize1,testLen);
Y2 = zeros(outSize2,testLen);
u1 = data1(:,trainLen+1);
u2 = data2(:,trainLen+1);
errorLen = testLen;
Y_t1 =data1(:,trainLen+2:trainLen+errorLen+1);
Y_t2 =data2(:,trainLen+2:trainLen+errorLen+1);
u=[u1;u2];

switch model

    case 'Lorenz'
        x=X(:,end);
    for t = 1:testLen 
        u1 = u(1:inSize1);
        u2 = u(inSize1+1:end);
        temp1=Win1*u1;
        temp2=Win2*u2;
        temp=[temp1;temp2];
        x = (1-a)*x + a*tanh( temp + W*x );                
        u1 = Wout1*x(1:resSize1);                            
        u = [u1;0;0;0];
        Y1(:,t) = u1;
    end
    figure(2);
    plot( Y_t1(1,1:errorLen), 'color', [0,0.75,0] );
    hold on;
    plot( Y1(1,1:errorLen), 'b' );
    hold off;
    axis tight;
    title('The predicted and true values of the Roessler system');
    legend('Target signal', ' predicted signal');
    figure(3);
    plot3(Y1(1,:),Y1(2,:),Y1(3,:))

    case 'roessler'
        x=X(:,end);
    for t = 1:testLen 
        u1 = u(1:inSize1);
        u2 = u(inSize1+1:end);
        temp1=Win1*u1;
        temp2=Win2*u2;
        temp=[temp1;temp2];
        x = (1-a)*x + a*tanh( temp + W*x );  
        % temp3=x(1+resSize1:end);    % squaring of the even-indexed entries
        % temp3(2:2:end)=temp3(2:2:end).^2; % squaring of the even-indexed entries
        % u2 = Wout2*temp3;   % squaring of the even-indexed entries
        u2 = Wout2*x(1+resSize1:end);                            
        u = [0;0;0;u2];
        Y2(:,t) = u2;   
    end
    figure(2);
    plot( Y_t2(1,1:errorLen), 'color', [0,0.75,0] );
    hold on;
    plot( Y2(1,1:errorLen), 'b' );
    hold off;
    axis tight;
    title('The predicted and true values of the Roessler system');
    legend('Target signal', ' predicted signal');

    figure(3);
    plot3(Y2(1,:),Y2(2,:),Y2(3,:))

end


% mse1 = sum((Y_t1(1,1:errorLen)-Y1(1,1:errorLen)).^2)./errorLen;

% mse = sum((Y_t(1,1:errorLen)-Y(1,1:errorLen)).^2)./errorLen+sum((Y_t(3,1:errorLen)-Y(3,1:errorLen)).^2)./errorLen;
% rmse1 = sqrt(mse1);
% disp( ['MSE = ', num2str( rmse )] );


% plot(Y1(1,:),Y1(2,:))
% hold on;
% plot(Y2(1,:),Y2(2,:))
% xlabel('x')
% ylabel('y')

plot3(Y2(1,:),Y2(2,:),Y2(3,:))
hold on;
plot3(Y_t2(1,:),Y_t2(2,:),Y_t2(3,:))
axis on;
% addpath ('result_lorenz_roessler_coupling/')
% dlmwrite('result_lorenz_roessler_coupling/roessler_coupling_true.dat', Y_t2, 'delimiter', '\t');
% dlmwrite('result_lorenz_roessler_coupling/roessler_coupling_pre.dat', Y2, 'delimiter', '\t');
