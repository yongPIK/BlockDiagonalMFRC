# Data and results

This directory holds the plotting data, table results and time series used by
the code.

| Directory | Content |
|---|---|
| `TimeSeries/` | 12 raw time series (ten systems + the Lorenz/Roessler data used for the decoupled run + the weakly coupled Lorenz-Roessler data) |
| `result_MFRC/result_MFRC/` | 500-realization D2 matrices of the ten systems, D2 of the single-task RC, attractor trajectories |
| `KLD_MATLAB/results/` | KLD D_sym matrices and success rates (Table 4) |
| `Wout_norm/data/` | readout-matrix statistics of the ten systems (Fig. 12) |
| `sprottBC_modularity_robustness/` | success-rate and Q grids of Fig. 8 |
| `multifunctionRC/result_add_noise/` | functional-network modularity Q grid (Fig. 8(d)) |
| `GP_updated/` | classical RC results obtained with the updated GP |

## Key protocols

### Ten-system MFRC / classical RC

- MFRC: `trainLen = 60000`, `initLen = 6000`, `testLen = 30000`, per-module
  readout window
  `trainlen_vec = [50000 20000 20000 40000 5000 10000 3000 5000 10000 50000]`;
- classical RC: the per-system training / washout / test lengths listed in
  `MATLAB/README.md` section 7 (SprottA 50000/500/60000, SprottB and SprottC
  20000/2000/2000, SprottD 40000/4000/3000, Lorenz 5000/500/500, Roessler
  10000/1000/500, Chen 3000/300/300, Selkov 5000/500/1000, Hyper-osc
  10000/1000/600, Hyper-SprottB 50000/5000/3000), rollout initialized at
  `X(:,1)`; the ten-system KLD replica instead uses the common
  `trainLen = 50000, initLen = 5000` for every system except Hyper-osc
  (see `MATLAB/KLD_MATLAB/system_config.m`);
- D2 down-sampling interval `gap = 10`; success criterion
  |D2_pred - D2_true| / D2_true < 0.20 over 500 realizations.

### Table 4 (KLD)

Success rates of the symmetric KLD criterion D_sym < 0.20 over 500
realizations. The Hyper-osc column uses the same RC protocol as its Table 3
entry (`rc_trainLen = 10000, rc_initLen = 1000`), the other systems use
`rc_trainLen = 50000, rc_initLen = 5000`; the parameters are set in
`MATLAB/KLD_MATLAB/system_config.m`.

```text
MFRC Hyper-osc, kappa=0.20: 0.764
RC   Hyper-osc, kappa=0.20: 0.368
```
